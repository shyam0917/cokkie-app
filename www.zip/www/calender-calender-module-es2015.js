(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["calender-calender-module"],{

/***/ "./node_modules/raw-loader/dist/cjs.js!./src/app/calender/calender.page.html":
/*!***********************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/calender/calender.page.html ***!
  \***********************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("<ion-header>\n  <ion-toolbar class=\"customize-toolbar\">\n    <ion-buttons slot=\"start\">\n      <ion-back-button text=\"\" color=\"light\"></ion-back-button>\n    </ion-buttons>\n    <ion-img class=\"logo p-3\" src=\"assets/img/logo.png\"></ion-img>\n  </ion-toolbar>\n</ion-header>\n\n\n<ion-content>\n  <div class=\"app-layout set-height\">\n    <div class=\"container\">\n      <div class=\"heading\">\n        <h3>STAFF CALENDAR SYSTEM</h3>\n      </div>  \n      <ion-list class=\"select-staff\">      \n        <ion-item>\n          <ion-label>Select Staff</ion-label>\n          <ion-select okText=\"Okay\" cancelText=\"Dismiss\">\n            <ion-select-option >briannormoye(Brian normoye)</ion-select-option>\n            <ion-select-option>development(Dev</ion-select-option>\n            <ion-select-option >elitermg(elitermg</ion-select-option>\n            <ion-select-option >BroJon cooke(Jon Cooke)wn</ion-select-option>\n          </ion-select>\n        </ion-item>\n      \n      </ion-list>\n\n      <ion-calendar [(ngModel)]=\"date\"\n              (change)=\"onChange($event)\"\n              [type]=\"type\"\n              [format]=\"'YYYY-MM-DD'\">\n</ion-calendar>\n    </div>\n  </div>\n</ion-content>\n\n\n");

/***/ }),

/***/ "./src/app/calender/calender-routing.module.ts":
/*!*****************************************************!*\
  !*** ./src/app/calender/calender-routing.module.ts ***!
  \*****************************************************/
/*! exports provided: CalenderPageRoutingModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "CalenderPageRoutingModule", function() { return CalenderPageRoutingModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm2015/core.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm2015/router.js");
/* harmony import */ var _calender_page__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./calender.page */ "./src/app/calender/calender.page.ts");




const routes = [
    {
        path: '',
        component: _calender_page__WEBPACK_IMPORTED_MODULE_3__["CalenderPage"]
    },
    {
        path: 'add-event',
        loadChildren: () => __webpack_require__.e(/*! import() | add-event-add-event-module */ "add-event-add-event-module").then(__webpack_require__.bind(null, /*! ./add-event/add-event.module */ "./src/app/calender/add-event/add-event.module.ts")).then(m => m.AddEventPageModule)
    }
];
let CalenderPageRoutingModule = class CalenderPageRoutingModule {
};
CalenderPageRoutingModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"].forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"]],
    })
], CalenderPageRoutingModule);



/***/ }),

/***/ "./src/app/calender/calender.module.ts":
/*!*********************************************!*\
  !*** ./src/app/calender/calender.module.ts ***!
  \*********************************************/
/*! exports provided: CalenderPageModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "CalenderPageModule", function() { return CalenderPageModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm2015/core.js");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/fesm2015/common.js");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/forms */ "./node_modules/@angular/forms/fesm2015/forms.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/fesm2015/ionic-angular.js");
/* harmony import */ var _calender_routing_module__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./calender-routing.module */ "./src/app/calender/calender-routing.module.ts");
/* harmony import */ var ion2_calendar__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ion2-calendar */ "./node_modules/ion2-calendar/dist/index.js");
/* harmony import */ var ion2_calendar__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(ion2_calendar__WEBPACK_IMPORTED_MODULE_6__);
/* harmony import */ var _calender_page__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ./calender.page */ "./src/app/calender/calender.page.ts");








let CalenderPageModule = class CalenderPageModule {
};
CalenderPageModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"],
            _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormsModule"],
            _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["IonicModule"],
            ion2_calendar__WEBPACK_IMPORTED_MODULE_6__["CalendarModule"],
            _calender_routing_module__WEBPACK_IMPORTED_MODULE_5__["CalenderPageRoutingModule"]
        ],
        declarations: [_calender_page__WEBPACK_IMPORTED_MODULE_7__["CalenderPage"]]
    })
], CalenderPageModule);



/***/ }),

/***/ "./src/app/calender/calender.page.scss":
/*!*********************************************!*\
  !*** ./src/app/calender/calender.page.scss ***!
  \*********************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = (".select-staff {\n  margin-bottom: 20px;\n}\n\n.button-native::after {\n  left: 0px;\n  right: 0px;\n  top: 0px;\n  bottom: 0px;\n  position: absolute;\n  content: \"\";\n  opacity: 0 !important;\n  background: red;\n  --background:#000 !important;\n  width: 10px;\n  height: 10px;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvY2FsZW5kZXIvRTpcXHNoaXBnaWdcXGNva2tpZS1hcHAvc3JjXFxhcHBcXGNhbGVuZGVyXFxjYWxlbmRlci5wYWdlLnNjc3MiLCJzcmMvYXBwL2NhbGVuZGVyL2NhbGVuZGVyLnBhZ2Uuc2NzcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQTtFQUNJLG1CQUFBO0FDQ0o7O0FEQ0E7RUFDSSxTQUFBO0VBQ0EsVUFBQTtFQUNBLFFBQUE7RUFDQSxXQUFBO0VBQ0Esa0JBQUE7RUFDQSxXQUFBO0VBQ0EscUJBQUE7RUFDQSxlQUFBO0VBQ0EsNEJBQUE7RUFDQSxXQUFBO0VBQ0EsWUFBQTtBQ0VKIiwiZmlsZSI6InNyYy9hcHAvY2FsZW5kZXIvY2FsZW5kZXIucGFnZS5zY3NzIiwic291cmNlc0NvbnRlbnQiOlsiLnNlbGVjdC1zdGFmZntcclxuICAgIG1hcmdpbi1ib3R0b206IDIwcHg7XHJcbn1cclxuLmJ1dHRvbi1uYXRpdmU6OmFmdGVyIHtcclxuICAgIGxlZnQ6IDBweDtcclxuICAgIHJpZ2h0OiAwcHg7XHJcbiAgICB0b3A6IDBweDtcclxuICAgIGJvdHRvbTogMHB4O1xyXG4gICAgcG9zaXRpb246IGFic29sdXRlO1xyXG4gICAgY29udGVudDogXCJcIjtcclxuICAgIG9wYWNpdHk6IDAgIWltcG9ydGFudDtcclxuICAgIGJhY2tncm91bmQ6IHJlZDtcclxuICAgIC0tYmFja2dyb3VuZDojMDAwICFpbXBvcnRhbnQ7XHJcbiAgICB3aWR0aDogMTBweDtcclxuICAgIGhlaWdodDogMTBweDtcclxufSIsIi5zZWxlY3Qtc3RhZmYge1xuICBtYXJnaW4tYm90dG9tOiAyMHB4O1xufVxuXG4uYnV0dG9uLW5hdGl2ZTo6YWZ0ZXIge1xuICBsZWZ0OiAwcHg7XG4gIHJpZ2h0OiAwcHg7XG4gIHRvcDogMHB4O1xuICBib3R0b206IDBweDtcbiAgcG9zaXRpb246IGFic29sdXRlO1xuICBjb250ZW50OiBcIlwiO1xuICBvcGFjaXR5OiAwICFpbXBvcnRhbnQ7XG4gIGJhY2tncm91bmQ6IHJlZDtcbiAgLS1iYWNrZ3JvdW5kOiMwMDAgIWltcG9ydGFudDtcbiAgd2lkdGg6IDEwcHg7XG4gIGhlaWdodDogMTBweDtcbn0iXX0= */");

/***/ }),

/***/ "./src/app/calender/calender.page.ts":
/*!*******************************************!*\
  !*** ./src/app/calender/calender.page.ts ***!
  \*******************************************/
/*! exports provided: CalenderPage */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "CalenderPage", function() { return CalenderPage; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm2015/core.js");


let CalenderPage = class CalenderPage {
    constructor() { }
    ngOnInit() {
    }
    onChange($event) {
    }
};
CalenderPage = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
        selector: 'app-calender',
        template: tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(/*! raw-loader!./calender.page.html */ "./node_modules/raw-loader/dist/cjs.js!./src/app/calender/calender.page.html")).default,
        styles: [tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(/*! ./calender.page.scss */ "./src/app/calender/calender.page.scss")).default]
    }),
    tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [])
], CalenderPage);



/***/ })

}]);
//# sourceMappingURL=calender-calender-module-es2015.js.map
function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

function _defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } }

function _createClass(Constructor, protoProps, staticProps) { if (protoProps) _defineProperties(Constructor.prototype, protoProps); if (staticProps) _defineProperties(Constructor, staticProps); return Constructor; }

(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["calender-calender-module"], {
  /***/
  "./node_modules/ionic2-calendar/fesm2015/ionic2-calendar.js":
  /*!******************************************************************!*\
    !*** ./node_modules/ionic2-calendar/fesm2015/ionic2-calendar.js ***!
    \******************************************************************/

  /*! exports provided: CalendarComponent, NgCalendarModule, ɵa, ɵb, ɵc, ɵd, ɵe */

  /***/
  function node_modulesIonic2CalendarFesm2015Ionic2CalendarJs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "CalendarComponent", function () {
      return CalendarComponent;
    });
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "NgCalendarModule", function () {
      return NgCalendarModule;
    });
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "ɵa", function () {
      return MonthViewComponent;
    });
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "ɵb", function () {
      return CalendarService;
    });
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "ɵc", function () {
      return WeekViewComponent;
    });
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "ɵd", function () {
      return DayViewComponent;
    });
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "ɵe", function () {
      return initPositionScrollComponent;
    });
    /* harmony import */


    var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! tslib */
    "./node_modules/tslib/tslib.es6.js");
    /* harmony import */


    var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! @angular/core */
    "./node_modules/@angular/core/fesm2015/core.js");
    /* harmony import */


    var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
    /*! @angular/common */
    "./node_modules/@angular/common/fesm2015/common.js");
    /* harmony import */


    var _ionic_angular__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
    /*! @ionic/angular */
    "./node_modules/@ionic/angular/fesm2015/ionic-angular.js");
    /* harmony import */


    var rxjs__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(
    /*! rxjs */
    "./node_modules/rxjs/_esm2015/index.js");

    var CalendarService =
    /*#__PURE__*/
    function () {
      function CalendarService() {
        _classCallCheck(this, CalendarService);

        this.currentDateChangedFromParent = new rxjs__WEBPACK_IMPORTED_MODULE_4__["Subject"]();
        this.currentDateChangedFromChildren = new rxjs__WEBPACK_IMPORTED_MODULE_4__["Subject"]();
        this.eventSourceChanged = new rxjs__WEBPACK_IMPORTED_MODULE_4__["Subject"]();
        this.slideChanged = new rxjs__WEBPACK_IMPORTED_MODULE_4__["Subject"]();
        this.currentDateChangedFromParent$ = this.currentDateChangedFromParent.asObservable();
        this.currentDateChangedFromChildren$ = this.currentDateChangedFromChildren.asObservable();
        this.eventSourceChanged$ = this.eventSourceChanged.asObservable();
        this.slideChanged$ = this.slideChanged.asObservable();
      }

      _createClass(CalendarService, [{
        key: "setCurrentDate",
        value: function setCurrentDate(val) {
          var fromParent = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : false;
          this._currentDate = new Date(val);

          if (fromParent) {
            this.currentDateChangedFromParent.next(val);
          } else {
            this.currentDateChangedFromChildren.next(val);
          }
        }
      }, {
        key: "rangeChanged",
        value: function rangeChanged(component) {
          if (this.queryMode === 'local') {
            if (component.eventSource && component.onDataLoaded) {
              component.onDataLoaded();
            }
          } else if (this.queryMode === 'remote') {
            var rangeStart = new Date(component.range.startTime.getTime()),
                rangeEnd = new Date(component.range.endTime.getTime());
            rangeStart.setHours(0);

            if (rangeStart.getHours() === 23) {
              rangeStart.setTime(rangeStart.getTime() + 3600000);
            }

            rangeEnd.setHours(0);

            if (rangeEnd.getHours() === 23) {
              rangeEnd.setTime(rangeEnd.getTime() + 3600000);
            }

            component.onRangeChanged.emit({
              startTime: rangeStart,
              endTime: rangeEnd
            });
          }
        }
      }, {
        key: "getStep",
        value: function getStep(mode) {
          switch (mode) {
            case 'month':
              return {
                years: 0,
                months: 1,
                days: 0
              };

            case 'week':
              return {
                years: 0,
                months: 0,
                days: 7
              };

            case 'day':
              return {
                years: 0,
                months: 0,
                days: 1
              };
          }
        }
      }, {
        key: "getAdjacentCalendarDate",
        value: function getAdjacentCalendarDate(mode, direction) {
          var calculateCalendarDate = this.currentDate;
          var step = this.getStep(mode),
              year = calculateCalendarDate.getFullYear() + direction * step.years,
              month = calculateCalendarDate.getMonth() + direction * step.months,
              date = calculateCalendarDate.getDate() + direction * step.days;
          calculateCalendarDate = new Date(year, month, date, 12, 0, 0);

          if (mode === 'month') {
            var firstDayInNextMonth = new Date(year, month + 1, 1, 12, 0, 0);

            if (firstDayInNextMonth.getTime() <= calculateCalendarDate.getTime()) {
              calculateCalendarDate = new Date(firstDayInNextMonth.getTime() - 24 * 60 * 60 * 1000);
            }
          }

          return calculateCalendarDate;
        }
      }, {
        key: "getAdjacentViewStartTime",
        value: function getAdjacentViewStartTime(component, direction) {
          var adjacentCalendarDate = this.getAdjacentCalendarDate(component.mode, direction);
          return component.getRange(adjacentCalendarDate).startTime;
        }
      }, {
        key: "populateAdjacentViews",
        value: function populateAdjacentViews(component) {
          var currentViewStartDate,
              currentViewData,
              toUpdateViewIndex,
              currentViewIndex = component.currentViewIndex;

          if (component.direction === 1) {
            currentViewStartDate = this.getAdjacentViewStartTime(component, 1);
            toUpdateViewIndex = (currentViewIndex + 1) % 3;
            component.views[toUpdateViewIndex] = component.getViewData(currentViewStartDate);
          } else if (component.direction === -1) {
            currentViewStartDate = this.getAdjacentViewStartTime(component, -1);
            toUpdateViewIndex = (currentViewIndex + 2) % 3;
            component.views[toUpdateViewIndex] = component.getViewData(currentViewStartDate);
          } else {
            if (!component.views) {
              currentViewData = [];
              currentViewStartDate = component.range.startTime;
              currentViewData.push(component.getViewData(currentViewStartDate));
              currentViewStartDate = this.getAdjacentViewStartTime(component, 1);
              currentViewData.push(component.getViewData(currentViewStartDate));
              currentViewStartDate = this.getAdjacentViewStartTime(component, -1);
              currentViewData.push(component.getViewData(currentViewStartDate));
              component.views = currentViewData;
            } else {
              currentViewStartDate = component.range.startTime;
              component.views[currentViewIndex] = component.getViewData(currentViewStartDate);
              currentViewStartDate = this.getAdjacentViewStartTime(component, -1);
              toUpdateViewIndex = (currentViewIndex + 2) % 3;
              component.views[toUpdateViewIndex] = component.getViewData(currentViewStartDate);
              currentViewStartDate = this.getAdjacentViewStartTime(component, 1);
              toUpdateViewIndex = (currentViewIndex + 1) % 3;
              component.views[toUpdateViewIndex] = component.getViewData(currentViewStartDate);
            }
          }
        }
      }, {
        key: "loadEvents",
        value: function loadEvents() {
          this.eventSourceChanged.next();
        }
      }, {
        key: "slide",
        value: function slide(direction) {
          this.slideChanged.next(direction);
        }
      }, {
        key: "currentDate",
        get: function get() {
          return this._currentDate;
        }
      }]);

      return CalendarService;
    }();

    CalendarService = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Injectable"])()], CalendarService);
    var MonthViewComponent_1;

    var MonthViewComponent = MonthViewComponent_1 =
    /*#__PURE__*/
    function () {
      function MonthViewComponent(calendarService) {
        _classCallCheck(this, MonthViewComponent);

        this.calendarService = calendarService;
        this.autoSelect = true;
        this.dir = '';
        this.onRangeChanged = new _angular_core__WEBPACK_IMPORTED_MODULE_1__["EventEmitter"]();
        this.onEventSelected = new _angular_core__WEBPACK_IMPORTED_MODULE_1__["EventEmitter"]();
        this.onTimeSelected = new _angular_core__WEBPACK_IMPORTED_MODULE_1__["EventEmitter"](true);
        this.onTitleChanged = new _angular_core__WEBPACK_IMPORTED_MODULE_1__["EventEmitter"](true);
        this.views = [];
        this.currentViewIndex = 0;
        this.mode = 'month';
        this.direction = 0;
        this.moveOnSelected = false;
        this.inited = false;
        this.callbackOnInit = true;
      }

      _createClass(MonthViewComponent, [{
        key: "ngOnInit",
        value: function ngOnInit() {
          var _this = this;

          if (!this.sliderOptions) {
            this.sliderOptions = {};
          }

          this.sliderOptions.loop = true;

          if (this.dateFormatter && this.dateFormatter.formatMonthViewDay) {
            this.formatDayLabel = this.dateFormatter.formatMonthViewDay;
          } else {
            var dayLabelDatePipe = new _angular_common__WEBPACK_IMPORTED_MODULE_2__["DatePipe"]('en-US');

            this.formatDayLabel = function (date) {
              return dayLabelDatePipe.transform(date, this.formatDay);
            };
          }

          if (this.dateFormatter && this.dateFormatter.formatMonthViewDayHeader) {
            this.formatDayHeaderLabel = this.dateFormatter.formatMonthViewDayHeader;
          } else {
            var datePipe = new _angular_common__WEBPACK_IMPORTED_MODULE_2__["DatePipe"](this.locale);

            this.formatDayHeaderLabel = function (date) {
              return datePipe.transform(date, this.formatDayHeader);
            };
          }

          if (this.dateFormatter && this.dateFormatter.formatMonthViewTitle) {
            this.formatTitle = this.dateFormatter.formatMonthViewTitle;
          } else {
            var _datePipe = new _angular_common__WEBPACK_IMPORTED_MODULE_2__["DatePipe"](this.locale);

            this.formatTitle = function (date) {
              return _datePipe.transform(date, this.formatMonthTitle);
            };
          }

          if (this.lockSwipeToPrev) {
            this.slider.lockSwipeToPrev(true);
          }

          if (this.lockSwipes) {
            this.slider.lockSwipes(true);
          }

          this.refreshView();
          this.inited = true;
          this.currentDateChangedFromParentSubscription = this.calendarService.currentDateChangedFromParent$.subscribe(function (currentDate) {
            _this.refreshView();
          });
          this.eventSourceChangedSubscription = this.calendarService.eventSourceChanged$.subscribe(function () {
            _this.onDataLoaded();
          });
          this.slideChangedSubscription = this.calendarService.slideChanged$.subscribe(function (direction) {
            if (direction === 1) {
              _this.slider.slideNext();
            } else if (direction === -1) {
              _this.slider.slidePrev();
            }
          });
        }
      }, {
        key: "ngOnDestroy",
        value: function ngOnDestroy() {
          if (this.currentDateChangedFromParentSubscription) {
            this.currentDateChangedFromParentSubscription.unsubscribe();
            this.currentDateChangedFromParentSubscription = null;
          }

          if (this.eventSourceChangedSubscription) {
            this.eventSourceChangedSubscription.unsubscribe();
            this.eventSourceChangedSubscription = null;
          }

          if (this.slideChangedSubscription) {
            this.slideChangedSubscription.unsubscribe();
            this.slideChangedSubscription = null;
          }
        }
      }, {
        key: "ngOnChanges",
        value: function ngOnChanges(changes) {
          if (!this.inited) {
            return;
          }

          var eventSourceChange = changes.eventSource;

          if (eventSourceChange && eventSourceChange.currentValue) {
            this.onDataLoaded();
          }

          var lockSwipeToPrev = changes.lockSwipeToPrev;

          if (lockSwipeToPrev) {
            this.slider.lockSwipeToPrev(lockSwipeToPrev.currentValue);
          }

          var lockSwipes = changes.lockSwipes;

          if (lockSwipes) {
            this.slider.lockSwipes(lockSwipes.currentValue);
          }
        }
      }, {
        key: "ngAfterViewInit",
        value: function ngAfterViewInit() {
          var title = this.getTitle();
          this.onTitleChanged.emit(title);
        }
      }, {
        key: "onSlideChanged",
        value: function onSlideChanged() {
          var _this2 = this;

          if (this.callbackOnInit) {
            this.callbackOnInit = false;
            return;
          }

          var direction = 0;
          var currentViewIndex = this.currentViewIndex;
          this.slider.getActiveIndex().then(function (currentSlideIndex) {
            currentSlideIndex = (currentSlideIndex + 2) % 3;

            if (isNaN(currentSlideIndex)) {
              currentSlideIndex = currentViewIndex;
            }

            if (currentSlideIndex - currentViewIndex === 1) {
              direction = 1;
            } else if (currentSlideIndex === 0 && currentViewIndex === 2) {
              direction = 1;

              _this2.slider.slideTo(1, 0, false);
            } else if (currentViewIndex - currentSlideIndex === 1) {
              direction = -1;
            } else if (currentSlideIndex === 2 && currentViewIndex === 0) {
              direction = -1;

              _this2.slider.slideTo(3, 0, false);
            }

            _this2.currentViewIndex = currentSlideIndex;

            _this2.move(direction);
          });
        }
      }, {
        key: "move",
        value: function move(direction) {
          if (direction === 0) {
            return;
          }

          this.direction = direction;

          if (!this.moveOnSelected) {
            var adjacentDate = this.calendarService.getAdjacentCalendarDate(this.mode, direction);
            this.calendarService.setCurrentDate(adjacentDate);
          }

          this.refreshView();
          this.direction = 0;
          this.moveOnSelected = false;
        }
      }, {
        key: "createDateObject",
        value: function createDateObject(date) {
          var disabled = false;

          if (this.markDisabled) {
            disabled = this.markDisabled(date);
          }

          return {
            date: date,
            events: [],
            label: this.formatDayLabel(date),
            secondary: false,
            disabled: disabled
          };
        }
      }, {
        key: "getViewData",
        value: function getViewData(startTime) {
          var startDate = startTime,
              date = startDate.getDate(),
              month = (startDate.getMonth() + (date !== 1 ? 1 : 0)) % 12;
          var dates = MonthViewComponent_1.getDates(startDate, 42);
          var days = [];

          for (var i = 0; i < 42; i++) {
            var dateObject = this.createDateObject(dates[i]);
            dateObject.secondary = dates[i].getMonth() !== month;
            days[i] = dateObject;
          }

          var dayHeaders = [];

          for (var _i = 0; _i < 7; _i++) {
            dayHeaders.push(this.formatDayHeaderLabel(days[_i].date));
          }

          return {
            dates: days,
            dayHeaders: dayHeaders
          };
        }
      }, {
        key: "getHighlightClass",
        value: function getHighlightClass(date) {
          var className = '';

          if (date.hasEvent) {
            if (date.secondary) {
              className = 'monthview-secondary-with-event';
            } else {
              className = 'monthview-primary-with-event';
            }
          }

          if (date.selected) {
            if (className) {
              className += ' ';
            }

            className += 'monthview-selected';
          }

          if (date.current) {
            if (className) {
              className += ' ';
            }

            className += 'monthview-current';
          }

          if (date.secondary) {
            if (className) {
              className += ' ';
            }

            className += 'text-muted';
          }

          if (date.disabled) {
            if (className) {
              className += ' ';
            }

            className += 'monthview-disabled';
          }

          return className;
        }
      }, {
        key: "getRange",
        value: function getRange(currentDate) {
          var year = currentDate.getFullYear(),
              month = currentDate.getMonth(),
              firstDayOfMonth = new Date(year, month, 1, 12, 0, 0),
              // set hour to 12 to avoid DST problem
          difference = this.startingDayMonth - firstDayOfMonth.getDay(),
              numDisplayedFromPreviousMonth = difference > 0 ? 7 - difference : -difference,
              startDate = new Date(firstDayOfMonth.getTime());

          if (numDisplayedFromPreviousMonth > 0) {
            startDate.setDate(-numDisplayedFromPreviousMonth + 1);
          }

          var endDate = new Date(startDate.getTime());
          endDate.setDate(endDate.getDate() + 42);
          return {
            startTime: startDate,
            endTime: endDate
          };
        }
      }, {
        key: "onDataLoaded",
        value: function onDataLoaded() {
          var range = this.range,
              eventSource = this.eventSource,
              len = eventSource ? eventSource.length : 0,
              startTime = range.startTime,
              endTime = range.endTime,
              utcStartTime = Date.UTC(startTime.getFullYear(), startTime.getMonth(), startTime.getDate()),
              utcEndTime = Date.UTC(endTime.getFullYear(), endTime.getMonth(), endTime.getDate()),
              currentViewIndex = this.currentViewIndex,
              dates = this.views[currentViewIndex].dates,
              oneDay = 86400000,
              eps = 0.0006;

          for (var r = 0; r < 42; r += 1) {
            if (dates[r].hasEvent) {
              dates[r].hasEvent = false;
              dates[r].events = [];
            }
          }

          for (var i = 0; i < len; i += 1) {
            var event = eventSource[i],
                eventStartTime = event.startTime,
                eventEndTime = event.endTime;
            var eventUTCStartTime = void 0,
                eventUTCEndTime = void 0;

            if (event.allDay) {
              eventUTCStartTime = eventStartTime.getTime();
              eventUTCEndTime = eventEndTime.getTime();
            } else {
              eventUTCStartTime = Date.UTC(eventStartTime.getFullYear(), eventStartTime.getMonth(), eventStartTime.getDate());
              eventUTCEndTime = Date.UTC(eventEndTime.getFullYear(), eventEndTime.getMonth(), eventEndTime.getDate() + 1);
            }

            if (eventUTCEndTime <= utcStartTime || eventUTCStartTime >= utcEndTime) {
              continue;
            }

            var timeDifferenceStart = void 0,
                timeDifferenceEnd = void 0;

            if (eventUTCStartTime < utcStartTime) {
              timeDifferenceStart = 0;
            } else {
              timeDifferenceStart = (eventUTCStartTime - utcStartTime) / oneDay;
            }

            if (eventUTCEndTime > utcEndTime) {
              timeDifferenceEnd = (utcEndTime - utcStartTime) / oneDay;
            } else {
              timeDifferenceEnd = (eventUTCEndTime - utcStartTime) / oneDay;
            }

            var index = Math.floor(timeDifferenceStart);
            var endIndex = Math.ceil(timeDifferenceEnd - eps);

            while (index < endIndex) {
              dates[index].hasEvent = true;
              var eventSet = dates[index].events;

              if (eventSet) {
                eventSet.push(event);
              } else {
                eventSet = [];
                eventSet.push(event);
                dates[index].events = eventSet;
              }

              index += 1;
            }
          }

          for (var _r = 0; _r < 42; _r += 1) {
            if (dates[_r].hasEvent) {
              dates[_r].events.sort(this.compareEvent);
            }
          }

          if (this.autoSelect) {
            var findSelected = false;

            for (var _r2 = 0; _r2 < 42; _r2 += 1) {
              if (dates[_r2].selected) {
                this.selectedDate = dates[_r2];
                findSelected = true;
                break;
              }
            }

            if (findSelected) {
              this.onTimeSelected.emit({
                selectedTime: this.selectedDate.date,
                events: this.selectedDate.events,
                disabled: this.selectedDate.disabled
              });
            }
          }
        }
      }, {
        key: "refreshView",
        value: function refreshView() {
          this.range = this.getRange(this.calendarService.currentDate);

          if (this.inited) {
            var title = this.getTitle();
            this.onTitleChanged.emit(title);
          }

          this.calendarService.populateAdjacentViews(this);
          this.updateCurrentView(this.range.startTime, this.views[this.currentViewIndex]);
          this.calendarService.rangeChanged(this);
        }
      }, {
        key: "getTitle",
        value: function getTitle() {
          var currentViewStartDate = this.range.startTime,
              date = currentViewStartDate.getDate(),
              month = (currentViewStartDate.getMonth() + (date !== 1 ? 1 : 0)) % 12,
              year = currentViewStartDate.getFullYear() + (date !== 1 && month === 0 ? 1 : 0),
              headerDate = new Date(year, month, 1, 12, 0, 0, 0);
          return this.formatTitle(headerDate);
        }
      }, {
        key: "compareEvent",
        value: function compareEvent(event1, event2) {
          if (event1.allDay) {
            return 1;
          } else if (event2.allDay) {
            return -1;
          } else {
            return event1.startTime.getTime() - event2.startTime.getTime();
          }
        }
      }, {
        key: "select",
        value: function select(viewDate) {
          if (!this.views) {
            return;
          }

          var selectedDate = viewDate.date,
              events = viewDate.events;

          if (!viewDate.disabled) {
            var dates = this.views[this.currentViewIndex].dates,
                currentCalendarDate = this.calendarService.currentDate,
                currentMonth = currentCalendarDate.getMonth(),
                currentYear = currentCalendarDate.getFullYear(),
                selectedMonth = selectedDate.getMonth(),
                selectedYear = selectedDate.getFullYear();
            var direction = 0;

            if (currentYear === selectedYear) {
              if (currentMonth !== selectedMonth) {
                direction = currentMonth < selectedMonth ? 1 : -1;
              }
            } else {
              direction = currentYear < selectedYear ? 1 : -1;
            }

            this.calendarService.setCurrentDate(selectedDate);

            if (direction === 0) {
              var currentViewStartDate = this.range.startTime,
                  oneDay = 86400000,
                  selectedDayDifference = Math.round((Date.UTC(selectedDate.getFullYear(), selectedDate.getMonth(), selectedDate.getDate()) - Date.UTC(currentViewStartDate.getFullYear(), currentViewStartDate.getMonth(), currentViewStartDate.getDate())) / oneDay);

              for (var r = 0; r < 42; r += 1) {
                dates[r].selected = false;
              }

              if (selectedDayDifference >= 0 && selectedDayDifference < 42) {
                dates[selectedDayDifference].selected = true;
                this.selectedDate = dates[selectedDayDifference];
              }
            } else {
              this.moveOnSelected = true;
              this.slideView(direction);
            }
          }

          this.onTimeSelected.emit({
            selectedTime: selectedDate,
            events: events,
            disabled: viewDate.disabled
          });
        }
      }, {
        key: "slideView",
        value: function slideView(direction) {
          if (direction === 1) {
            this.slider.slideNext();
          } else if (direction === -1) {
            this.slider.slidePrev();
          }
        }
      }, {
        key: "updateCurrentView",
        value: function updateCurrentView(currentViewStartDate, view) {
          var currentCalendarDate = this.calendarService.currentDate,
              today = new Date(),
              oneDay = 86400000,
              selectedDayDifference = Math.round((Date.UTC(currentCalendarDate.getFullYear(), currentCalendarDate.getMonth(), currentCalendarDate.getDate()) - Date.UTC(currentViewStartDate.getFullYear(), currentViewStartDate.getMonth(), currentViewStartDate.getDate())) / oneDay),
              currentDayDifference = Math.round((Date.UTC(today.getFullYear(), today.getMonth(), today.getDate()) - Date.UTC(currentViewStartDate.getFullYear(), currentViewStartDate.getMonth(), currentViewStartDate.getDate())) / oneDay);

          for (var r = 0; r < 42; r += 1) {
            view.dates[r].selected = false;
          }

          if (selectedDayDifference >= 0 && selectedDayDifference < 42 && !view.dates[selectedDayDifference].disabled && (this.autoSelect || this.moveOnSelected)) {
            view.dates[selectedDayDifference].selected = true;
            this.selectedDate = view.dates[selectedDayDifference];
          } else {
            this.selectedDate = {
              date: null,
              events: [],
              label: null,
              secondary: null,
              disabled: false
            };
          }

          if (currentDayDifference >= 0 && currentDayDifference < 42) {
            view.dates[currentDayDifference].current = true;
          }
        }
      }, {
        key: "eventSelected",
        value: function eventSelected(event) {
          this.onEventSelected.emit(event);
        }
      }], [{
        key: "getDates",
        value: function getDates(startDate, n) {
          var dates = new Array(n),
              current = new Date(startDate.getTime());
          var i = 0;

          while (i < n) {
            dates[i++] = new Date(current.getTime());
            current.setDate(current.getDate() + 1);
          }

          return dates;
        }
      }]);

      return MonthViewComponent;
    }();

    MonthViewComponent.ctorParameters = function () {
      return [{
        type: CalendarService
      }];
    };

    Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["ViewChild"])('monthSlider', {
      static: true
    })], MonthViewComponent.prototype, "slider", void 0);
    Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Input"])()], MonthViewComponent.prototype, "monthviewDisplayEventTemplate", void 0);
    Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Input"])()], MonthViewComponent.prototype, "monthviewInactiveDisplayEventTemplate", void 0);
    Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Input"])()], MonthViewComponent.prototype, "monthviewEventDetailTemplate", void 0);
    Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Input"])()], MonthViewComponent.prototype, "formatDay", void 0);
    Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Input"])()], MonthViewComponent.prototype, "formatDayHeader", void 0);
    Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Input"])()], MonthViewComponent.prototype, "formatMonthTitle", void 0);
    Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Input"])()], MonthViewComponent.prototype, "eventSource", void 0);
    Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Input"])()], MonthViewComponent.prototype, "startingDayMonth", void 0);
    Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Input"])()], MonthViewComponent.prototype, "showEventDetail", void 0);
    Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Input"])()], MonthViewComponent.prototype, "noEventsLabel", void 0);
    Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Input"])()], MonthViewComponent.prototype, "autoSelect", void 0);
    Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Input"])()], MonthViewComponent.prototype, "markDisabled", void 0);
    Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Input"])()], MonthViewComponent.prototype, "locale", void 0);
    Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Input"])()], MonthViewComponent.prototype, "dateFormatter", void 0);
    Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Input"])()], MonthViewComponent.prototype, "dir", void 0);
    Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Input"])()], MonthViewComponent.prototype, "lockSwipeToPrev", void 0);
    Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Input"])()], MonthViewComponent.prototype, "lockSwipes", void 0);
    Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Input"])()], MonthViewComponent.prototype, "sliderOptions", void 0);
    Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Output"])()], MonthViewComponent.prototype, "onRangeChanged", void 0);
    Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Output"])()], MonthViewComponent.prototype, "onEventSelected", void 0);
    Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Output"])()], MonthViewComponent.prototype, "onTimeSelected", void 0);
    Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Output"])()], MonthViewComponent.prototype, "onTitleChanged", void 0);
    MonthViewComponent = MonthViewComponent_1 = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
      selector: 'monthview',
      template: "\n        <div>\n            <ion-slides #monthSlider [options]=\"sliderOptions\" [dir]=\"dir\" (ionSlideDidChange)=\"onSlideChanged()\">\n                <ion-slide>\n                    <table *ngIf=\"0===currentViewIndex\" class=\"table table-bordered table-fixed monthview-datetable\">\n                        <thead>\n                        <tr>\n                            <th *ngFor=\"let dayHeader of views[0].dayHeaders\">\n                                <small>{{dayHeader}}</small>\n                            </th>\n                        </tr>\n                        </thead>\n                        <tbody>\n                        <tr *ngFor=\"let row of [0,1,2,3,4,5]\">\n                            <td *ngFor=\"let col of [0,1,2,3,4,5,6]\" tappable (click)=\"select(views[0].dates[row*7+col])\"\n                                [ngClass]=\"getHighlightClass(views[0].dates[row*7+col])\">\n                                <ng-template [ngTemplateOutlet]=\"monthviewDisplayEventTemplate\"\n                                             [ngTemplateOutletContext]=\"{view: views[0], row: row, col: col}\">\n                                </ng-template>\n                            </td>\n                        </tr>\n                        </tbody>\n                    </table>\n                    <table *ngIf=\"0!==currentViewIndex\" class=\"table table-bordered table-fixed monthview-datetable\">\n                        <thead>\n                        <tr class=\"text-center\">\n                            <th *ngFor=\"let dayHeader of views[0].dayHeaders\">\n                                <small>{{dayHeader}}</small>\n                            </th>\n                        </tr>\n                        </thead>\n                        <tbody>\n                        <tr *ngFor=\"let row of [0,1,2,3,4,5]\">\n                            <td *ngFor=\"let col of [0,1,2,3,4,5,6]\">\n                                <ng-template [ngTemplateOutlet]=\"monthviewInactiveDisplayEventTemplate\"\n                                             [ngTemplateOutletContext]=\"{view: views[0], row: row, col: col}\">\n                                </ng-template>\n                            </td>\n                        <tr>\n                        </tbody>\n                    </table>\n                </ion-slide>\n                <ion-slide>\n                    <table *ngIf=\"1===currentViewIndex\" class=\"table table-bordered table-fixed monthview-datetable\">\n                        <thead>\n                        <tr>\n                            <th *ngFor=\"let dayHeader of views[1].dayHeaders\">\n                                <small>{{dayHeader}}</small>\n                            </th>\n                        </tr>\n                        </thead>\n                        <tbody>\n                        <tr *ngFor=\"let row of [0,1,2,3,4,5]\">\n                            <td *ngFor=\"let col of [0,1,2,3,4,5,6]\" tappable (click)=\"select(views[1].dates[row*7+col])\"\n                                [ngClass]=\"getHighlightClass(views[1].dates[row*7+col])\">\n                                <ng-template [ngTemplateOutlet]=\"monthviewDisplayEventTemplate\"\n                                             [ngTemplateOutletContext]=\"{view: views[1], row: row, col: col}\">\n                                </ng-template>\n                            </td>\n                        </tr>\n                        </tbody>\n                    </table>\n                    <table *ngIf=\"1!==currentViewIndex\" class=\"table table-bordered table-fixed monthview-datetable\">\n                        <thead>\n                        <tr class=\"text-center\">\n                            <th *ngFor=\"let dayHeader of views[1].dayHeaders\">\n                                <small>{{dayHeader}}</small>\n                            </th>\n                        </tr>\n                        </thead>\n                        <tbody>\n                        <tr *ngFor=\"let row of [0,1,2,3,4,5]\">\n                            <td *ngFor=\"let col of [0,1,2,3,4,5,6]\">\n                                <ng-template [ngTemplateOutlet]=\"monthviewInactiveDisplayEventTemplate\"\n                                             [ngTemplateOutletContext]=\"{view: views[1], row: row, col: col}\">\n                                </ng-template>\n                            </td>\n                        <tr>\n                        </tbody>\n                    </table>\n                </ion-slide>\n                <ion-slide>\n                    <table *ngIf=\"2===currentViewIndex\" class=\"table table-bordered table-fixed monthview-datetable\">\n                        <thead>\n                        <tr>\n                            <th *ngFor=\"let dayHeader of views[2].dayHeaders\">\n                                <small>{{dayHeader}}</small>\n                            </th>\n                        </tr>\n                        </thead>\n                        <tbody>\n                        <tr *ngFor=\"let row of [0,1,2,3,4,5]\">\n                            <td *ngFor=\"let col of [0,1,2,3,4,5,6]\" tappable (click)=\"select(views[2].dates[row*7+col])\"\n                                [ngClass]=\"getHighlightClass(views[2].dates[row*7+col])\">\n                                <ng-template [ngTemplateOutlet]=\"monthviewDisplayEventTemplate\"\n                                             [ngTemplateOutletContext]=\"{view: views[2], row: row, col: col}\">\n                                </ng-template>\n                            </td>\n                        </tr>\n                        </tbody>\n                    </table>\n                    <table *ngIf=\"2!==currentViewIndex\" class=\"table table-bordered table-fixed monthview-datetable\">\n                        <thead>\n                        <tr class=\"text-center\">\n                            <th *ngFor=\"let dayHeader of views[2].dayHeaders\">\n                                <small>{{dayHeader}}</small>\n                            </th>\n                        </tr>\n                        </thead>\n                        <tbody>\n                        <tr *ngFor=\"let row of [0,1,2,3,4,5]\">\n                            <td *ngFor=\"let col of [0,1,2,3,4,5,6]\">\n                                <ng-template [ngTemplateOutlet]=\"monthviewInactiveDisplayEventTemplate\"\n                                             [ngTemplateOutletContext]=\"{view: views[2], row: row, col: col}\">\n                                </ng-template>\n                            </td>\n                        <tr>\n                        </tbody>\n                    </table>\n                </ion-slide>\n            </ion-slides>\n            <ng-template [ngTemplateOutlet]=\"monthviewEventDetailTemplate\"\n                         [ngTemplateOutletContext]=\"{showEventDetail:showEventDetail, selectedDate: selectedDate, noEventsLabel: noEventsLabel}\">\n            </ng-template>\n        </div>\n    ",
      styles: ["\n        .text-muted {\n            color: #999;\n        }\n\n        .table-fixed {\n            table-layout: fixed;\n        }\n\n        .table {\n            width: 100%;\n            max-width: 100%;\n            background-color: transparent;\n        }\n\n        .table > thead > tr > th, .table > tbody > tr > th, .table > tfoot > tr > th, .table > thead > tr > td,\n        .table > tbody > tr > td, .table > tfoot > tr > td {\n            padding: 8px;\n            line-height: 20px;\n            vertical-align: top;\n        }\n\n        .table > thead > tr > th {\n            vertical-align: bottom;\n            border-bottom: 2px solid #ddd;\n        }\n\n        .table > thead:first-child > tr:first-child > th, .table > thead:first-child > tr:first-child > td {\n            border-top: 0\n        }\n\n        .table > tbody + tbody {\n            border-top: 2px solid #ddd;\n        }\n\n        .table-bordered {\n            border: 1px solid #ddd;\n        }\n\n        .table-bordered > thead > tr > th, .table-bordered > tbody > tr > th, .table-bordered > tfoot > tr > th,\n        .table-bordered > thead > tr > td, .table-bordered > tbody > tr > td, .table-bordered > tfoot > tr > td {\n            border: 1px solid #ddd;\n        }\n\n        .table-bordered > thead > tr > th, .table-bordered > thead > tr > td {\n            border-bottom-width: 2px;\n        }\n\n        .table-striped > tbody > tr:nth-child(odd) > td, .table-striped > tbody > tr:nth-child(odd) > th {\n            background-color: #f9f9f9\n        }\n\n        .monthview-primary-with-event {\n            background-color: #3a87ad;\n            color: white;\n        }\n\n        .monthview-current {\n            background-color: #f0f0f0;\n        }\n\n        .monthview-selected {\n            background-color: #009900;\n            color: white;\n        }\n\n        .monthview-datetable td.monthview-disabled {\n            color: lightgrey;\n            cursor: default;\n        }\n\n        .monthview-datetable th {\n            text-align: center;\n        }\n\n        .monthview-datetable td {\n            cursor: pointer;\n            text-align: center;\n        }\n\n        .monthview-secondary-with-event {\n            background-color: #d9edf7;\n        }\n\n        ::-webkit-scrollbar,\n        *::-webkit-scrollbar {\n            display: none;\n        }\n    "]
    })], MonthViewComponent);
    var WeekViewComponent_1;

    var WeekViewComponent = WeekViewComponent_1 =
    /*#__PURE__*/
    function () {
      function WeekViewComponent(calendarService, elm) {
        _classCallCheck(this, WeekViewComponent);

        this.calendarService = calendarService;
        this.elm = elm;
        this.class = true;
        this.autoSelect = true;
        this.dir = '';
        this.scrollToHour = 0;
        this.onRangeChanged = new _angular_core__WEBPACK_IMPORTED_MODULE_1__["EventEmitter"]();
        this.onEventSelected = new _angular_core__WEBPACK_IMPORTED_MODULE_1__["EventEmitter"]();
        this.onTimeSelected = new _angular_core__WEBPACK_IMPORTED_MODULE_1__["EventEmitter"]();
        this.onTitleChanged = new _angular_core__WEBPACK_IMPORTED_MODULE_1__["EventEmitter"](true);
        this.views = [];
        this.currentViewIndex = 0;
        this.direction = 0;
        this.mode = 'week';
        this.inited = false;
        this.callbackOnInit = true;
      }

      _createClass(WeekViewComponent, [{
        key: "ngOnInit",
        value: function ngOnInit() {
          var _this3 = this;

          if (!this.sliderOptions) {
            this.sliderOptions = {};
          }

          this.sliderOptions.loop = true;
          this.hourRange = (this.endHour - this.startHour) * this.hourSegments;

          if (this.dateFormatter && this.dateFormatter.formatWeekViewDayHeader) {
            this.formatDayHeader = this.dateFormatter.formatWeekViewDayHeader;
          } else {
            var datePipe = new _angular_common__WEBPACK_IMPORTED_MODULE_2__["DatePipe"](this.locale);

            this.formatDayHeader = function (date) {
              return datePipe.transform(date, this.formatWeekViewDayHeader);
            };
          }

          if (this.dateFormatter && this.dateFormatter.formatWeekViewTitle) {
            this.formatTitle = this.dateFormatter.formatWeekViewTitle;
          } else {
            var _datePipe2 = new _angular_common__WEBPACK_IMPORTED_MODULE_2__["DatePipe"](this.locale);

            this.formatTitle = function (date) {
              return _datePipe2.transform(date, this.formatWeekTitle);
            };
          }

          if (this.dateFormatter && this.dateFormatter.formatWeekViewHourColumn) {
            this.formatHourColumnLabel = this.dateFormatter.formatWeekViewHourColumn;
          } else {
            var _datePipe3 = new _angular_common__WEBPACK_IMPORTED_MODULE_2__["DatePipe"](this.locale);

            this.formatHourColumnLabel = function (date) {
              return _datePipe3.transform(date, this.formatHourColumn);
            };
          }

          if (this.lockSwipeToPrev) {
            this.slider.lockSwipeToPrev(true);
          }

          if (this.lockSwipes) {
            this.slider.lockSwipes(true);
          }

          this.refreshView();
          this.hourColumnLabels = this.getHourColumnLabels();
          this.inited = true;
          this.currentDateChangedFromParentSubscription = this.calendarService.currentDateChangedFromParent$.subscribe(function (currentDate) {
            _this3.refreshView();
          });
          this.eventSourceChangedSubscription = this.calendarService.eventSourceChanged$.subscribe(function () {
            _this3.onDataLoaded();
          });
          this.slideChangedSubscription = this.calendarService.slideChanged$.subscribe(function (direction) {
            if (direction === 1) {
              _this3.slider.slideNext();
            } else if (direction === -1) {
              _this3.slider.slidePrev();
            }
          });
        }
      }, {
        key: "ngAfterViewInit",
        value: function ngAfterViewInit() {
          var title = this.getTitle();
          this.onTitleChanged.emit(title);

          if (this.scrollToHour > 0) {
            var hourColumns = this.elm.nativeElement.querySelector('.weekview-normal-event-container').querySelectorAll('.calendar-hour-column');
            var me = this;
            setTimeout(function () {
              me.initScrollPosition = hourColumns[me.scrollToHour - me.startHour].offsetTop;
            }, 50);
          }
        }
      }, {
        key: "ngOnChanges",
        value: function ngOnChanges(changes) {
          if (!this.inited) {
            return;
          }

          var eventSourceChange = changes.eventSource;

          if (eventSourceChange && eventSourceChange.currentValue) {
            this.onDataLoaded();
          }

          var lockSwipeToPrev = changes.lockSwipeToPrev;

          if (lockSwipeToPrev) {
            this.slider.lockSwipeToPrev(lockSwipeToPrev.currentValue);
          }

          var lockSwipes = changes.lockSwipes;

          if (lockSwipes) {
            this.slider.lockSwipes(lockSwipes.currentValue);
          }
        }
      }, {
        key: "ngOnDestroy",
        value: function ngOnDestroy() {
          if (this.currentDateChangedFromParentSubscription) {
            this.currentDateChangedFromParentSubscription.unsubscribe();
            this.currentDateChangedFromParentSubscription = null;
          }

          if (this.eventSourceChangedSubscription) {
            this.eventSourceChangedSubscription.unsubscribe();
            this.eventSourceChangedSubscription = null;
          }

          if (this.slideChangedSubscription) {
            this.slideChangedSubscription.unsubscribe();
            this.slideChangedSubscription = null;
          }
        }
      }, {
        key: "onSlideChanged",
        value: function onSlideChanged() {
          var _this4 = this;

          if (this.callbackOnInit) {
            this.callbackOnInit = false;
            return;
          }

          var currentViewIndex = this.currentViewIndex;
          var direction = 0;
          this.slider.getActiveIndex().then(function (currentSlideIndex) {
            currentSlideIndex = (currentSlideIndex + 2) % 3;

            if (isNaN(currentSlideIndex)) {
              currentSlideIndex = currentViewIndex;
            }

            if (currentSlideIndex - currentViewIndex === 1) {
              direction = 1;
            } else if (currentSlideIndex === 0 && currentViewIndex === 2) {
              direction = 1;

              _this4.slider.slideTo(1, 0, false);
            } else if (currentViewIndex - currentSlideIndex === 1) {
              direction = -1;
            } else if (currentSlideIndex === 2 && currentViewIndex === 0) {
              direction = -1;

              _this4.slider.slideTo(3, 0, false);
            }

            _this4.currentViewIndex = currentSlideIndex;

            _this4.move(direction);
          });
        }
      }, {
        key: "move",
        value: function move(direction) {
          if (direction === 0) {
            return;
          }

          this.direction = direction;
          var adjacent = this.calendarService.getAdjacentCalendarDate(this.mode, direction);
          this.calendarService.setCurrentDate(adjacent);
          this.refreshView();
          this.direction = 0;
        }
      }, {
        key: "getHourColumnLabels",
        value: function getHourColumnLabels() {
          var hourColumnLabels = [];

          for (var hour = 0, length = this.views[0].rows.length; hour < length; hour += 1) {
            // handle edge case for DST
            if (hour === 0 && this.views[0].rows[hour][0].time.getHours() !== this.startHour) {
              var time = new Date(this.views[0].rows[hour][0].time);
              time.setDate(time.getDate() + 1);
              time.setHours(this.startHour);
              hourColumnLabels.push(this.formatHourColumnLabel(time));
            } else {
              hourColumnLabels.push(this.formatHourColumnLabel(this.views[0].rows[hour][0].time));
            }
          }

          return hourColumnLabels;
        }
      }, {
        key: "getViewData",
        value: function getViewData(startTime) {
          var dates = WeekViewComponent_1.getDates(startTime, 7);

          for (var i = 0; i < 7; i++) {
            dates[i].dayHeader = this.formatDayHeader(dates[i].date);
          }

          return {
            rows: WeekViewComponent_1.createDateObjects(startTime, this.startHour, this.endHour, this.hourSegments),
            dates: dates
          };
        }
      }, {
        key: "getRange",
        value: function getRange(currentDate) {
          var year = currentDate.getFullYear(),
              month = currentDate.getMonth(),
              date = currentDate.getDate(),
              day = currentDate.getDay();
          var difference = day - this.startingDayWeek;

          if (difference < 0) {
            difference += 7;
          } // set hour to 12 to avoid DST problem


          var firstDayOfWeek = new Date(year, month, date - difference, 12, 0, 0),
              endTime = new Date(year, month, date - difference + 7, 12, 0, 0);
          return {
            startTime: firstDayOfWeek,
            endTime: endTime
          };
        }
      }, {
        key: "onDataLoaded",
        value: function onDataLoaded() {
          var eventSource = this.eventSource,
              len = eventSource ? eventSource.length : 0,
              startTime = this.range.startTime,
              endTime = this.range.endTime,
              utcStartTime = Date.UTC(startTime.getFullYear(), startTime.getMonth(), startTime.getDate()),
              utcEndTime = Date.UTC(endTime.getFullYear(), endTime.getMonth(), endTime.getDate()),
              currentViewIndex = this.currentViewIndex,
              rows = this.views[currentViewIndex].rows,
              dates = this.views[currentViewIndex].dates,
              oneHour = 3600000,
              oneDay = 86400000,
              // add allday eps
          eps = 0.016,
              rangeStartRowIndex = this.startHour * this.hourSegments,
              rangeEndRowIndex = this.endHour * this.hourSegments,
              allRows = 24 * this.hourSegments;
          var allDayEventInRange = false,
              normalEventInRange = false;

          for (var i = 0; i < 7; i += 1) {
            dates[i].events = [];
            dates[i].hasEvent = false;
          }

          for (var day = 0; day < 7; day += 1) {
            for (var hour = 0; hour < this.hourRange; hour += 1) {
              rows[hour][day].events = [];
            }
          }

          for (var _i2 = 0; _i2 < len; _i2 += 1) {
            var event = eventSource[_i2];
            var eventStartTime = event.startTime;
            var eventEndTime = event.endTime;
            var eventUTCStartTime = void 0,
                eventUTCEndTime = void 0;

            if (event.allDay) {
              eventUTCStartTime = eventStartTime.getTime();
              eventUTCEndTime = eventEndTime.getTime();
            } else {
              eventUTCStartTime = Date.UTC(eventStartTime.getFullYear(), eventStartTime.getMonth(), eventStartTime.getDate());
              eventUTCEndTime = Date.UTC(eventEndTime.getFullYear(), eventEndTime.getMonth(), eventEndTime.getDate() + 1);
            }

            if (eventUTCEndTime <= utcStartTime || eventUTCStartTime >= utcEndTime || eventStartTime >= eventEndTime) {
              continue;
            }

            if (event.allDay) {
              allDayEventInRange = true;
              var allDayStartIndex = void 0;

              if (eventUTCStartTime <= utcStartTime) {
                allDayStartIndex = 0;
              } else {
                allDayStartIndex = Math.round((eventUTCStartTime - utcStartTime) / oneDay);
              }

              var allDayEndIndex = void 0;

              if (eventUTCEndTime >= utcEndTime) {
                allDayEndIndex = Math.round((utcEndTime - utcStartTime) / oneDay);
              } else {
                allDayEndIndex = Math.round((eventUTCEndTime - utcStartTime) / oneDay);
              }

              var displayAllDayEvent = {
                event: event,
                startIndex: allDayStartIndex,
                endIndex: allDayEndIndex
              };
              var eventSet = dates[allDayStartIndex].events;

              if (eventSet) {
                eventSet.push(displayAllDayEvent);
              } else {
                eventSet = [];
                eventSet.push(displayAllDayEvent);
                dates[allDayStartIndex].events = eventSet;
              }

              dates[allDayStartIndex].hasEvent = true;
            } else {
              normalEventInRange = true;
              var timeDifferenceStart = void 0;

              if (eventUTCStartTime < utcStartTime) {
                timeDifferenceStart = 0;
              } else {
                timeDifferenceStart = (eventUTCStartTime - utcStartTime) / oneHour * this.hourSegments + (eventStartTime.getHours() + eventStartTime.getMinutes() / 60) * this.hourSegments;
              }

              var timeDifferenceEnd = void 0;

              if (eventUTCEndTime > utcEndTime) {
                timeDifferenceEnd = (utcEndTime - utcStartTime) / oneHour * this.hourSegments;
              } else {
                timeDifferenceEnd = (eventUTCEndTime - oneDay - utcStartTime) / oneHour * this.hourSegments + (eventEndTime.getHours() + eventEndTime.getMinutes() / 60) * this.hourSegments;
              }

              var startIndex = Math.floor(timeDifferenceStart),
                  endIndex = Math.ceil(timeDifferenceEnd - eps);
              var startRowIndex = startIndex % allRows,
                  dayIndex = Math.floor(startIndex / allRows),
                  endOfDay = dayIndex * allRows,
                  startOffset = 0,
                  endOffset = 0;

              if (this.hourParts !== 1) {
                if (startRowIndex < rangeStartRowIndex) {
                  startOffset = 0;
                } else {
                  startOffset = Math.floor((timeDifferenceStart - startIndex) * this.hourParts);
                }
              }

              do {
                endOfDay += allRows;
                var endRowIndex = void 0;

                if (endOfDay < endIndex) {
                  endRowIndex = allRows;
                } else {
                  if (endOfDay === endIndex) {
                    endRowIndex = allRows;
                  } else {
                    endRowIndex = endIndex % allRows;
                  }

                  if (this.hourParts !== 1) {
                    if (endRowIndex > rangeEndRowIndex) {
                      endOffset = 0;
                    } else {
                      endOffset = Math.floor((endIndex - timeDifferenceEnd) * this.hourParts);
                    }
                  }
                }

                if (startRowIndex < rangeStartRowIndex) {
                  startRowIndex = 0;
                } else {
                  startRowIndex -= rangeStartRowIndex;
                }

                if (endRowIndex > rangeEndRowIndex) {
                  endRowIndex = rangeEndRowIndex;
                }

                endRowIndex -= rangeStartRowIndex;

                if (startRowIndex < endRowIndex) {
                  var displayEvent = {
                    event: event,
                    startIndex: startRowIndex,
                    endIndex: endRowIndex,
                    startOffset: startOffset,
                    endOffset: endOffset
                  };
                  var _eventSet = rows[startRowIndex][dayIndex].events;

                  if (_eventSet) {
                    _eventSet.push(displayEvent);
                  } else {
                    _eventSet = [];

                    _eventSet.push(displayEvent);

                    rows[startRowIndex][dayIndex].events = _eventSet;
                  }

                  dates[dayIndex].hasEvent = true;
                }

                startRowIndex = 0;
                startOffset = 0;
                dayIndex += 1;
              } while (endOfDay < endIndex);
            }
          }

          if (normalEventInRange) {
            for (var _day = 0; _day < 7; _day += 1) {
              var orderedEvents = [];

              for (var _hour = 0; _hour < this.hourRange; _hour += 1) {
                if (rows[_hour][_day].events) {
                  rows[_hour][_day].events.sort(WeekViewComponent_1.compareEventByStartOffset);

                  orderedEvents = orderedEvents.concat(rows[_hour][_day].events);
                }
              }

              if (orderedEvents.length > 0) {
                this.placeEvents(orderedEvents);
              }
            }
          }

          if (allDayEventInRange) {
            var orderedAllDayEvents = [];

            for (var _day2 = 0; _day2 < 7; _day2 += 1) {
              if (dates[_day2].events) {
                orderedAllDayEvents = orderedAllDayEvents.concat(dates[_day2].events);
              }
            }

            if (orderedAllDayEvents.length > 0) {
              this.placeAllDayEvents(orderedAllDayEvents);
            }
          }

          if (this.autoSelect) {
            var findSelected = false;
            var selectedDate;

            for (var r = 0; r < 7; r += 1) {
              if (dates[r].selected) {
                selectedDate = dates[r];
                findSelected = true;
                break;
              }
            }

            if (findSelected) {
              var disabled = false;

              if (this.markDisabled) {
                disabled = this.markDisabled(selectedDate.date);
              }

              this.onTimeSelected.emit({
                selectedTime: selectedDate.date,
                events: selectedDate.events.map(function (e) {
                  return e.event;
                }),
                disabled: disabled
              });
            }
          }
        }
      }, {
        key: "refreshView",
        value: function refreshView() {
          this.range = this.getRange(this.calendarService.currentDate);

          if (this.inited) {
            var title = this.getTitle();
            this.onTitleChanged.emit(title);
          }

          this.calendarService.populateAdjacentViews(this);
          this.updateCurrentView(this.range.startTime, this.views[this.currentViewIndex]);
          this.calendarService.rangeChanged(this);
        }
      }, {
        key: "getTitle",
        value: function getTitle() {
          var firstDayOfWeek = new Date(this.range.startTime.getTime());
          firstDayOfWeek.setHours(12, 0, 0, 0);
          return this.formatTitle(firstDayOfWeek);
        }
      }, {
        key: "getHighlightClass",
        value: function getHighlightClass(date) {
          var className = '';

          if (date.hasEvent) {
            if (className) {
              className += ' ';
            }

            className = 'weekview-with-event';
          }

          if (date.selected) {
            if (className) {
              className += ' ';
            }

            className += 'weekview-selected';
          }

          if (date.current) {
            if (className) {
              className += ' ';
            }

            className += 'weekview-current';
          }

          return className;
        }
      }, {
        key: "select",
        value: function select(selectedTime, events) {
          var disabled = false;

          if (this.markDisabled) {
            disabled = this.markDisabled(selectedTime);
          }

          this.onTimeSelected.emit({
            selectedTime: selectedTime,
            events: events.map(function (e) {
              return e.event;
            }),
            disabled: disabled
          });
        }
      }, {
        key: "placeEvents",
        value: function placeEvents(orderedEvents) {
          this.calculatePosition(orderedEvents);
          WeekViewComponent_1.calculateWidth(orderedEvents, this.hourRange, this.hourParts);
        }
      }, {
        key: "placeAllDayEvents",
        value: function placeAllDayEvents(orderedEvents) {
          this.calculatePosition(orderedEvents);
        }
      }, {
        key: "overlap",
        value: function overlap(event1, event2) {
          var earlyEvent = event1,
              lateEvent = event2;

          if (event1.startIndex > event2.startIndex || event1.startIndex === event2.startIndex && event1.startOffset > event2.startOffset) {
            earlyEvent = event2;
            lateEvent = event1;
          }

          if (earlyEvent.endIndex <= lateEvent.startIndex) {
            return false;
          } else {
            return !(earlyEvent.endIndex - lateEvent.startIndex === 1 && earlyEvent.endOffset + lateEvent.startOffset >= this.hourParts);
          }
        }
      }, {
        key: "calculatePosition",
        value: function calculatePosition(events) {
          var len = events.length,
              isForbidden = new Array(len);
          var maxColumn = 0;

          for (var i = 0; i < len; i += 1) {
            var col = void 0;

            for (col = 0; col < maxColumn; col += 1) {
              isForbidden[col] = false;
            }

            for (var j = 0; j < i; j += 1) {
              if (this.overlap(events[i], events[j])) {
                isForbidden[events[j].position] = true;
              }
            }

            for (col = 0; col < maxColumn; col += 1) {
              if (!isForbidden[col]) {
                break;
              }
            }

            if (col < maxColumn) {
              events[i].position = col;
            } else {
              events[i].position = maxColumn++;
            }
          }

          if (this.dir === 'rtl') {
            for (var _i3 = 0; _i3 < len; _i3 += 1) {
              events[_i3].position = maxColumn - 1 - events[_i3].position;
            }
          }
        }
      }, {
        key: "updateCurrentView",
        value: function updateCurrentView(currentViewStartDate, view) {
          var currentCalendarDate = this.calendarService.currentDate,
              today = new Date(),
              oneDay = 86400000,
              selectedDayDifference = Math.round((Date.UTC(currentCalendarDate.getFullYear(), currentCalendarDate.getMonth(), currentCalendarDate.getDate()) - Date.UTC(currentViewStartDate.getFullYear(), currentViewStartDate.getMonth(), currentViewStartDate.getDate())) / oneDay),
              currentDayDifference = Math.floor((Date.UTC(today.getFullYear(), today.getMonth(), today.getTime()) - Date.UTC(currentViewStartDate.getFullYear(), currentViewStartDate.getMonth(), currentViewStartDate.getDate())) / oneDay);

          for (var r = 0; r < 7; r += 1) {
            view.dates[r].selected = false;
          }

          if (selectedDayDifference >= 0 && selectedDayDifference < 7 && this.autoSelect) {
            view.dates[selectedDayDifference].selected = true;
          }

          if (currentDayDifference >= 0 && currentDayDifference < 7) {
            view.dates[currentDayDifference].current = true;
          }
        }
      }, {
        key: "daySelected",
        value: function daySelected(viewDate) {
          var selectedDate = viewDate.date,
              dates = this.views[this.currentViewIndex].dates,
              currentViewStartDate = this.range.startTime,
              oneDay = 86400000,
              selectedDayDifference = Math.round((Date.UTC(selectedDate.getFullYear(), selectedDate.getMonth(), selectedDate.getDate()) - Date.UTC(currentViewStartDate.getFullYear(), currentViewStartDate.getMonth(), currentViewStartDate.getDate())) / oneDay);
          this.calendarService.setCurrentDate(selectedDate);

          for (var r = 0; r < 7; r += 1) {
            dates[r].selected = false;
          }

          if (selectedDayDifference >= 0 && selectedDayDifference < 7) {
            dates[selectedDayDifference].selected = true;
          }

          var disabled = false;

          if (this.markDisabled) {
            disabled = this.markDisabled(selectedDate);
          }

          this.onTimeSelected.emit({
            selectedTime: selectedDate,
            events: viewDate.events.map(function (e) {
              return e.event;
            }),
            disabled: disabled
          });
        }
      }, {
        key: "setScrollPosition",
        value: function setScrollPosition(scrollPosition) {
          this.initScrollPosition = scrollPosition;
        }
      }], [{
        key: "createDateObjects",
        value: function createDateObjects(startTime, startHour, endHour, timeInterval) {
          var times = [],
              currentHour = 0,
              currentDate = startTime.getDate();
          var hourStep, minStep;

          if (timeInterval < 1) {
            hourStep = Math.floor(1 / timeInterval);
            minStep = 60;
          } else {
            hourStep = 1;
            minStep = Math.floor(60 / timeInterval);
          }

          for (var hour = startHour; hour < endHour; hour += hourStep) {
            for (var interval = 0; interval < 60; interval += minStep) {
              var row = [];

              for (var day = 0; day < 7; day += 1) {
                var time = new Date(startTime.getTime());
                time.setHours(currentHour + hour, interval);
                time.setDate(currentDate + day);
                row.push({
                  events: [],
                  time: time
                });
              }

              times.push(row);
            }
          }

          return times;
        }
      }, {
        key: "getDates",
        value: function getDates(startTime, n) {
          var dates = new Array(n),
              current = new Date(startTime.getTime());
          var i = 0;

          while (i < n) {
            dates[i++] = {
              date: new Date(current.getTime()),
              events: [],
              dayHeader: ''
            };
            current.setDate(current.getDate() + 1);
          }

          return dates;
        }
      }, {
        key: "compareEventByStartOffset",
        value: function compareEventByStartOffset(eventA, eventB) {
          return eventA.startOffset - eventB.startOffset;
        }
      }, {
        key: "calculateWidth",
        value: function calculateWidth(orderedEvents, size, hourParts) {
          var totalSize = size * hourParts,
              cells = new Array(totalSize); // sort by position in descending order, the right most columns should be calculated first

          orderedEvents.sort(function (eventA, eventB) {
            return eventB.position - eventA.position;
          });

          for (var _i4 = 0; _i4 < totalSize; _i4 += 1) {
            cells[_i4] = {
              calculated: false,
              events: []
            };
          }

          var len = orderedEvents.length;

          for (var _i5 = 0; _i5 < len; _i5 += 1) {
            var event = orderedEvents[_i5];
            var index = event.startIndex * hourParts + event.startOffset;

            while (index < event.endIndex * hourParts - event.endOffset) {
              cells[index].events.push(event);
              index += 1;
            }
          }

          var i = 0;

          while (i < len) {
            var _event = orderedEvents[i];

            if (!_event.overlapNumber) {
              var overlapNumber = _event.position + 1;
              _event.overlapNumber = overlapNumber;
              var eventQueue = [_event];

              while (_event = eventQueue.shift()) {
                var _index = _event.startIndex * hourParts + _event.startOffset;

                while (_index < _event.endIndex * hourParts - _event.endOffset) {
                  if (!cells[_index].calculated) {
                    cells[_index].calculated = true;

                    if (cells[_index].events) {
                      var eventCountInCell = cells[_index].events.length;

                      for (var j = 0; j < eventCountInCell; j += 1) {
                        var currentEventInCell = cells[_index].events[j];

                        if (!currentEventInCell.overlapNumber) {
                          currentEventInCell.overlapNumber = overlapNumber;
                          eventQueue.push(currentEventInCell);
                        }
                      }
                    }
                  }

                  _index += 1;
                }
              }
            }

            i += 1;
          }
        }
      }]);

      return WeekViewComponent;
    }();

    WeekViewComponent.ctorParameters = function () {
      return [{
        type: CalendarService
      }, {
        type: _angular_core__WEBPACK_IMPORTED_MODULE_1__["ElementRef"]
      }];
    };

    Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["ViewChild"])('weekSlider', {
      static: true
    })], WeekViewComponent.prototype, "slider", void 0);
    Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["HostBinding"])('class.weekview')], WeekViewComponent.prototype, "class", void 0);
    Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Input"])()], WeekViewComponent.prototype, "weekviewHeaderTemplate", void 0);
    Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Input"])()], WeekViewComponent.prototype, "weekviewAllDayEventTemplate", void 0);
    Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Input"])()], WeekViewComponent.prototype, "weekviewNormalEventTemplate", void 0);
    Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Input"])()], WeekViewComponent.prototype, "weekviewAllDayEventSectionTemplate", void 0);
    Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Input"])()], WeekViewComponent.prototype, "weekviewNormalEventSectionTemplate", void 0);
    Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Input"])()], WeekViewComponent.prototype, "weekviewInactiveAllDayEventSectionTemplate", void 0);
    Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Input"])()], WeekViewComponent.prototype, "weekviewInactiveNormalEventSectionTemplate", void 0);
    Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Input"])()], WeekViewComponent.prototype, "formatWeekTitle", void 0);
    Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Input"])()], WeekViewComponent.prototype, "formatWeekViewDayHeader", void 0);
    Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Input"])()], WeekViewComponent.prototype, "formatHourColumn", void 0);
    Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Input"])()], WeekViewComponent.prototype, "startingDayWeek", void 0);
    Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Input"])()], WeekViewComponent.prototype, "allDayLabel", void 0);
    Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Input"])()], WeekViewComponent.prototype, "hourParts", void 0);
    Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Input"])()], WeekViewComponent.prototype, "eventSource", void 0);
    Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Input"])()], WeekViewComponent.prototype, "autoSelect", void 0);
    Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Input"])()], WeekViewComponent.prototype, "markDisabled", void 0);
    Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Input"])()], WeekViewComponent.prototype, "locale", void 0);
    Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Input"])()], WeekViewComponent.prototype, "dateFormatter", void 0);
    Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Input"])()], WeekViewComponent.prototype, "dir", void 0);
    Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Input"])()], WeekViewComponent.prototype, "scrollToHour", void 0);
    Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Input"])()], WeekViewComponent.prototype, "preserveScrollPosition", void 0);
    Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Input"])()], WeekViewComponent.prototype, "lockSwipeToPrev", void 0);
    Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Input"])()], WeekViewComponent.prototype, "lockSwipes", void 0);
    Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Input"])()], WeekViewComponent.prototype, "startHour", void 0);
    Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Input"])()], WeekViewComponent.prototype, "endHour", void 0);
    Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Input"])()], WeekViewComponent.prototype, "sliderOptions", void 0);
    Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Input"])()], WeekViewComponent.prototype, "hourSegments", void 0);
    Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Output"])()], WeekViewComponent.prototype, "onRangeChanged", void 0);
    Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Output"])()], WeekViewComponent.prototype, "onEventSelected", void 0);
    Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Output"])()], WeekViewComponent.prototype, "onTimeSelected", void 0);
    Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Output"])()], WeekViewComponent.prototype, "onTitleChanged", void 0);
    WeekViewComponent = WeekViewComponent_1 = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
      selector: 'weekview',
      template: "\n        <ion-slides #weekSlider [options]=\"sliderOptions\" [dir]=\"dir\" (ionSlideDidChange)=\"onSlideChanged()\"\n                    class=\"slides-container\">\n            <ion-slide class=\"slide-container\">\n                <table class=\"table table-bordered table-fixed weekview-header\">\n                    <thead>\n                    <tr>\n                        <th class=\"calendar-hour-column\"></th>\n                        <th class=\"weekview-header text-center\" *ngFor=\"let date of views[0].dates\"\n                            [ngClass]=\"getHighlightClass(date)\"\n                            (click)=\"daySelected(date)\">\n                            <ng-template [ngTemplateOutlet]=\"weekviewHeaderTemplate\"\n                                         [ngTemplateOutletContext]=\"{viewDate:date}\">\n                            </ng-template>\n                        </th>\n                    </tr>\n                    </thead>\n                </table>\n                <div *ngIf=\"0===currentViewIndex\">\n                    <div class=\"weekview-allday-table\">\n                        <div class=\"weekview-allday-label\">{{allDayLabel}}</div>\n                        <div class=\"weekview-allday-content-wrapper scroll-content\">\n                            <table class=\"table table-fixed weekview-allday-content-table\">\n                                <tbody>\n                                <tr>\n                                    <td *ngFor=\"let day of views[0].dates\" class=\"calendar-cell\">\n                                        <ng-template [ngTemplateOutlet]=\"weekviewAllDayEventSectionTemplate\"\n                                                     [ngTemplateOutletContext]=\"{day:day, eventTemplate:weekviewAllDayEventTemplate}\">\n                                        </ng-template>\n                                    </td>\n                                </tr>\n                                </tbody>\n                            </table>\n                        </div>\n                    </div>\n                    <init-position-scroll class=\"weekview-normal-event-container\" [initPosition]=\"initScrollPosition\"\n                                          [emitEvent]=\"preserveScrollPosition\" (onScroll)=\"setScrollPosition($event)\">\n                        <table class=\"table table-bordered table-fixed weekview-normal-event-table\">\n                            <tbody>\n                            <tr *ngFor=\"let row of views[0].rows; let i = index\">\n                                <td class=\"calendar-hour-column text-center\">\n                                    {{hourColumnLabels[i]}}\n                                </td>\n                                <td *ngFor=\"let tm of row\" class=\"calendar-cell\" tappable\n                                    (click)=\"select(tm.time, tm.events)\">\n                                    <ng-template [ngTemplateOutlet]=\"weekviewNormalEventSectionTemplate\"\n                                                 [ngTemplateOutletContext]=\"{tm:tm, hourParts: hourParts, eventTemplate:weekviewNormalEventTemplate}\">\n                                    </ng-template>\n                                </td>\n                            </tr>\n                            </tbody>\n                        </table>\n                    </init-position-scroll>\n                </div>\n                <div *ngIf=\"0!==currentViewIndex\">\n                    <div class=\"weekview-allday-table\">\n                        <div class=\"weekview-allday-label\">{{allDayLabel}}</div>\n                        <div class=\"weekview-allday-content-wrapper scroll-content\">\n                            <table class=\"table table-fixed weekview-allday-content-table\">\n                                <tbody>\n                                <tr>\n                                    <td *ngFor=\"let day of views[0].dates\" class=\"calendar-cell\">\n                                        <ng-template [ngTemplateOutlet]=\"weekviewInactiveAllDayEventSectionTemplate\"\n                                                     [ngTemplateOutletContext]=\"{day:day}\">\n                                        </ng-template>\n                                    </td>\n                                </tr>\n                                </tbody>\n                            </table>\n                        </div>\n                    </div>\n                    <init-position-scroll class=\"weekview-normal-event-container\" [initPosition]=\"initScrollPosition\">\n                        <table class=\"table table-bordered table-fixed weekview-normal-event-table\">\n                            <tbody>\n                            <tr *ngFor=\"let row of views[0].rows; let i = index\">\n                                <td class=\"calendar-hour-column text-center\">\n                                    {{hourColumnLabels[i]}}\n                                </td>\n                                <td *ngFor=\"let tm of row\" class=\"calendar-cell\">\n                                    <ng-template [ngTemplateOutlet]=\"weekviewInactiveNormalEventSectionTemplate\"\n                                                 [ngTemplateOutletContext]=\"{tm:tm, hourParts: hourParts}\">\n                                    </ng-template>\n                                </td>\n                            </tr>\n                            </tbody>\n                        </table>\n                    </init-position-scroll>\n                </div>\n            </ion-slide>\n            <ion-slide class=\"slide-container\">\n                <table class=\"table table-bordered table-fixed weekview-header\">\n                    <thead>\n                    <tr>\n                        <th class=\"calendar-hour-column\"></th>\n                        <th class=\"weekview-header text-center\" *ngFor=\"let date of views[1].dates\"\n                            [ngClass]=\"getHighlightClass(date)\"\n                            (click)=\"daySelected(date)\">\n                            <ng-template [ngTemplateOutlet]=\"weekviewHeaderTemplate\"\n                                         [ngTemplateOutletContext]=\"{viewDate:date}\">\n                            </ng-template>\n                        </th>\n                    </tr>\n                    </thead>\n                </table>\n                <div *ngIf=\"1===currentViewIndex\">\n                    <div class=\"weekview-allday-table\">\n                        <div class=\"weekview-allday-label\">{{allDayLabel}}</div>\n                        <div class=\"weekview-allday-content-wrapper scroll-content\">\n                            <table class=\"table table-fixed weekview-allday-content-table\">\n                                <tbody>\n                                <tr>\n                                    <td *ngFor=\"let day of views[1].dates\" class=\"calendar-cell\">\n                                        <ng-template [ngTemplateOutlet]=\"weekviewAllDayEventSectionTemplate\"\n                                                     [ngTemplateOutletContext]=\"{day:day, eventTemplate:weekviewAllDayEventTemplate}\">\n                                        </ng-template>\n                                    </td>\n                                </tr>\n                                </tbody>\n                            </table>\n                        </div>\n                    </div>\n                    <init-position-scroll class=\"weekview-normal-event-container\" [initPosition]=\"initScrollPosition\"\n                                          [emitEvent]=\"preserveScrollPosition\" (onScroll)=\"setScrollPosition($event)\">\n                        <table class=\"table table-bordered table-fixed weekview-normal-event-table\">\n                            <tbody>\n                            <tr *ngFor=\"let row of views[1].rows; let i = index\">\n                                <td class=\"calendar-hour-column text-center\">\n                                    {{hourColumnLabels[i]}}\n                                </td>\n                                <td *ngFor=\"let tm of row\" class=\"calendar-cell\" tappable\n                                    (click)=\"select(tm.time, tm.events)\">\n                                    <div [ngClass]=\"{'calendar-event-wrap': tm.events}\" *ngIf=\"tm.events\">\n                                        <ng-template [ngTemplateOutlet]=\"weekviewNormalEventSectionTemplate\"\n                                                     [ngTemplateOutletContext]=\"{tm:tm, hourParts: hourParts, eventTemplate:weekviewNormalEventTemplate}\">\n                                        </ng-template>\n                                    </div>\n                                </td>\n                            </tr>\n                            </tbody>\n                        </table>\n                    </init-position-scroll>\n                </div>\n                <div *ngIf=\"1!==currentViewIndex\">\n                    <div class=\"weekview-allday-table\">\n                        <div class=\"weekview-allday-label\">{{allDayLabel}}</div>\n                        <div class=\"weekview-allday-content-wrapper scroll-content\">\n                            <table class=\"table table-fixed weekview-allday-content-table\">\n                                <tbody>\n                                <tr>\n                                    <td *ngFor=\"let day of views[1].dates\" class=\"calendar-cell\">\n                                        <ng-template [ngTemplateOutlet]=\"weekviewInactiveAllDayEventSectionTemplate\"\n                                                     [ngTemplateOutletContext]=\"{day:day}\">\n                                        </ng-template>\n                                    </td>\n                                </tr>\n                                </tbody>\n                            </table>\n                        </div>\n                    </div>\n                    <init-position-scroll class=\"weekview-normal-event-container\" [initPosition]=\"initScrollPosition\">\n                        <table class=\"table table-bordered table-fixed weekview-normal-event-table\">\n                            <tbody>\n                            <tr *ngFor=\"let row of views[1].rows; let i = index\">\n                                <td class=\"calendar-hour-column text-center\">\n                                    {{hourColumnLabels[i]}}\n                                </td>\n                                <td *ngFor=\"let tm of row\" class=\"calendar-cell\">\n                                    <div [ngClass]=\"{'calendar-event-wrap': tm.events}\" *ngIf=\"tm.events\">\n                                        <ng-template [ngTemplateOutlet]=\"weekviewInactiveNormalEventSectionTemplate\"\n                                                     [ngTemplateOutletContext]=\"{tm:tm, hourParts: hourParts}\">\n                                        </ng-template>\n                                    </div>\n                                </td>\n                            </tr>\n                            </tbody>\n                        </table>\n                    </init-position-scroll>\n                </div>\n            </ion-slide>\n            <ion-slide class=\"slide-container\">\n                <table class=\"table table-bordered table-fixed weekview-header\">\n                    <thead>\n                    <tr>\n                        <th class=\"calendar-hour-column\"></th>\n                        <th class=\"weekview-header text-center\" *ngFor=\"let date of views[2].dates\"\n                            [ngClass]=\"getHighlightClass(date)\"\n                            (click)=\"daySelected(date)\">\n                            <ng-template [ngTemplateOutlet]=\"weekviewHeaderTemplate\"\n                                         [ngTemplateOutletContext]=\"{viewDate:date}\">\n                            </ng-template>\n                        </th>\n                    </tr>\n                    </thead>\n                </table>\n                <div *ngIf=\"2===currentViewIndex\">\n                    <div class=\"weekview-allday-table\">\n                        <div class=\"weekview-allday-label\">{{allDayLabel}}</div>\n                        <div class=\"weekview-allday-content-wrapper scroll-content\">\n                            <table class=\"table table-fixed weekview-allday-content-table\">\n                                <tbody>\n                                <tr>\n                                    <td *ngFor=\"let day of views[2].dates\" class=\"calendar-cell\">\n                                        <ng-template [ngTemplateOutlet]=\"weekviewAllDayEventSectionTemplate\"\n                                                     [ngTemplateOutletContext]=\"{day:day, eventTemplate:weekviewAllDayEventTemplate}\">\n                                        </ng-template>\n                                    </td>\n                                </tr>\n                                </tbody>\n                            </table>\n                        </div>\n                    </div>\n                    <init-position-scroll class=\"weekview-normal-event-container\" [initPosition]=\"initScrollPosition\"\n                                          [emitEvent]=\"preserveScrollPosition\" (onScroll)=\"setScrollPosition($event)\">\n                        <table class=\"table table-bordered table-fixed weekview-normal-event-table\">\n                            <tbody>\n                            <tr *ngFor=\"let row of views[2].rows; let i = index\">\n                                <td class=\"calendar-hour-column text-center\">\n                                    {{hourColumnLabels[i]}}\n                                </td>\n                                <td *ngFor=\"let tm of row\" class=\"calendar-cell\" tappable\n                                    (click)=\"select(tm.time, tm.events)\">\n                                    <div [ngClass]=\"{'calendar-event-wrap': tm.events}\" *ngIf=\"tm.events\">\n                                        <ng-template [ngTemplateOutlet]=\"weekviewNormalEventSectionTemplate\"\n                                                     [ngTemplateOutletContext]=\"{tm:tm, hourParts: hourParts, eventTemplate:weekviewNormalEventTemplate}\">\n                                        </ng-template>\n                                    </div>\n                                </td>\n                            </tr>\n                            </tbody>\n                        </table>\n                    </init-position-scroll>\n                </div>\n                <div *ngIf=\"2!==currentViewIndex\">\n                    <div class=\"weekview-allday-table\">\n                        <div class=\"weekview-allday-label\">{{allDayLabel}}</div>\n                        <div class=\"weekview-allday-content-wrapper scroll-content\">\n                            <table class=\"table table-fixed weekview-allday-content-table\">\n                                <tbody>\n                                <tr>\n                                    <td *ngFor=\"let day of views[2].dates\" class=\"calendar-cell\">\n                                        <ng-template [ngTemplateOutlet]=\"weekviewInactiveAllDayEventSectionTemplate\"\n                                                     [ngTemplateOutletContext]=\"{day:day}\">\n                                        </ng-template>\n                                    </td>\n                                </tr>\n                                </tbody>\n                            </table>\n                        </div>\n                    </div>\n                    <init-position-scroll class=\"weekview-normal-event-container\" [initPosition]=\"initScrollPosition\">\n                        <table class=\"table table-bordered table-fixed weekview-normal-event-table\">\n                            <tbody>\n                            <tr *ngFor=\"let row of views[2].rows; let i = index\">\n                                <td class=\"calendar-hour-column text-center\">\n                                    {{hourColumnLabels[i]}}\n                                </td>\n                                <td *ngFor=\"let tm of row\" class=\"calendar-cell\">\n                                    <div [ngClass]=\"{'calendar-event-wrap': tm.events}\" *ngIf=\"tm.events\">\n                                        <ng-template [ngTemplateOutlet]=\"weekviewInactiveNormalEventSectionTemplate\"\n                                                     [ngTemplateOutletContext]=\"{tm:tm, hourParts: hourParts}\">\n                                        </ng-template>\n                                    </div>\n                                </td>\n                            </tr>\n                            </tbody>\n                        </table>\n                    </init-position-scroll>\n                </div>\n            </ion-slide>\n        </ion-slides>\n    ",
      encapsulation: _angular_core__WEBPACK_IMPORTED_MODULE_1__["ViewEncapsulation"].None,
      styles: ["\n        .table-fixed {\n            table-layout: fixed;\n        }\n\n        .table {\n            width: 100%;\n            max-width: 100%;\n            background-color: transparent;\n        }\n\n        .table > thead > tr > th, .table > tbody > tr > th, .table > tfoot > tr > th, .table > thead > tr > td,\n        .table > tbody > tr > td, .table > tfoot > tr > td {\n            padding: 8px;\n            line-height: 20px;\n            vertical-align: top;\n        }\n\n        .table > thead > tr > th {\n            vertical-align: bottom;\n            border-bottom: 2px solid #ddd;\n        }\n\n        .table > thead:first-child > tr:first-child > th, .table > thead:first-child > tr:first-child > td {\n            border-top: 0\n        }\n\n        .table > tbody + tbody {\n            border-top: 2px solid #ddd;\n        }\n\n        .table-bordered {\n            border: 1px solid #ddd;\n        }\n\n        .table-bordered > thead > tr > th, .table-bordered > tbody > tr > th, .table-bordered > tfoot > tr > th,\n        .table-bordered > thead > tr > td, .table-bordered > tbody > tr > td, .table-bordered > tfoot > tr > td {\n            border: 1px solid #ddd;\n        }\n\n        .table-bordered > thead > tr > th, .table-bordered > thead > tr > td {\n            border-bottom-width: 2px;\n        }\n\n        .table-striped > tbody > tr:nth-child(odd) > td, .table-striped > tbody > tr:nth-child(odd) > th {\n            background-color: #f9f9f9\n        }\n\n        .calendar-hour-column {\n            width: 50px;\n            white-space: nowrap;\n        }\n\n        .calendar-event-wrap {\n            position: relative;\n            width: 100%;\n            height: 100%;\n        }\n\n        .calendar-event {\n            position: absolute;\n            padding: 2px;\n            cursor: pointer;\n            z-index: 10000;\n        }\n\n        .calendar-cell {\n            padding: 0 !important;\n            height: 37px;\n        }\n\n        .slides-container {\n            height: 100%;\n        }\n\n        .slide-container {\n            display: block;\n        }\n\n        .weekview-allday-label {\n            float: left;\n            height: 100%;\n            line-height: 50px;\n            text-align: center;\n            width: 50px;\n            border-left: 1px solid #ddd;\n        }\n\n        [dir=\"rtl\"] .weekview-allday-label {\n            float: right;\n            border-right: 1px solid #ddd;\n        }\n\n        .weekview-allday-content-wrapper {\n            margin-left: 50px;\n            overflow: hidden;\n            height: 51px;\n        }\n\n        [dir=\"rtl\"] .weekview-allday-content-wrapper {\n            margin-left: 0;\n            margin-right: 50px;\n        }\n\n        .weekview-allday-content-table {\n            min-height: 50px;\n        }\n\n        .weekview-allday-content-table td {\n            border-left: 1px solid #ddd;\n            border-right: 1px solid #ddd;\n        }\n\n        .weekview-header th {\n            overflow: hidden;\n            white-space: nowrap;\n            font-size: 14px;\n        }\n\n        .weekview-allday-table {\n            height: 50px;\n            position: relative;\n            border-bottom: 1px solid #ddd;\n            font-size: 14px;\n        }\n\n        .weekview-normal-event-container {\n            margin-top: 87px;\n            overflow: hidden;\n            left: 0;\n            right: 0;\n            top: 0;\n            bottom: 0;\n            position: absolute;\n            font-size: 14px;\n        }\n\n        .scroll-content {\n            overflow-y: auto;\n            overflow-x: hidden;\n        }\n\n        ::-webkit-scrollbar,\n        *::-webkit-scrollbar {\n            display: none;\n        }\n\n        .table > tbody > tr > td.calendar-hour-column {\n            padding-left: 0;\n            padding-right: 0;\n            vertical-align: middle;\n        }\n\n        @media (max-width: 750px) {\n            .weekview-allday-label, .calendar-hour-column {\n                width: 31px;\n                font-size: 12px;\n            }\n\n            .weekview-allday-label {\n                padding-top: 4px;\n            }\n\n            .table > tbody > tr > td.calendar-hour-column {\n                padding-left: 0;\n                padding-right: 0;\n                vertical-align: middle;\n                line-height: 12px;\n            }\n\n            .table > thead > tr > th.weekview-header {\n                padding-left: 0;\n                padding-right: 0;\n                font-size: 12px;\n            }\n\n            .weekview-allday-label {\n                line-height: 20px;\n            }\n\n            .weekview-allday-content-wrapper {\n                margin-left: 31px;\n            }\n\n            [dir=\"rtl\"] .weekview-allday-content-wrapper {\n                margin-left: 0;\n                margin-right: 31px;\n            }\n        }\n    "]
    })], WeekViewComponent);
    var DayViewComponent_1;

    var DayViewComponent = DayViewComponent_1 =
    /*#__PURE__*/
    function () {
      function DayViewComponent(calendarService, elm) {
        _classCallCheck(this, DayViewComponent);

        this.calendarService = calendarService;
        this.elm = elm;
        this.class = true;
        this.dir = '';
        this.scrollToHour = 0;
        this.onRangeChanged = new _angular_core__WEBPACK_IMPORTED_MODULE_1__["EventEmitter"]();
        this.onEventSelected = new _angular_core__WEBPACK_IMPORTED_MODULE_1__["EventEmitter"]();
        this.onTimeSelected = new _angular_core__WEBPACK_IMPORTED_MODULE_1__["EventEmitter"]();
        this.onTitleChanged = new _angular_core__WEBPACK_IMPORTED_MODULE_1__["EventEmitter"](true);
        this.views = [];
        this.currentViewIndex = 0;
        this.direction = 0;
        this.mode = 'day';
        this.inited = false;
        this.callbackOnInit = true;
      }

      _createClass(DayViewComponent, [{
        key: "ngOnInit",
        value: function ngOnInit() {
          var _this5 = this;

          if (!this.sliderOptions) {
            this.sliderOptions = {};
          }

          this.sliderOptions.loop = true;
          this.hourRange = (this.endHour - this.startHour) * this.hourSegments;

          if (this.dateFormatter && this.dateFormatter.formatDayViewTitle) {
            this.formatTitle = this.dateFormatter.formatDayViewTitle;
          } else {
            var datePipe = new _angular_common__WEBPACK_IMPORTED_MODULE_2__["DatePipe"](this.locale);

            this.formatTitle = function (date) {
              return datePipe.transform(date, this.formatDayTitle);
            };
          }

          if (this.dateFormatter && this.dateFormatter.formatDayViewHourColumn) {
            this.formatHourColumnLabel = this.dateFormatter.formatDayViewHourColumn;
          } else {
            var _datePipe4 = new _angular_common__WEBPACK_IMPORTED_MODULE_2__["DatePipe"](this.locale);

            this.formatHourColumnLabel = function (date) {
              return _datePipe4.transform(date, this.formatHourColumn);
            };
          }

          if (this.lockSwipeToPrev) {
            this.slider.lockSwipeToPrev(true);
          }

          if (this.lockSwipes) {
            this.slider.lockSwipes(true);
          }

          this.refreshView();
          this.hourColumnLabels = this.getHourColumnLabels();
          this.inited = true;
          this.currentDateChangedFromParentSubscription = this.calendarService.currentDateChangedFromParent$.subscribe(function (currentDate) {
            _this5.refreshView();
          });
          this.eventSourceChangedSubscription = this.calendarService.eventSourceChanged$.subscribe(function () {
            _this5.onDataLoaded();
          });
          this.slideChangedSubscription = this.calendarService.slideChanged$.subscribe(function (direction) {
            if (direction === 1) {
              _this5.slider.slideNext();
            } else if (direction === -1) {
              _this5.slider.slidePrev();
            }
          });
        }
      }, {
        key: "ngAfterViewInit",
        value: function ngAfterViewInit() {
          var title = this.getTitle();
          this.onTitleChanged.emit(title);

          if (this.scrollToHour > 0) {
            var hourColumns = this.elm.nativeElement.querySelector('.dayview-normal-event-container').querySelectorAll('.calendar-hour-column');
            var me = this;
            setTimeout(function () {
              me.initScrollPosition = hourColumns[me.scrollToHour - me.startHour].offsetTop;
            }, 50);
          }
        }
      }, {
        key: "ngOnChanges",
        value: function ngOnChanges(changes) {
          if (!this.inited) {
            return;
          }

          var eventSourceChange = changes.eventSource;

          if (eventSourceChange && eventSourceChange.currentValue) {
            this.onDataLoaded();
          }

          var lockSwipeToPrev = changes.lockSwipeToPrev;

          if (lockSwipeToPrev) {
            this.slider.lockSwipeToPrev(lockSwipeToPrev.currentValue);
          }

          var lockSwipes = changes.lockSwipes;

          if (lockSwipes) {
            this.slider.lockSwipes(lockSwipes.currentValue);
          }
        }
      }, {
        key: "ngOnDestroy",
        value: function ngOnDestroy() {
          if (this.currentDateChangedFromParentSubscription) {
            this.currentDateChangedFromParentSubscription.unsubscribe();
            this.currentDateChangedFromParentSubscription = null;
          }

          if (this.eventSourceChangedSubscription) {
            this.eventSourceChangedSubscription.unsubscribe();
            this.eventSourceChangedSubscription = null;
          }

          if (this.slideChangedSubscription) {
            this.slideChangedSubscription.unsubscribe();
            this.slideChangedSubscription = null;
          }
        }
      }, {
        key: "onSlideChanged",
        value: function onSlideChanged() {
          var _this6 = this;

          if (this.callbackOnInit) {
            this.callbackOnInit = false;
            return;
          }

          var direction = 0;
          var currentViewIndex = this.currentViewIndex;
          this.slider.getActiveIndex().then(function (currentSlideIndex) {
            currentSlideIndex = (currentSlideIndex + 2) % 3;

            if (isNaN(currentSlideIndex)) {
              currentSlideIndex = currentViewIndex;
            }

            if (currentSlideIndex - currentViewIndex === 1) {
              direction = 1;
            } else if (currentSlideIndex === 0 && currentViewIndex === 2) {
              direction = 1;

              _this6.slider.slideTo(1, 0, false);
            } else if (currentViewIndex - currentSlideIndex === 1) {
              direction = -1;
            } else if (currentSlideIndex === 2 && currentViewIndex === 0) {
              direction = -1;

              _this6.slider.slideTo(3, 0, false);
            }

            _this6.currentViewIndex = currentSlideIndex;

            _this6.move(direction);
          });
        }
      }, {
        key: "move",
        value: function move(direction) {
          if (direction === 0) {
            return;
          }

          this.direction = direction;
          var adjacentDate = this.calendarService.getAdjacentCalendarDate(this.mode, direction);
          this.calendarService.setCurrentDate(adjacentDate);
          this.refreshView();
          this.direction = 0;
        }
      }, {
        key: "getHourColumnLabels",
        value: function getHourColumnLabels() {
          var hourColumnLabels = [];

          for (var hour = 0, length = this.views[0].rows.length; hour < length; hour += 1) {
            // handle edge case for DST
            if (hour === 0 && this.views[0].rows[hour].time.getHours() !== this.startHour) {
              var time = new Date(this.views[0].rows[hour].time);
              time.setDate(time.getDate() + 1);
              time.setHours(this.startHour);
              hourColumnLabels.push(this.formatHourColumnLabel(time));
            } else {
              hourColumnLabels.push(this.formatHourColumnLabel(this.views[0].rows[hour].time));
            }
          }

          return hourColumnLabels;
        }
      }, {
        key: "getViewData",
        value: function getViewData(startTime) {
          return {
            rows: DayViewComponent_1.createDateObjects(startTime, this.startHour, this.endHour, this.hourSegments),
            allDayEvents: []
          };
        }
      }, {
        key: "getRange",
        value: function getRange(currentDate) {
          var year = currentDate.getFullYear(),
              month = currentDate.getMonth(),
              date = currentDate.getDate(),
              startTime = new Date(year, month, date, 12, 0, 0),
              endTime = new Date(year, month, date + 1, 12, 0, 0);
          return {
            startTime: startTime,
            endTime: endTime
          };
        }
      }, {
        key: "onDataLoaded",
        value: function onDataLoaded() {
          var eventSource = this.eventSource,
              len = eventSource ? eventSource.length : 0,
              startTime = this.range.startTime,
              endTime = this.range.endTime,
              utcStartTime = Date.UTC(startTime.getFullYear(), startTime.getMonth(), startTime.getDate()),
              utcEndTime = Date.UTC(endTime.getFullYear(), endTime.getMonth(), endTime.getDate()),
              currentViewIndex = this.currentViewIndex,
              rows = this.views[currentViewIndex].rows,
              allDayEvents = this.views[currentViewIndex].allDayEvents = [],
              oneHour = 3600000,
              eps = 0.016,
              rangeStartRowIndex = this.startHour * this.hourSegments,
              rangeEndRowIndex = this.endHour * this.hourSegments;
          var normalEventInRange = false;

          for (var hour = 0; hour < this.hourRange; hour += 1) {
            rows[hour].events = [];
          }

          for (var i = 0; i < len; i += 1) {
            var event = eventSource[i];
            var eventStartTime = event.startTime;
            var eventEndTime = event.endTime;
            var eventUTCStartTime = void 0,
                eventUTCEndTime = void 0;

            if (event.allDay) {
              eventUTCStartTime = eventStartTime.getTime();
              eventUTCEndTime = eventEndTime.getTime();
            } else {
              eventUTCStartTime = Date.UTC(eventStartTime.getFullYear(), eventStartTime.getMonth(), eventStartTime.getDate());
              eventUTCEndTime = Date.UTC(eventEndTime.getFullYear(), eventEndTime.getMonth(), eventEndTime.getDate() + 1);
            }

            if (eventUTCEndTime <= utcStartTime || eventUTCStartTime >= utcEndTime || eventStartTime >= eventEndTime) {
              continue;
            }

            if (event.allDay) {
              allDayEvents.push({
                event: event
              });
            } else {
              normalEventInRange = true;
              var timeDifferenceStart = void 0;

              if (eventUTCStartTime < utcStartTime) {
                timeDifferenceStart = 0;
              } else {
                timeDifferenceStart = (eventStartTime.getHours() + eventStartTime.getMinutes() / 60) * this.hourSegments;
              }

              var timeDifferenceEnd = void 0;

              if (eventUTCEndTime > utcEndTime) {
                timeDifferenceEnd = (utcEndTime - utcStartTime) / oneHour * this.hourSegments;
              } else {
                timeDifferenceEnd = (eventEndTime.getHours() + eventEndTime.getMinutes() / 60) * this.hourSegments;
              }

              var startIndex = Math.floor(timeDifferenceStart);
              var endIndex = Math.ceil(timeDifferenceEnd - eps);
              var startOffset = 0;
              var endOffset = 0;

              if (this.hourParts !== 1) {
                if (startIndex < rangeStartRowIndex) {
                  startOffset = 0;
                } else {
                  startOffset = Math.floor((timeDifferenceStart - startIndex) * this.hourParts);
                }

                if (endIndex > rangeEndRowIndex) {
                  endOffset = 0;
                } else {
                  endOffset = Math.floor((endIndex - timeDifferenceEnd) * this.hourParts);
                }
              }

              if (startIndex < rangeStartRowIndex) {
                startIndex = 0;
              } else {
                startIndex -= rangeStartRowIndex;
              }

              if (endIndex > rangeEndRowIndex) {
                endIndex = rangeEndRowIndex;
              }

              endIndex -= rangeStartRowIndex;

              if (startIndex < endIndex) {
                var displayEvent = {
                  event: event,
                  startIndex: startIndex,
                  endIndex: endIndex,
                  startOffset: startOffset,
                  endOffset: endOffset
                };
                var eventSet = rows[startIndex].events;

                if (eventSet) {
                  eventSet.push(displayEvent);
                } else {
                  eventSet = [];
                  eventSet.push(displayEvent);
                  rows[startIndex].events = eventSet;
                }
              }
            }
          }

          if (normalEventInRange) {
            var orderedEvents = [];

            for (var _hour2 = 0; _hour2 < this.hourRange; _hour2 += 1) {
              if (rows[_hour2].events) {
                rows[_hour2].events.sort(DayViewComponent_1.compareEventByStartOffset);

                orderedEvents = orderedEvents.concat(rows[_hour2].events);
              }
            }

            if (orderedEvents.length > 0) {
              this.placeEvents(orderedEvents);
            }
          }
        }
      }, {
        key: "refreshView",
        value: function refreshView() {
          this.range = this.getRange(this.calendarService.currentDate);

          if (this.inited) {
            var title = this.getTitle();
            this.onTitleChanged.emit(title);
          }

          this.calendarService.populateAdjacentViews(this);
          this.calendarService.rangeChanged(this);
        }
      }, {
        key: "getTitle",
        value: function getTitle() {
          var startingDate = new Date(this.range.startTime.getTime());
          startingDate.setHours(12, 0, 0, 0);
          return this.formatTitle(startingDate);
        }
      }, {
        key: "select",
        value: function select(selectedTime, events) {
          var disabled = false;

          if (this.markDisabled) {
            disabled = this.markDisabled(selectedTime);
          }

          this.onTimeSelected.emit({
            selectedTime: selectedTime,
            events: events.map(function (e) {
              return e.event;
            }),
            disabled: disabled
          });
        }
      }, {
        key: "placeEvents",
        value: function placeEvents(orderedEvents) {
          this.calculatePosition(orderedEvents);
          DayViewComponent_1.calculateWidth(orderedEvents, this.hourRange, this.hourParts);
        }
      }, {
        key: "placeAllDayEvents",
        value: function placeAllDayEvents(orderedEvents) {
          this.calculatePosition(orderedEvents);
        }
      }, {
        key: "overlap",
        value: function overlap(event1, event2) {
          var earlyEvent = event1,
              lateEvent = event2;

          if (event1.startIndex > event2.startIndex || event1.startIndex === event2.startIndex && event1.startOffset > event2.startOffset) {
            earlyEvent = event2;
            lateEvent = event1;
          }

          if (earlyEvent.endIndex <= lateEvent.startIndex) {
            return false;
          } else {
            return !(earlyEvent.endIndex - lateEvent.startIndex === 1 && earlyEvent.endOffset + lateEvent.startOffset >= this.hourParts);
          }
        }
      }, {
        key: "calculatePosition",
        value: function calculatePosition(events) {
          var len = events.length,
              isForbidden = new Array(len);
          var maxColumn = 0,
              col;

          for (var i = 0; i < len; i += 1) {
            for (col = 0; col < maxColumn; col += 1) {
              isForbidden[col] = false;
            }

            for (var j = 0; j < i; j += 1) {
              if (this.overlap(events[i], events[j])) {
                isForbidden[events[j].position] = true;
              }
            }

            for (col = 0; col < maxColumn; col += 1) {
              if (!isForbidden[col]) {
                break;
              }
            }

            if (col < maxColumn) {
              events[i].position = col;
            } else {
              events[i].position = maxColumn++;
            }
          }

          if (this.dir === 'rtl') {
            for (var _i6 = 0; _i6 < len; _i6 += 1) {
              events[_i6].position = maxColumn - 1 - events[_i6].position;
            }
          }
        }
      }, {
        key: "eventSelected",
        value: function eventSelected(event) {
          this.onEventSelected.emit(event);
        }
      }, {
        key: "setScrollPosition",
        value: function setScrollPosition(scrollPosition) {
          this.initScrollPosition = scrollPosition;
        }
      }], [{
        key: "createDateObjects",
        value: function createDateObjects(startTime, startHour, endHour, timeInterval) {
          var rows = [],
              currentHour = 0,
              currentDate = startTime.getDate();
          var time, hourStep, minStep;

          if (timeInterval < 1) {
            hourStep = Math.floor(1 / timeInterval);
            minStep = 60;
          } else {
            hourStep = 1;
            minStep = Math.floor(60 / timeInterval);
          }

          for (var hour = startHour; hour < endHour; hour += hourStep) {
            for (var interval = 0; interval < 60; interval += minStep) {
              time = new Date(startTime.getTime());
              time.setHours(currentHour + hour, interval);
              time.setDate(currentDate);
              rows.push({
                time: time,
                events: []
              });
            }
          }

          return rows;
        }
      }, {
        key: "compareEventByStartOffset",
        value: function compareEventByStartOffset(eventA, eventB) {
          return eventA.startOffset - eventB.startOffset;
        }
      }, {
        key: "calculateWidth",
        value: function calculateWidth(orderedEvents, size, hourParts) {
          var totalSize = size * hourParts,
              cells = new Array(totalSize); // sort by position in descending order, the right most columns should be calculated first

          orderedEvents.sort(function (eventA, eventB) {
            return eventB.position - eventA.position;
          });

          for (var _i7 = 0; _i7 < totalSize; _i7 += 1) {
            cells[_i7] = {
              calculated: false,
              events: []
            };
          }

          var len = orderedEvents.length;

          for (var _i8 = 0; _i8 < len; _i8 += 1) {
            var event = orderedEvents[_i8];
            var index = event.startIndex * hourParts + event.startOffset;

            while (index < event.endIndex * hourParts - event.endOffset) {
              cells[index].events.push(event);
              index += 1;
            }
          }

          var i = 0;

          while (i < len) {
            var _event2 = orderedEvents[i];

            if (!_event2.overlapNumber) {
              var overlapNumber = _event2.position + 1;
              _event2.overlapNumber = overlapNumber;
              var eventQueue = [_event2];

              while (_event2 = eventQueue.shift()) {
                var _index2 = _event2.startIndex * hourParts + _event2.startOffset;

                while (_index2 < _event2.endIndex * hourParts - _event2.endOffset) {
                  if (!cells[_index2].calculated) {
                    cells[_index2].calculated = true;

                    if (cells[_index2].events) {
                      var eventCountInCell = cells[_index2].events.length;

                      for (var j = 0; j < eventCountInCell; j += 1) {
                        var currentEventInCell = cells[_index2].events[j];

                        if (!currentEventInCell.overlapNumber) {
                          currentEventInCell.overlapNumber = overlapNumber;
                          eventQueue.push(currentEventInCell);
                        }
                      }
                    }
                  }

                  _index2 += 1;
                }
              }
            }

            i += 1;
          }
        }
      }]);

      return DayViewComponent;
    }();

    DayViewComponent.ctorParameters = function () {
      return [{
        type: CalendarService
      }, {
        type: _angular_core__WEBPACK_IMPORTED_MODULE_1__["ElementRef"]
      }];
    };

    Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["ViewChild"])('daySlider', {
      static: true
    })], DayViewComponent.prototype, "slider", void 0);
    Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["HostBinding"])('class.dayview')], DayViewComponent.prototype, "class", void 0);
    Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Input"])()], DayViewComponent.prototype, "dayviewAllDayEventTemplate", void 0);
    Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Input"])()], DayViewComponent.prototype, "dayviewNormalEventTemplate", void 0);
    Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Input"])()], DayViewComponent.prototype, "dayviewAllDayEventSectionTemplate", void 0);
    Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Input"])()], DayViewComponent.prototype, "dayviewNormalEventSectionTemplate", void 0);
    Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Input"])()], DayViewComponent.prototype, "dayviewInactiveAllDayEventSectionTemplate", void 0);
    Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Input"])()], DayViewComponent.prototype, "dayviewInactiveNormalEventSectionTemplate", void 0);
    Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Input"])()], DayViewComponent.prototype, "formatHourColumn", void 0);
    Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Input"])()], DayViewComponent.prototype, "formatDayTitle", void 0);
    Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Input"])()], DayViewComponent.prototype, "allDayLabel", void 0);
    Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Input"])()], DayViewComponent.prototype, "hourParts", void 0);
    Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Input"])()], DayViewComponent.prototype, "eventSource", void 0);
    Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Input"])()], DayViewComponent.prototype, "markDisabled", void 0);
    Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Input"])()], DayViewComponent.prototype, "locale", void 0);
    Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Input"])()], DayViewComponent.prototype, "dateFormatter", void 0);
    Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Input"])()], DayViewComponent.prototype, "dir", void 0);
    Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Input"])()], DayViewComponent.prototype, "scrollToHour", void 0);
    Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Input"])()], DayViewComponent.prototype, "preserveScrollPosition", void 0);
    Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Input"])()], DayViewComponent.prototype, "lockSwipeToPrev", void 0);
    Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Input"])()], DayViewComponent.prototype, "lockSwipes", void 0);
    Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Input"])()], DayViewComponent.prototype, "startHour", void 0);
    Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Input"])()], DayViewComponent.prototype, "endHour", void 0);
    Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Input"])()], DayViewComponent.prototype, "sliderOptions", void 0);
    Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Input"])()], DayViewComponent.prototype, "hourSegments", void 0);
    Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Output"])()], DayViewComponent.prototype, "onRangeChanged", void 0);
    Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Output"])()], DayViewComponent.prototype, "onEventSelected", void 0);
    Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Output"])()], DayViewComponent.prototype, "onTimeSelected", void 0);
    Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Output"])()], DayViewComponent.prototype, "onTitleChanged", void 0);
    DayViewComponent = DayViewComponent_1 = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
      selector: 'dayview',
      template: "\n        <ion-slides #daySlider [options]=\"sliderOptions\" [dir]=\"dir\" (ionSlideDidChange)=\"onSlideChanged()\" class=\"slides-container\">\n            <ion-slide class=\"slide-container\">\n                <div class=\"dayview-allday-table\">\n                    <div class=\"dayview-allday-label\">{{allDayLabel}}</div>\n                    <div class=\"dayview-allday-content-wrapper scroll-content\">\n                        <table class=\"table table-bordered dayview-allday-content-table\">\n                            <tbody>\n                            <tr>\n                                <td class=\"calendar-cell\" [ngClass]=\"{'calendar-event-wrap':views[0].allDayEvents.length>0}\"\n                                    [ngStyle]=\"{height: 25*views[0].allDayEvents.length+'px'}\"\n                                    *ngIf=\"0===currentViewIndex\">\n                                    <ng-template [ngTemplateOutlet]=\"dayviewAllDayEventSectionTemplate\"\n                                                 [ngTemplateOutletContext]=\"{allDayEvents:views[0].allDayEvents,eventTemplate:dayviewAllDayEventTemplate}\">\n                                    </ng-template>\n                                </td>\n                                <td class=\"calendar-cell\" *ngIf=\"0!==currentViewIndex\">\n                                    <ng-template [ngTemplateOutlet]=\"dayviewInactiveAllDayEventSectionTemplate\"\n                                                 [ngTemplateOutletContext]=\"{allDayEvents:views[0].allDayEvents}\">\n                                    </ng-template>\n                                </td>\n                            </tr>\n                            </tbody>\n                        </table>\n                    </div>\n                </div>\n                <init-position-scroll *ngIf=\"0===currentViewIndex\" class=\"dayview-normal-event-container\"\n                                      [initPosition]=\"initScrollPosition\" [emitEvent]=\"preserveScrollPosition\"\n                                      (onScroll)=\"setScrollPosition($event)\">\n                    <table class=\"table table-bordered table-fixed dayview-normal-event-table\">\n                        <tbody>\n                        <tr *ngFor=\"let tm of views[0].rows; let i = index\">\n                            <td class=\"calendar-hour-column text-center\">\n                                {{hourColumnLabels[i]}}\n                            </td>\n                            <td class=\"calendar-cell\" tappable (click)=\"select(tm.time, tm.events)\">\n                                <ng-template [ngTemplateOutlet]=\"dayviewNormalEventSectionTemplate\"\n                                             [ngTemplateOutletContext]=\"{tm:tm, hourParts: hourParts, eventTemplate:dayviewNormalEventTemplate}\">\n                                </ng-template>\n                            </td>\n                        </tr>\n                        </tbody>\n                    </table>\n                </init-position-scroll>\n                <init-position-scroll *ngIf=\"0!==currentViewIndex\" class=\"dayview-normal-event-container\"\n                                      [initPosition]=\"initScrollPosition\">\n                    <table class=\"table table-bordered table-fixed dayview-normal-event-table\">\n                        <tbody>\n                        <tr *ngFor=\"let tm of views[0].rows; let i = index\">\n                            <td class=\"calendar-hour-column text-center\">\n                                {{hourColumnLabels[i]}}\n                            </td>\n                            <td class=\"calendar-cell\">\n                                <ng-template [ngTemplateOutlet]=\"dayviewInactiveNormalEventSectionTemplate\"\n                                             [ngTemplateOutletContext]=\"{tm:tm, hourParts: hourParts}\">\n                                </ng-template>\n                            </td>\n                        </tr>\n                        </tbody>\n                    </table>\n                </init-position-scroll>\n            </ion-slide>\n            <ion-slide class=\"slide-container\">\n                <div class=\"dayview-allday-table\">\n                    <div class=\"dayview-allday-label\">{{allDayLabel}}</div>\n                    <div class=\"dayview-allday-content-wrapper scroll-content\">\n                        <table class=\"table table-bordered dayview-allday-content-table\">\n                            <tbody>\n                            <tr>\n                                <td class=\"calendar-cell\" [ngClass]=\"{'calendar-event-wrap':views[1].allDayEvents.length>0}\"\n                                    [ngStyle]=\"{height: 25*views[1].allDayEvents.length+'px'}\"\n                                    *ngIf=\"1===currentViewIndex\">\n                                    <ng-template [ngTemplateOutlet]=\"dayviewAllDayEventSectionTemplate\"\n                                                 [ngTemplateOutletContext]=\"{allDayEvents:views[1].allDayEvents,eventTemplate:dayviewAllDayEventTemplate}\">\n                                    </ng-template>\n                                </td>\n                                <td class=\"calendar-cell\" *ngIf=\"1!==currentViewIndex\">\n                                    <ng-template [ngTemplateOutlet]=\"dayviewInactiveAllDayEventSectionTemplate\"\n                                                 [ngTemplateOutletContext]=\"{allDayEvents:views[1].allDayEvents}\">\n                                    </ng-template>\n                                </td>\n                            </tr>\n                            </tbody>\n                        </table>\n                    </div>\n                </div>\n                <init-position-scroll *ngIf=\"1===currentViewIndex\" class=\"dayview-normal-event-container\"\n                                      [initPosition]=\"initScrollPosition\" [emitEvent]=\"preserveScrollPosition\"\n                                      (onScroll)=\"setScrollPosition($event)\">\n                    <table class=\"table table-bordered table-fixed dayview-normal-event-table\">\n                        <tbody>\n                        <tr *ngFor=\"let tm of views[1].rows; let i = index\">\n                            <td class=\"calendar-hour-column text-center\">\n                                {{hourColumnLabels[i]}}\n                            </td>\n                            <td class=\"calendar-cell\" tappable (click)=\"select(tm.time, tm.events)\">\n                                <ng-template [ngTemplateOutlet]=\"dayviewNormalEventSectionTemplate\"\n                                             [ngTemplateOutletContext]=\"{tm:tm, hourParts: hourParts, eventTemplate:dayviewNormalEventTemplate}\">\n                                </ng-template>\n                            </td>\n                        </tr>\n                        </tbody>\n                    </table>\n                </init-position-scroll>\n                <init-position-scroll *ngIf=\"1!==currentViewIndex\" class=\"dayview-normal-event-container\"\n                                      [initPosition]=\"initScrollPosition\">\n                    <table class=\"table table-bordered table-fixed dayview-normal-event-table\">\n                        <tbody>\n                        <tr *ngFor=\"let tm of views[1].rows; let i = index\">\n                            <td class=\"calendar-hour-column text-center\">\n                                {{hourColumnLabels[i]}}\n                            </td>\n                            <td class=\"calendar-cell\">\n                                <ng-template [ngTemplateOutlet]=\"dayviewInactiveNormalEventSectionTemplate\"\n                                             [ngTemplateOutletContext]=\"{tm:tm, hourParts: hourParts}\">\n                                </ng-template>\n                            </td>\n                        </tr>\n                        </tbody>\n                    </table>\n                </init-position-scroll>\n            </ion-slide>\n            <ion-slide class=\"slide-container\">\n                <div class=\"dayview-allday-table\">\n                    <div class=\"dayview-allday-label\">{{allDayLabel}}</div>\n                    <div class=\"dayview-allday-content-wrapper scroll-content\">\n                        <table class=\"table table-bordered dayview-allday-content-table\">\n                            <tbody>\n                            <tr>\n                                <td class=\"calendar-cell\" [ngClass]=\"{'calendar-event-wrap':views[2].allDayEvents.length>0}\"\n                                    [ngStyle]=\"{height: 25*views[2].allDayEvents.length+'px'}\"\n                                    *ngIf=\"2===currentViewIndex\">\n                                    <ng-template [ngTemplateOutlet]=\"dayviewAllDayEventSectionTemplate\"\n                                                 [ngTemplateOutletContext]=\"{allDayEvents:views[2].allDayEvents,eventTemplate:dayviewAllDayEventTemplate}\">\n                                    </ng-template>\n                                </td>\n                                <td class=\"calendar-cell\" *ngIf=\"2!==currentViewIndex\">\n                                    <ng-template [ngTemplateOutlet]=\"dayviewInactiveAllDayEventSectionTemplate\"\n                                                 [ngTemplateOutletContext]=\"{allDayEvents:views[2].allDayEvents}\">\n                                    </ng-template>\n                                </td>\n                            </tr>\n                            </tbody>\n                        </table>\n                    </div>\n                </div>\n                <init-position-scroll *ngIf=\"2===currentViewIndex\" class=\"dayview-normal-event-container\"\n                                      [initPosition]=\"initScrollPosition\" [emitEvent]=\"preserveScrollPosition\"\n                                      (onScroll)=\"setScrollPosition($event)\">\n                    <table class=\"table table-bordered table-fixed dayview-normal-event-table\">\n                        <tbody>\n                        <tr *ngFor=\"let tm of views[2].rows; let i = index\">\n                            <td class=\"calendar-hour-column text-center\">\n                                {{hourColumnLabels[i]}}\n                            </td>\n                            <td class=\"calendar-cell\" tappable (click)=\"select(tm.time, tm.events)\">\n                                <ng-template [ngTemplateOutlet]=\"dayviewNormalEventSectionTemplate\"\n                                             [ngTemplateOutletContext]=\"{tm:tm, hourParts: hourParts, eventTemplate:dayviewNormalEventTemplate}\">\n                                </ng-template>\n                            </td>\n                        </tr>\n                        </tbody>\n                    </table>\n                </init-position-scroll>\n                <init-position-scroll *ngIf=\"2!==currentViewIndex\" class=\"dayview-normal-event-container\"\n                                      [initPosition]=\"initScrollPosition\">\n                    <table class=\"table table-bordered table-fixed dayview-normal-event-table\">\n                        <tbody>\n                        <tr *ngFor=\"let tm of views[2].rows; let i = index\">\n                            <td class=\"calendar-hour-column text-center\">\n                                {{hourColumnLabels[i]}}\n                            </td>\n                            <td class=\"calendar-cell\">\n                                <ng-template [ngTemplateOutlet]=\"dayviewInactiveNormalEventSectionTemplate\"\n                                             [ngTemplateOutletContext]=\"{tm:tm, hourParts: hourParts}\">\n                                </ng-template>\n                            </td>\n                        </tr>\n                        </tbody>\n                    </table>\n                </init-position-scroll>\n            </ion-slide>\n        </ion-slides>\n    ",
      encapsulation: _angular_core__WEBPACK_IMPORTED_MODULE_1__["ViewEncapsulation"].None,
      styles: ["\n        .table-fixed {\n            table-layout: fixed;\n        }\n\n        .table {\n            width: 100%;\n            max-width: 100%;\n            background-color: transparent;\n        }\n\n        .table > thead > tr > th, .table > tbody > tr > th, .table > tfoot > tr > th, .table > thead > tr > td,\n        .table > tbody > tr > td, .table > tfoot > tr > td {\n            padding: 8px;\n            line-height: 20px;\n            vertical-align: top;\n        }\n\n        .table > thead > tr > th {\n            vertical-align: bottom;\n            border-bottom: 2px solid #ddd;\n        }\n\n        .table > thead:first-child > tr:first-child > th, .table > thead:first-child > tr:first-child > td {\n            border-top: 0\n        }\n\n        .table > tbody + tbody {\n            border-top: 2px solid #ddd;\n        }\n\n        .table-bordered {\n            border: 1px solid #ddd;\n        }\n\n        .table-bordered > thead > tr > th, .table-bordered > tbody > tr > th, .table-bordered > tfoot > tr > th,\n        .table-bordered > thead > tr > td, .table-bordered > tbody > tr > td, .table-bordered > tfoot > tr > td {\n            border: 1px solid #ddd;\n        }\n\n        .table-bordered > thead > tr > th, .table-bordered > thead > tr > td {\n            border-bottom-width: 2px;\n        }\n\n        .table-striped > tbody > tr:nth-child(odd) > td, .table-striped > tbody > tr:nth-child(odd) > th {\n            background-color: #f9f9f9\n        }\n\n        .calendar-hour-column {\n            width: 50px;\n            white-space: nowrap;\n        }\n\n        .calendar-event-wrap {\n            position: relative;\n            width: 100%;\n            height: 100%;\n        }\n\n        .calendar-event {\n            position: absolute;\n            padding: 2px;\n            cursor: pointer;\n            z-index: 10000;\n        }\n\n        .slides-container {\n            height: 100%;\n        }\n\n        .slide-container {\n            display: block;\n        }\n\n        .calendar-cell {\n            padding: 0 !important;\n            height: 37px;\n        }\n\n        .dayview-allday-label {\n            float: left;\n            height: 100%;\n            line-height: 50px;\n            text-align: center;\n            width: 50px;\n            border-left: 1px solid #ddd;\n        }\n\n        [dir=\"rtl\"] .dayview-allday-label {\n            border-right: 1px solid #ddd;\n            float: right;\n        }\n\n        .dayview-allday-content-wrapper {\n            margin-left: 50px;\n            overflow: hidden;\n            height: 51px;\n        }\n\n        [dir=\"rtl\"] .dayview-allday-content-wrapper {\n            margin-left: 0;\n            margin-right: 50px;\n        }\n\n        .dayview-allday-content-table {\n            min-height: 50px;\n        }\n\n        .dayview-allday-content-table td {\n            border-left: 1px solid #ddd;\n            border-right: 1px solid #ddd;\n        }\n\n        .dayview-allday-table {\n            height: 50px;\n            position: relative;\n            border-bottom: 1px solid #ddd;\n            font-size: 14px;\n        }\n\n        .dayview-normal-event-container {\n            margin-top: 50px;\n            overflow: hidden;\n            left: 0;\n            right: 0;\n            top: 0;\n            bottom: 0;\n            position: absolute;\n            font-size: 14px;\n        }\n\n        .scroll-content {\n            overflow-y: auto;\n            overflow-x: hidden;\n        }\n\n        ::-webkit-scrollbar,\n        *::-webkit-scrollbar {\n            display: none;\n        }\n\n        .table > tbody > tr > td.calendar-hour-column {\n            padding-left: 0;\n            padding-right: 0;\n            vertical-align: middle;\n        }\n\n        @media (max-width: 750px) {\n            .dayview-allday-label, .calendar-hour-column {\n                width: 31px;\n                font-size: 12px;\n            }\n\n            .dayview-allday-label {\n                padding-top: 4px;\n            }\n\n            .table > tbody > tr > td.calendar-hour-column {\n                padding-left: 0;\n                padding-right: 0;\n                vertical-align: middle;\n                line-height: 12px;\n            }\n\n            .dayview-allday-label {\n                line-height: 20px;\n            }\n\n            .dayview-allday-content-wrapper {\n                margin-left: 31px;\n            }\n\n            [dir=\"rtl\"] .dayview-allday-content-wrapper {\n                margin-left: 0;\n                margin-right: 31px;\n            }\n        }\n    "]
    })], DayViewComponent);
    var Step;

    (function (Step) {
      Step[Step["QuarterHour"] = 15] = "QuarterHour";
      Step[Step["HalfHour"] = 30] = "HalfHour";
      Step[Step["Hour"] = 60] = "Hour";
    })(Step || (Step = {}));

    var CalendarComponent =
    /*#__PURE__*/
    function () {
      function CalendarComponent(calendarService, appLocale) {
        _classCallCheck(this, CalendarComponent);

        this.calendarService = calendarService;
        this.appLocale = appLocale;
        this.eventSource = [];
        this.calendarMode = 'month';
        this.formatDay = 'd';
        this.formatDayHeader = 'EEE';
        this.formatDayTitle = 'MMMM dd, yyyy';
        this.formatWeekTitle = 'MMMM yyyy, \'Week\' w';
        this.formatMonthTitle = 'MMMM yyyy';
        this.formatWeekViewDayHeader = 'EEE d';
        this.formatHourColumn = 'ha';
        this.showEventDetail = true;
        this.startingDayMonth = 0;
        this.startingDayWeek = 0;
        this.allDayLabel = 'all day';
        this.noEventsLabel = 'No Events';
        this.queryMode = 'local';
        this.step = Step.Hour;
        this.timeInterval = 60;
        this.autoSelect = true;
        this.dir = "";
        this.scrollToHour = 0;
        this.preserveScrollPosition = false;
        this.lockSwipeToPrev = false;
        this.lockSwipes = false;
        this.locale = "";
        this.startHour = 0;
        this.endHour = 24;
        this.onCurrentDateChanged = new _angular_core__WEBPACK_IMPORTED_MODULE_1__["EventEmitter"]();
        this.onRangeChanged = new _angular_core__WEBPACK_IMPORTED_MODULE_1__["EventEmitter"]();
        this.onEventSelected = new _angular_core__WEBPACK_IMPORTED_MODULE_1__["EventEmitter"]();
        this.onTimeSelected = new _angular_core__WEBPACK_IMPORTED_MODULE_1__["EventEmitter"]();
        this.onTitleChanged = new _angular_core__WEBPACK_IMPORTED_MODULE_1__["EventEmitter"]();
        this.hourParts = 1;
        this.hourSegments = 1;
        this.locale = appLocale;
      }

      _createClass(CalendarComponent, [{
        key: "ngOnInit",
        value: function ngOnInit() {
          var _this7 = this;

          if (this.autoSelect) {
            if (this.autoSelect.toString() === 'false') {
              this.autoSelect = false;
            } else {
              this.autoSelect = true;
            }
          }

          this.hourSegments = 60 / this.timeInterval;
          this.hourParts = 60 / this.step;

          if (this.hourParts <= this.hourSegments) {
            this.hourParts = 1;
          } else {
            this.hourParts = this.hourParts / this.hourSegments;
          }

          this.startHour = parseInt(this.startHour.toString());
          this.endHour = parseInt(this.endHour.toString());
          this.calendarService.queryMode = this.queryMode;
          this.currentDateChangedFromChildrenSubscription = this.calendarService.currentDateChangedFromChildren$.subscribe(function (currentDate) {
            _this7._currentDate = currentDate;

            _this7.onCurrentDateChanged.emit(currentDate);
          });
        }
      }, {
        key: "ngOnDestroy",
        value: function ngOnDestroy() {
          if (this.currentDateChangedFromChildrenSubscription) {
            this.currentDateChangedFromChildrenSubscription.unsubscribe();
            this.currentDateChangedFromChildrenSubscription = null;
          }
        }
      }, {
        key: "rangeChanged",
        value: function rangeChanged(range) {
          this.onRangeChanged.emit(range);
        }
      }, {
        key: "eventSelected",
        value: function eventSelected(event) {
          this.onEventSelected.emit(event);
        }
      }, {
        key: "timeSelected",
        value: function timeSelected(_timeSelected) {
          this.onTimeSelected.emit(_timeSelected);
        }
      }, {
        key: "titleChanged",
        value: function titleChanged(title) {
          this.onTitleChanged.emit(title);
        }
      }, {
        key: "loadEvents",
        value: function loadEvents() {
          this.calendarService.loadEvents();
        }
      }, {
        key: "slideNext",
        value: function slideNext() {
          this.calendarService.slide(1);
        }
      }, {
        key: "slidePrev",
        value: function slidePrev() {
          this.calendarService.slide(-1);
        }
      }, {
        key: "currentDate",
        get: function get() {
          return this._currentDate;
        },
        set: function set(val) {
          if (!val) {
            val = new Date();
          }

          this._currentDate = val;
          this.calendarService.setCurrentDate(val, true);
          this.onCurrentDateChanged.emit(this._currentDate);
        }
      }]);

      return CalendarComponent;
    }();

    CalendarComponent.ctorParameters = function () {
      return [{
        type: CalendarService
      }, {
        type: String,
        decorators: [{
          type: _angular_core__WEBPACK_IMPORTED_MODULE_1__["Inject"],
          args: [_angular_core__WEBPACK_IMPORTED_MODULE_1__["LOCALE_ID"]]
        }]
      }];
    };

    Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Input"])()], CalendarComponent.prototype, "currentDate", null);
    Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Input"])()], CalendarComponent.prototype, "eventSource", void 0);
    Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Input"])()], CalendarComponent.prototype, "calendarMode", void 0);
    Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Input"])()], CalendarComponent.prototype, "formatDay", void 0);
    Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Input"])()], CalendarComponent.prototype, "formatDayHeader", void 0);
    Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Input"])()], CalendarComponent.prototype, "formatDayTitle", void 0);
    Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Input"])()], CalendarComponent.prototype, "formatWeekTitle", void 0);
    Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Input"])()], CalendarComponent.prototype, "formatMonthTitle", void 0);
    Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Input"])()], CalendarComponent.prototype, "formatWeekViewDayHeader", void 0);
    Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Input"])()], CalendarComponent.prototype, "formatHourColumn", void 0);
    Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Input"])()], CalendarComponent.prototype, "showEventDetail", void 0);
    Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Input"])()], CalendarComponent.prototype, "startingDayMonth", void 0);
    Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Input"])()], CalendarComponent.prototype, "startingDayWeek", void 0);
    Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Input"])()], CalendarComponent.prototype, "allDayLabel", void 0);
    Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Input"])()], CalendarComponent.prototype, "noEventsLabel", void 0);
    Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Input"])()], CalendarComponent.prototype, "queryMode", void 0);
    Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Input"])()], CalendarComponent.prototype, "step", void 0);
    Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Input"])()], CalendarComponent.prototype, "timeInterval", void 0);
    Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Input"])()], CalendarComponent.prototype, "autoSelect", void 0);
    Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Input"])()], CalendarComponent.prototype, "markDisabled", void 0);
    Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Input"])()], CalendarComponent.prototype, "monthviewDisplayEventTemplate", void 0);
    Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Input"])()], CalendarComponent.prototype, "monthviewInactiveDisplayEventTemplate", void 0);
    Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Input"])()], CalendarComponent.prototype, "monthviewEventDetailTemplate", void 0);
    Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Input"])()], CalendarComponent.prototype, "weekviewHeaderTemplate", void 0);
    Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Input"])()], CalendarComponent.prototype, "weekviewAllDayEventTemplate", void 0);
    Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Input"])()], CalendarComponent.prototype, "weekviewNormalEventTemplate", void 0);
    Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Input"])()], CalendarComponent.prototype, "dayviewAllDayEventTemplate", void 0);
    Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Input"])()], CalendarComponent.prototype, "dayviewNormalEventTemplate", void 0);
    Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Input"])()], CalendarComponent.prototype, "weekviewAllDayEventSectionTemplate", void 0);
    Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Input"])()], CalendarComponent.prototype, "weekviewNormalEventSectionTemplate", void 0);
    Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Input"])()], CalendarComponent.prototype, "dayviewAllDayEventSectionTemplate", void 0);
    Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Input"])()], CalendarComponent.prototype, "dayviewNormalEventSectionTemplate", void 0);
    Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Input"])()], CalendarComponent.prototype, "weekviewInactiveAllDayEventSectionTemplate", void 0);
    Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Input"])()], CalendarComponent.prototype, "weekviewInactiveNormalEventSectionTemplate", void 0);
    Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Input"])()], CalendarComponent.prototype, "dayviewInactiveAllDayEventSectionTemplate", void 0);
    Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Input"])()], CalendarComponent.prototype, "dayviewInactiveNormalEventSectionTemplate", void 0);
    Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Input"])()], CalendarComponent.prototype, "dateFormatter", void 0);
    Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Input"])()], CalendarComponent.prototype, "dir", void 0);
    Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Input"])()], CalendarComponent.prototype, "scrollToHour", void 0);
    Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Input"])()], CalendarComponent.prototype, "preserveScrollPosition", void 0);
    Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Input"])()], CalendarComponent.prototype, "lockSwipeToPrev", void 0);
    Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Input"])()], CalendarComponent.prototype, "lockSwipes", void 0);
    Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Input"])()], CalendarComponent.prototype, "locale", void 0);
    Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Input"])()], CalendarComponent.prototype, "startHour", void 0);
    Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Input"])()], CalendarComponent.prototype, "endHour", void 0);
    Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Input"])()], CalendarComponent.prototype, "sliderOptions", void 0);
    Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Output"])()], CalendarComponent.prototype, "onCurrentDateChanged", void 0);
    Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Output"])()], CalendarComponent.prototype, "onRangeChanged", void 0);
    Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Output"])()], CalendarComponent.prototype, "onEventSelected", void 0);
    Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Output"])()], CalendarComponent.prototype, "onTimeSelected", void 0);
    Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Output"])()], CalendarComponent.prototype, "onTitleChanged", void 0);
    CalendarComponent = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
      selector: 'calendar',
      template: "\n        <ng-template #monthviewDefaultDisplayEventTemplate let-view=\"view\" let-row=\"row\" let-col=\"col\">\n            {{view.dates[row*7+col].label}}\n        </ng-template>\n        <ng-template #monthviewDefaultEventDetailTemplate let-showEventDetail=\"showEventDetail\" let-selectedDate=\"selectedDate\" let-noEventsLabel=\"noEventsLabel\">\n            <ion-list class=\"event-detail-container\" has-bouncing=\"false\" *ngIf=\"showEventDetail\" overflow-scroll=\"false\">\n                <ion-item *ngFor=\"let event of selectedDate?.events\" (click)=\"eventSelected(event)\">\n                        <span *ngIf=\"!event.allDay\" class=\"monthview-eventdetail-timecolumn\">{{event.startTime|date: 'HH:mm'}}\n                            -\n                            {{event.endTime|date: 'HH:mm'}}\n                        </span>\n                    <span *ngIf=\"event.allDay\" class=\"monthview-eventdetail-timecolumn\">{{allDayLabel}}</span>\n                    <span class=\"event-detail\">  |  {{event.title}}</span>\n                </ion-item>\n                <ion-item *ngIf=\"selectedDate?.events.length==0\">\n                    <div class=\"no-events-label\">{{noEventsLabel}}</div>\n                </ion-item>\n            </ion-list>\n        </ng-template>\n        <ng-template #defaultWeekviewHeaderTemplate let-viewDate=\"viewDate\">\n            {{ viewDate.dayHeader }}\n        </ng-template>\n        <ng-template #defaultAllDayEventTemplate let-displayEvent=\"displayEvent\">\n            <div class=\"calendar-event-inner\">{{displayEvent.event.title}}</div>\n        </ng-template>\n        <ng-template #defaultNormalEventTemplate let-displayEvent=\"displayEvent\">\n            <div class=\"calendar-event-inner\">{{displayEvent.event.title}}</div>\n        </ng-template>\n        <ng-template #defaultWeekViewAllDayEventSectionTemplate let-day=\"day\" let-eventTemplate=\"eventTemplate\">\n            <div [ngClass]=\"{'calendar-event-wrap': day.events}\" *ngIf=\"day.events\"\n                 [ngStyle]=\"{height: 25*day.events.length+'px'}\">\n                <div *ngFor=\"let displayEvent of day.events\" class=\"calendar-event\" tappable\n                     (click)=\"eventSelected(displayEvent.event)\"\n                     [ngStyle]=\"{top: 25*displayEvent.position+'px', width: 100*(displayEvent.endIndex-displayEvent.startIndex)+'%', height: '25px'}\">\n                    <ng-template [ngTemplateOutlet]=\"eventTemplate\"\n                                 [ngTemplateOutletContext]=\"{displayEvent:displayEvent}\">\n                    </ng-template>\n                </div>\n            </div>\n        </ng-template>\n        <ng-template #defaultDayViewAllDayEventSectionTemplate let-allDayEvents=\"allDayEvents\" let-eventTemplate=\"eventTemplate\">\n            <div *ngFor=\"let displayEvent of allDayEvents; let eventIndex=index\"\n                 class=\"calendar-event\" tappable\n                 (click)=\"eventSelected(displayEvent.event)\"\n                 [ngStyle]=\"{top: 25*eventIndex+'px',width: '100%',height:'25px'}\">\n                <ng-template [ngTemplateOutlet]=\"eventTemplate\"\n                             [ngTemplateOutletContext]=\"{displayEvent:displayEvent}\">\n                </ng-template>\n            </div>\n        </ng-template>\n        <ng-template #defaultNormalEventSectionTemplate let-tm=\"tm\" let-hourParts=\"hourParts\" let-eventTemplate=\"eventTemplate\">\n            <div [ngClass]=\"{'calendar-event-wrap': tm.events}\" *ngIf=\"tm.events\">\n                <div *ngFor=\"let displayEvent of tm.events\" class=\"calendar-event\" tappable\n                     (click)=\"eventSelected(displayEvent.event)\"\n                     [ngStyle]=\"{top: (37*displayEvent.startOffset/hourParts)+'px',left: 100/displayEvent.overlapNumber*displayEvent.position+'%', width: 100/displayEvent.overlapNumber+'%', height: 37*(displayEvent.endIndex -displayEvent.startIndex - (displayEvent.endOffset + displayEvent.startOffset)/hourParts)+'px'}\">\n                    <ng-template [ngTemplateOutlet]=\"eventTemplate\"\n                                 [ngTemplateOutletContext]=\"{displayEvent:displayEvent}\">\n                    </ng-template>\n                </div>\n            </div>\n        </ng-template>\n        <ng-template #defaultInactiveAllDayEventSectionTemplate>\n        </ng-template>\n        <ng-template #defaultInactiveNormalEventSectionTemplate>\n        </ng-template>\n\n        <div [ngSwitch]=\"calendarMode\" class=\"{{calendarMode}}view-container\">\n            <monthview *ngSwitchCase=\"'month'\"\n                [formatDay]=\"formatDay\"\n                [formatDayHeader]=\"formatDayHeader\"\n                [formatMonthTitle]=\"formatMonthTitle\"\n                [startingDayMonth]=\"startingDayMonth\"\n                [showEventDetail]=\"showEventDetail\"\n                [noEventsLabel]=\"noEventsLabel\"\n                [autoSelect]=\"autoSelect\"\n                [eventSource]=\"eventSource\"\n                [markDisabled]=\"markDisabled\"\n                [monthviewDisplayEventTemplate]=\"monthviewDisplayEventTemplate||monthviewDefaultDisplayEventTemplate\"\n                [monthviewInactiveDisplayEventTemplate]=\"monthviewInactiveDisplayEventTemplate||monthviewDefaultDisplayEventTemplate\"\n                [monthviewEventDetailTemplate]=\"monthviewEventDetailTemplate||monthviewDefaultEventDetailTemplate\"\n                [locale]=\"locale\"\n                [dateFormatter]=\"dateFormatter\"\n                [dir]=\"dir\"\n                [lockSwipeToPrev]=\"lockSwipeToPrev\"\n                [lockSwipes]=\"lockSwipes\"\n                [sliderOptions]=\"sliderOptions\"\n                (onRangeChanged)=\"rangeChanged($event)\"\n                (onEventSelected)=\"eventSelected($event)\"\n                (onTimeSelected)=\"timeSelected($event)\"\n                (onTitleChanged)=\"titleChanged($event)\">\n            </monthview>\n            <weekview *ngSwitchCase=\"'week'\"\n                [formatWeekTitle]=\"formatWeekTitle\"\n                [formatWeekViewDayHeader]=\"formatWeekViewDayHeader\"\n                [formatHourColumn]=\"formatHourColumn\"\n                [startingDayWeek]=\"startingDayWeek\"\n                [allDayLabel]=\"allDayLabel\"\n                [hourParts]=\"hourParts\"\n                [autoSelect]=\"autoSelect\"\n                [hourSegments]=\"hourSegments\"\n                [eventSource]=\"eventSource\"\n                [markDisabled]=\"markDisabled\"\n                [weekviewHeaderTemplate]=\"weekviewHeaderTemplate||defaultWeekviewHeaderTemplate\"\n                [weekviewAllDayEventTemplate]=\"weekviewAllDayEventTemplate||defaultAllDayEventTemplate\"\n                [weekviewNormalEventTemplate]=\"weekviewNormalEventTemplate||defaultNormalEventTemplate\"\n                [weekviewAllDayEventSectionTemplate]=\"weekviewAllDayEventSectionTemplate||defaultWeekViewAllDayEventSectionTemplate\"\n                [weekviewNormalEventSectionTemplate]=\"weekviewNormalEventSectionTemplate||defaultNormalEventSectionTemplate\"\n                [weekviewInactiveAllDayEventSectionTemplate]=\"weekviewInactiveAllDayEventSectionTemplate||defaultInactiveAllDayEventSectionTemplate\"\n                [weekviewInactiveNormalEventSectionTemplate]=\"weekviewInactiveNormalEventSectionTemplate||defaultInactiveNormalEventSectionTemplate\"\n                [locale]=\"locale\"\n                [dateFormatter]=\"dateFormatter\"\n                [dir]=\"dir\"\n                [scrollToHour]=\"scrollToHour\"\n                [preserveScrollPosition]=\"preserveScrollPosition\"\n                [lockSwipeToPrev]=\"lockSwipeToPrev\"\n                [lockSwipes]=\"lockSwipes\"\n                [startHour]=\"startHour\"\n                [endHour]=\"endHour\"\n                [sliderOptions]=\"sliderOptions\"\n                (onRangeChanged)=\"rangeChanged($event)\"\n                (onEventSelected)=\"eventSelected($event)\"\n                (onTimeSelected)=\"timeSelected($event)\"\n                (onTitleChanged)=\"titleChanged($event)\">\n            </weekview>\n            <dayview *ngSwitchCase=\"'day'\"\n                [formatDayTitle]=\"formatDayTitle\"\n                [formatHourColumn]=\"formatHourColumn\"\n                [allDayLabel]=\"allDayLabel\"\n                [hourParts]=\"hourParts\"\n                [hourSegments]=\"hourSegments\"\n                [eventSource]=\"eventSource\"\n                [markDisabled]=\"markDisabled\"\n                [dayviewAllDayEventTemplate]=\"dayviewAllDayEventTemplate||defaultAllDayEventTemplate\"\n                [dayviewNormalEventTemplate]=\"dayviewNormalEventTemplate||defaultNormalEventTemplate\"\n                [dayviewAllDayEventSectionTemplate]=\"dayviewAllDayEventSectionTemplate||defaultDayViewAllDayEventSectionTemplate\"\n                [dayviewNormalEventSectionTemplate]=\"dayviewNormalEventSectionTemplate||defaultNormalEventSectionTemplate\"\n                [dayviewInactiveAllDayEventSectionTemplate]=\"dayviewInactiveAllDayEventSectionTemplate||defaultInactiveAllDayEventSectionTemplate\"\n                [dayviewInactiveNormalEventSectionTemplate]=\"dayviewInactiveNormalEventSectionTemplate||defaultInactiveNormalEventSectionTemplate\"\n                [locale]=\"locale\"\n                [dateFormatter]=\"dateFormatter\"\n                [dir]=\"dir\"\n                [scrollToHour]=\"scrollToHour\"\n                [preserveScrollPosition]=\"preserveScrollPosition\"\n                [lockSwipeToPrev]=\"lockSwipeToPrev\"\n                [lockSwipes]=\"lockSwipes\"\n                [startHour]=\"startHour\"\n                [endHour]=\"endHour\"\n                [sliderOptions]=\"sliderOptions\"\n                (onRangeChanged)=\"rangeChanged($event)\"\n                (onEventSelected)=\"eventSelected($event)\"\n                (onTimeSelected)=\"timeSelected($event)\"\n                (onTitleChanged)=\"titleChanged($event)\">\n            </dayview>\n        </div>\n    ",
      providers: [CalendarService],
      styles: ["\n        :host > div { height: 100%; }\n\n        .event-detail-container {\n          border-top: 2px darkgrey solid;\n        }\n\n        .no-events-label {\n          font-weight: bold;\n          color: darkgrey;\n          text-align: center;\n        }\n\n        .event-detail {\n          cursor: pointer;\n          white-space: nowrap;\n          text-overflow: ellipsis;\n        }\n\n        .monthview-eventdetail-timecolumn {\n          width: 110px;\n          overflow: hidden;\n        }\n\n        .calendar-event-inner {\n          overflow: hidden;\n          background-color: #3a87ad;\n          color: white;\n          height: 100%;\n          width: 100%;\n          padding: 2px;\n          line-height: 15px;\n          text-align: initial;\n        }\n\n        @media (max-width: 750px) {\n          .calendar-event-inner {\n            font-size: 12px;\n          }\n        }\n    "]
    }), Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__param"])(1, Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Inject"])(_angular_core__WEBPACK_IMPORTED_MODULE_1__["LOCALE_ID"]))], CalendarComponent);

    var initPositionScrollComponent =
    /*#__PURE__*/
    function () {
      function initPositionScrollComponent(el) {
        _classCallCheck(this, initPositionScrollComponent);

        this.onScroll = new _angular_core__WEBPACK_IMPORTED_MODULE_1__["EventEmitter"]();
        this.listenerAttached = false;
        this.element = el;
      }

      _createClass(initPositionScrollComponent, [{
        key: "ngOnChanges",
        value: function ngOnChanges(changes) {
          var initPosition = changes['initPosition'];

          if (initPosition && initPosition.currentValue !== undefined && this.scrollContent) {
            var me = this;
            setTimeout(function () {
              me.scrollContent.scrollTop = initPosition.currentValue;
            }, 0);
          }
        }
      }, {
        key: "ngAfterViewInit",
        value: function ngAfterViewInit() {
          var scrollContent = this.scrollContent = this.element.nativeElement.querySelector('.scroll-content');

          if (this.initPosition !== undefined) {
            scrollContent.scrollTop = this.initPosition;
          }

          if (this.emitEvent && !this.listenerAttached) {
            var onScroll = this.onScroll;

            this.handler = function () {
              onScroll.emit(scrollContent.scrollTop);
            };

            this.listenerAttached = true;
            scrollContent.addEventListener('scroll', this.handler);
          }
        }
      }, {
        key: "ngOnDestroy",
        value: function ngOnDestroy() {
          if (this.listenerAttached) {
            this.scrollContent.removeEventListener('scroll', this.handler);
          }
        }
      }]);

      return initPositionScrollComponent;
    }();

    initPositionScrollComponent.ctorParameters = function () {
      return [{
        type: _angular_core__WEBPACK_IMPORTED_MODULE_1__["ElementRef"]
      }];
    };

    Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Input"])()], initPositionScrollComponent.prototype, "initPosition", void 0);
    Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Input"])()], initPositionScrollComponent.prototype, "emitEvent", void 0);
    Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Output"])()], initPositionScrollComponent.prototype, "onScroll", void 0);
    initPositionScrollComponent = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
      selector: 'init-position-scroll',
      template: "\n        <div class=\"scroll-content\" style=\"height:100%\">\n            <ng-content></ng-content>\n        </div>\n    ",
      encapsulation: _angular_core__WEBPACK_IMPORTED_MODULE_1__["ViewEncapsulation"].None,
      styles: ["\n        .scroll-content {\n            overflow-y: auto;\n            overflow-x: hidden;\n        }        \n    "]
    })], initPositionScrollComponent);

    var NgCalendarModule = function NgCalendarModule() {
      _classCallCheck(this, NgCalendarModule);
    };

    NgCalendarModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
      declarations: [MonthViewComponent, WeekViewComponent, DayViewComponent, CalendarComponent, initPositionScrollComponent],
      imports: [_ionic_angular__WEBPACK_IMPORTED_MODULE_3__["IonicModule"], _angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"]],
      exports: [CalendarComponent]
    })], NgCalendarModule);
    /**
     * Generated bundle index. Do not edit.
     */
    //# sourceMappingURL=ionic2-calendar.js.map

    /***/
  },

  /***/
  "./node_modules/raw-loader/dist/cjs.js!./src/app/calender/calender.page.html":
  /*!***********************************************************************************!*\
    !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/calender/calender.page.html ***!
    \***********************************************************************************/

  /*! exports provided: default */

  /***/
  function node_modulesRawLoaderDistCjsJsSrcAppCalenderCalenderPageHtml(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony default export */


    __webpack_exports__["default"] = "<ion-header>\n  <ion-toolbar class=\"customize-toolbar\">\n    <ion-buttons slot=\"start\">\n      <ion-back-button text=\"\" color=\"light\"></ion-back-button>\n    </ion-buttons>\n    <ion-img class=\"logo p-3\" src=\"assets/img/logo.png\"></ion-img>\n  </ion-toolbar>\n</ion-header>\n\n\n\n  <div class=\"app-layout\">\n    <div class=\"container\">\n      <div class=\"heading\">\n        <h3>STAFF CALENDAR SYSTEM</h3>\n      </div>  \n</div>\n</div>\n<div class=\"text-center\">\n  <ion-buttons class=\"mt-2 mb-3\">\n    <button class=\"btn btn-primary\" ion-button [disabled]=\"isToday\" (click)=\"today()\">Today</button>\n    <button class=\"btn btn-primary ml-2\" ion-button (click)=\"changeMode('month')\">Month</button>\n    <button class=\"btn btn-primary ml-2\" ion-button (click)=\"changeMode('week')\">Week</button>\n    <button class=\"btn btn-primary ml-2\" ion-button (click)=\"changeMode('day')\">Day</button>\n  </ion-buttons>\n</div>\n\n<ion-content >\n\n    <calendar [eventSource]=\"eventSource\"\n              [calendarMode]=\"calendar.mode\"\n              [currentDate]=\"calendar.currentDate\"\n              (onCurrentDateChanged)=\"onCurrentDateChanged($event)\"\n              (onEventSelected)=\"onEventSelected($event)\"\n              (onTitleChanged)=\"onViewTitleChanged($event)\"\n              (onTimeSelected)=\"onTimeSelected($event)\"\n              step=\"30\">\n    </calendar>\n  </ion-content>\n\n\n\n";
    /***/
  },

  /***/
  "./src/app/calender/calender-routing.module.ts":
  /*!*****************************************************!*\
    !*** ./src/app/calender/calender-routing.module.ts ***!
    \*****************************************************/

  /*! exports provided: CalenderPageRoutingModule */

  /***/
  function srcAppCalenderCalenderRoutingModuleTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "CalenderPageRoutingModule", function () {
      return CalenderPageRoutingModule;
    });
    /* harmony import */


    var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! tslib */
    "./node_modules/tslib/tslib.es6.js");
    /* harmony import */


    var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! @angular/core */
    "./node_modules/@angular/core/fesm2015/core.js");
    /* harmony import */


    var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
    /*! @angular/router */
    "./node_modules/@angular/router/fesm2015/router.js");
    /* harmony import */


    var _calender_page__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
    /*! ./calender.page */
    "./src/app/calender/calender.page.ts");

    var routes = [{
      path: '',
      component: _calender_page__WEBPACK_IMPORTED_MODULE_3__["CalenderPage"]
    }, {
      path: 'add-event',
      loadChildren: function loadChildren() {
        return __webpack_require__.e(
        /*! import() | add-event-add-event-module */
        "add-event-add-event-module").then(__webpack_require__.bind(null,
        /*! ./add-event/add-event.module */
        "./src/app/calender/add-event/add-event.module.ts")).then(function (m) {
          return m.AddEventPageModule;
        });
      }
    }];

    var CalenderPageRoutingModule = function CalenderPageRoutingModule() {
      _classCallCheck(this, CalenderPageRoutingModule);
    };

    CalenderPageRoutingModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
      imports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"].forChild(routes)],
      exports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"]]
    })], CalenderPageRoutingModule);
    /***/
  },

  /***/
  "./src/app/calender/calender.module.ts":
  /*!*********************************************!*\
    !*** ./src/app/calender/calender.module.ts ***!
    \*********************************************/

  /*! exports provided: CalenderPageModule */

  /***/
  function srcAppCalenderCalenderModuleTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "CalenderPageModule", function () {
      return CalenderPageModule;
    });
    /* harmony import */


    var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! tslib */
    "./node_modules/tslib/tslib.es6.js");
    /* harmony import */


    var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! @angular/core */
    "./node_modules/@angular/core/fesm2015/core.js");
    /* harmony import */


    var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
    /*! @angular/common */
    "./node_modules/@angular/common/fesm2015/common.js");
    /* harmony import */


    var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
    /*! @angular/forms */
    "./node_modules/@angular/forms/fesm2015/forms.js");
    /* harmony import */


    var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(
    /*! @ionic/angular */
    "./node_modules/@ionic/angular/fesm2015/ionic-angular.js");
    /* harmony import */


    var _calender_routing_module__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(
    /*! ./calender-routing.module */
    "./src/app/calender/calender-routing.module.ts");
    /* harmony import */


    var ionic2_calendar__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(
    /*! ionic2-calendar */
    "./node_modules/ionic2-calendar/fesm2015/ionic2-calendar.js");
    /* harmony import */


    var _calender_page__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(
    /*! ./calender.page */
    "./src/app/calender/calender.page.ts");

    var CalenderPageModule = function CalenderPageModule() {
      _classCallCheck(this, CalenderPageModule);
    };

    CalenderPageModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
      imports: [_angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"], _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormsModule"], _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["IonicModule"], ionic2_calendar__WEBPACK_IMPORTED_MODULE_6__["NgCalendarModule"], _calender_routing_module__WEBPACK_IMPORTED_MODULE_5__["CalenderPageRoutingModule"]],
      declarations: [_calender_page__WEBPACK_IMPORTED_MODULE_7__["CalenderPage"]]
    })], CalenderPageModule);
    /***/
  },

  /***/
  "./src/app/calender/calender.page.scss":
  /*!*********************************************!*\
    !*** ./src/app/calender/calender.page.scss ***!
    \*********************************************/

  /*! exports provided: default */

  /***/
  function srcAppCalenderCalenderPageScss(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony default export */


    __webpack_exports__["default"] = ".select-staff {\n  margin-bottom: 20px;\n}\n\n.button-native::after {\n  left: 0px;\n  right: 0px;\n  top: 0px;\n  bottom: 0px;\n  position: absolute;\n  content: \"\";\n  opacity: 0 !important;\n  background: red;\n  --background:#000 !important;\n  width: 10px;\n  height: 10px;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvY2FsZW5kZXIvRTpcXHNoaXBnaWdcXGNva2tpZS1hcHAvc3JjXFxhcHBcXGNhbGVuZGVyXFxjYWxlbmRlci5wYWdlLnNjc3MiLCJzcmMvYXBwL2NhbGVuZGVyL2NhbGVuZGVyLnBhZ2Uuc2NzcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQTtFQUNJLG1CQUFBO0FDQ0o7O0FEQ0E7RUFDSSxTQUFBO0VBQ0EsVUFBQTtFQUNBLFFBQUE7RUFDQSxXQUFBO0VBQ0Esa0JBQUE7RUFDQSxXQUFBO0VBQ0EscUJBQUE7RUFDQSxlQUFBO0VBQ0EsNEJBQUE7RUFDQSxXQUFBO0VBQ0EsWUFBQTtBQ0VKIiwiZmlsZSI6InNyYy9hcHAvY2FsZW5kZXIvY2FsZW5kZXIucGFnZS5zY3NzIiwic291cmNlc0NvbnRlbnQiOlsiLnNlbGVjdC1zdGFmZntcclxuICAgIG1hcmdpbi1ib3R0b206IDIwcHg7XHJcbn1cclxuLmJ1dHRvbi1uYXRpdmU6OmFmdGVyIHtcclxuICAgIGxlZnQ6IDBweDtcclxuICAgIHJpZ2h0OiAwcHg7XHJcbiAgICB0b3A6IDBweDtcclxuICAgIGJvdHRvbTogMHB4O1xyXG4gICAgcG9zaXRpb246IGFic29sdXRlO1xyXG4gICAgY29udGVudDogXCJcIjtcclxuICAgIG9wYWNpdHk6IDAgIWltcG9ydGFudDtcclxuICAgIGJhY2tncm91bmQ6IHJlZDtcclxuICAgIC0tYmFja2dyb3VuZDojMDAwICFpbXBvcnRhbnQ7XHJcbiAgICB3aWR0aDogMTBweDtcclxuICAgIGhlaWdodDogMTBweDtcclxufSIsIi5zZWxlY3Qtc3RhZmYge1xuICBtYXJnaW4tYm90dG9tOiAyMHB4O1xufVxuXG4uYnV0dG9uLW5hdGl2ZTo6YWZ0ZXIge1xuICBsZWZ0OiAwcHg7XG4gIHJpZ2h0OiAwcHg7XG4gIHRvcDogMHB4O1xuICBib3R0b206IDBweDtcbiAgcG9zaXRpb246IGFic29sdXRlO1xuICBjb250ZW50OiBcIlwiO1xuICBvcGFjaXR5OiAwICFpbXBvcnRhbnQ7XG4gIGJhY2tncm91bmQ6IHJlZDtcbiAgLS1iYWNrZ3JvdW5kOiMwMDAgIWltcG9ydGFudDtcbiAgd2lkdGg6IDEwcHg7XG4gIGhlaWdodDogMTBweDtcbn0iXX0= */";
    /***/
  },

  /***/
  "./src/app/calender/calender.page.ts":
  /*!*******************************************!*\
    !*** ./src/app/calender/calender.page.ts ***!
    \*******************************************/

  /*! exports provided: CalenderPage */

  /***/
  function srcAppCalenderCalenderPageTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "CalenderPage", function () {
      return CalenderPage;
    });
    /* harmony import */


    var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! tslib */
    "./node_modules/tslib/tslib.es6.js");
    /* harmony import */


    var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! @angular/core */
    "./node_modules/@angular/core/fesm2015/core.js");
    /* harmony import */


    var _services_category_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
    /*! ../services/category.service */
    "./src/app/services/category.service.ts");

    var CalenderPage =
    /*#__PURE__*/
    function () {
      function CalenderPage(categoryService) {
        _classCallCheck(this, CalenderPage);

        this.categoryService = categoryService;
        this.eventSource = [];
        this.apiSource = [];
        this.calendar = {
          mode: 'month',
          currentDate: new Date(),
          dateFormatter: {
            formatMonthViewDay: function formatMonthViewDay(date) {
              return date.getDate().toString();
            },
            formatMonthViewDayHeader: function formatMonthViewDayHeader(date) {
              return 'MonMH';
            },
            formatMonthViewTitle: function formatMonthViewTitle(date) {
              return 'testMT';
            },
            formatWeekViewDayHeader: function formatWeekViewDayHeader(date) {
              return 'MonWH';
            },
            formatWeekViewTitle: function formatWeekViewTitle(date) {
              return 'testWT';
            },
            formatWeekViewHourColumn: function formatWeekViewHourColumn(date) {
              return 'testWH';
            },
            formatDayViewHourColumn: function formatDayViewHourColumn(date) {
              return 'testDH';
            },
            formatDayViewTitle: function formatDayViewTitle(date) {
              return 'testDT';
            }
          }
        };

        this.markDisabled = function (date) {
          var current = new Date();
          current.setHours(0, 0, 0);
          return date < current;
        };
      }

      _createClass(CalenderPage, [{
        key: "ngOnInit",
        value: function ngOnInit() {
          this.loadEvents();
        } // loadEvents() {
        //     this.eventSource = this.getEvents();
        // }

      }, {
        key: "onViewTitleChanged",
        value: function onViewTitleChanged(title) {
          this.viewTitle = title;
        }
      }, {
        key: "onEventSelected",
        value: function onEventSelected(event) {
          console.log('Event selected:' + event.startTime + '-' + event.endTime + ',' + event.title);
        }
      }, {
        key: "changeMode",
        value: function changeMode(mode) {
          this.calendar.mode = mode;
        }
      }, {
        key: "today",
        value: function today() {
          this.calendar.currentDate = new Date();
          console.log("tt", new Date());
        }
      }, {
        key: "onTimeSelected",
        value: function onTimeSelected(ev) {
          console.log('Selected time: ' + ev.selectedTime + ', hasEvents: ' + (ev.events !== undefined && ev.events.length !== 0) + ', disabled: ' + ev.disabled);
        }
      }, {
        key: "onCurrentDateChanged",
        value: function onCurrentDateChanged(event) {
          var today = new Date();
          today.setHours(0, 0, 0, 0);
          event.setHours(0, 0, 0, 0);
          this.isToday = today.getTime() === event.getTime();
        }
      }, {
        key: "loadEvents",
        value: function loadEvents() {
          var _this8 = this;

          this.categoryService.getScheduleData().subscribe(function (res) {
            console.log("res", res);

            if (res['data']) {
              _this8.apiSource = res['data'];
              _this8.eventSource = _this8.apiSource.map(function (item) {
                return {
                  title: item.title,
                  startTime: new Date(item.starttime),
                  endTime: new Date(item.endtime),
                  allDay: false
                };
              });
              console.log("ttr", _this8.eventSource);
            }
          }, function (err) {
            console.log("err", err);
          });
        } //   createRandomEvents() {
        //       var events = [];
        //       for (var i = 0; i < 50; i += 1) {
        //           var date = new Date();
        //           var eventType = Math.floor(Math.random() * 2);
        //           var startDay = Math.floor(Math.random() * 90) - 45;
        //           var endDay = Math.floor(Math.random() * 2) + startDay;
        //           var startTime;
        //           var endTime;
        //           if (eventType === 0) {
        //               startTime = new Date(Date.UTC(date.getUTCFullYear(), date.getUTCMonth(), date.getUTCDate() + startDay));
        //               if (endDay === startDay) {
        //                   endDay += 1;
        //               }
        //               endTime = new Date(Date.UTC(date.getUTCFullYear(), date.getUTCMonth(), date.getUTCDate() + endDay));
        //               events.push({
        //                   title: 'All Day - ' + i,
        //                   startTime: startTime,
        //                   endTime: endTime,
        //                   allDay: true
        //               });
        //           } else {
        //               var startMinute = Math.floor(Math.random() * 24 * 60);
        //               var endMinute = Math.floor(Math.random() * 180) + startMinute;
        //               startTime = new Date(date.getFullYear(), date.getMonth(), date.getDate() + startDay, 0, date.getMinutes() + startMinute);
        //               endTime = new Date(date.getFullYear(), date.getMonth(), date.getDate() + endDay, 0, date.getMinutes() + endMinute);
        //               events.push({
        //                   title: 'Event - ' + i,
        //                   startTime: startTime,
        //                   endTime: endTime,
        //                   allDay: false
        //               });
        //           }
        //       }
        //       return events;
        //   }

      }, {
        key: "onRangeChanged",
        value: function onRangeChanged(ev) {
          console.log('range changed: startTime: ' + ev.startTime + ', endTime: ' + ev.endTime);
        }
      }]);

      return CalenderPage;
    }();

    CalenderPage.ctorParameters = function () {
      return [{
        type: _services_category_service__WEBPACK_IMPORTED_MODULE_2__["CategoryService"]
      }];
    };

    CalenderPage = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
      selector: 'app-calender',
      template: tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(
      /*! raw-loader!./calender.page.html */
      "./node_modules/raw-loader/dist/cjs.js!./src/app/calender/calender.page.html")).default,
      styles: [tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(
      /*! ./calender.page.scss */
      "./src/app/calender/calender.page.scss")).default]
    }), tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_services_category_service__WEBPACK_IMPORTED_MODULE_2__["CategoryService"]])], CalenderPage);
    /***/
  }
}]);
//# sourceMappingURL=calender-calender-module-es5.js.map
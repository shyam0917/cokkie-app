(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["home-home-module"],{

/***/ "./node_modules/raw-loader/dist/cjs.js!./src/app/home/home.page.html":
/*!***************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/home/home.page.html ***!
  \***************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("<ion-header>\n  <ion-toolbar class=\"customize-toolbar\">\n    <ion-buttons slot=\"start\">\n      <ion-menu-button color=\"dark\"></ion-menu-button>\n    </ion-buttons>\n    <ion-img class=\"logo p-3\" src=\"assets/img/logo.png\"></ion-img>\n  </ion-toolbar>\n</ion-header>\n\n<ion-content>\n  <div class=\"app-layout\">\n    <div class=\"container\">\n      <div class=\"heading\">\n        <h3>STAFF PORTAL</h3>\n        <div class=\"date\"> {{getCurrentDate | date}} {{getCurrentDate | date:'shortTime'}}</div>\n      </div>\n      <div class=\"app-content\">\n        <div class=\"row\">\n          <div class=\"col-4\">\n            <div class=\"icon-box\" routerLink=\"/calender\">\n\n              <img src=\"assets/img/icon-1.png\">\n              <p>SCHEDULE</p>\n              <div *ngIf=\"appointmentArray.length>0\" class=\"notification\">\n                <p>{{appointmentArray.length}}</p>\n              </div>\n            </div>\n          </div>\n          <div class=\"col-4\">\n            <div class=\"icon-box\" routerLink=\"/main-list/1\">\n              <img src=\"assets/img/icon-2.png\">\n              <p>CLIENTS</p>\n            </div>\n          </div>\n          <div class=\"col-4\">\n            <div class=\"icon-box bg-secondary\" [attr.disabled]=true>\n              <img src=\"assets/img/icon-3.png\">\n              <p>CLOCK IN/OUT</p>\n            </div>\n          </div>\n          <div class=\"col-4\">\n            <div class=\"icon-box\" routerLink=\"/main-list/3\">\n              <img src=\"assets/img/icon-4.png\">\n              <p>PROJECTS</p>\n            </div>\n          </div>\n          <div class=\"col-4\">\n            <div class=\"icon-box bg-secondary\">\n              <img src=\"assets/img/icon-5.png\">\n              <p>PROJ PHOTO</p>\n            </div>\n          </div>\n          <!-- routerLink=\"/main-list/7\" -->\n          <div class=\"col-4\">\n            <div class=\"icon-box\"  routerLink=\"/main-list/7\">\n              <img src=\"assets/img/icon-6.png\" >\n              <p>RECEIPT UPLOAD</p>\n            </div>\n          </div>\n          <div class=\"col-4\">\n            <div class=\"icon-box\" routerLink=\"/main-list/4\">\n              <img src=\"assets/img/icon-7.png\">\n              <p>INVOICES</p>\n            </div>\n          </div>\n          <div class=\"col-4\">\n            <div class=\"icon-box\" routerLink=\"/main-list/5\">\n              <img src=\"assets/img/icon-8.png\">\n              <p>ESTIMATE</p>\n            </div>\n          </div>\n          <div class=\"col-4\">\n            <div class=\"icon-box\" routerLink=\"/main-list/6\">\n              <img src=\"assets/img/icon-9.png\">\n              <p>PAYMENT</p>\n            </div>\n          </div>\n          <div class=\"col-4\">\n            <div class=\"icon-box bg-secondary\" [attr.disabled]=true>\n              <img src=\"assets/img/icon-9.png\">\n              <p>Check PAYMENT</p>\n            </div>\n          </div>\n          <div class=\"col-4\">\n            <div class=\"icon-box\" routerLink=\"/main-list/8\">\n              <img src=\"assets/img/icon-11.png\">\n              <p>View All Work Orders</p>\n            </div>\n          </div>\n          <div class=\"col-4\">\n            <div class=\"icon-box\" routerLink=\"/iframe-form/1\">\n              <img src=\"assets/img/icon-12.png\">\n              <p>Create Service Work Order</p>\n            </div>\n          </div>\n          <div class=\"col-4\">\n            <div class=\"icon-box\" routerLink=\"/iframe-form/2\">\n              <img src=\"assets/img/icon-13.png\">\n              <p>Create Electrical work order</p>\n            </div>\n          </div>\n        </div>\n      </div>\n      <div class=\"appointment\">\n        <h3>TODAYS APPOINTMENTS</h3>\n        <div class=\"appointment-detail\">\n          <p *ngFor=\"let appointment of appointmentArray; let i =index\">{{appointment.starttime | date:'shortTime'}} - #{{i+1}} {{appointment.title}} </p>\n        </div>\n      </div>\n    </div>\n  </div>\n</ion-content>");

/***/ }),

/***/ "./src/app/home/home-routing.module.ts":
/*!*********************************************!*\
  !*** ./src/app/home/home-routing.module.ts ***!
  \*********************************************/
/*! exports provided: HomePageRoutingModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "HomePageRoutingModule", function() { return HomePageRoutingModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm2015/core.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm2015/router.js");
/* harmony import */ var _home_page__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./home.page */ "./src/app/home/home.page.ts");




const routes = [
    {
        path: '',
        component: _home_page__WEBPACK_IMPORTED_MODULE_3__["HomePage"]
    }
];
let HomePageRoutingModule = class HomePageRoutingModule {
};
HomePageRoutingModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"].forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"]],
    })
], HomePageRoutingModule);



/***/ }),

/***/ "./src/app/home/home.module.ts":
/*!*************************************!*\
  !*** ./src/app/home/home.module.ts ***!
  \*************************************/
/*! exports provided: HomePageModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "HomePageModule", function() { return HomePageModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm2015/core.js");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/fesm2015/common.js");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/forms */ "./node_modules/@angular/forms/fesm2015/forms.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/fesm2015/ionic-angular.js");
/* harmony import */ var _home_routing_module__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./home-routing.module */ "./src/app/home/home-routing.module.ts");
/* harmony import */ var _home_page__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./home.page */ "./src/app/home/home.page.ts");







let HomePageModule = class HomePageModule {
};
HomePageModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"],
            _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormsModule"],
            _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["IonicModule"],
            _home_routing_module__WEBPACK_IMPORTED_MODULE_5__["HomePageRoutingModule"]
        ],
        declarations: [_home_page__WEBPACK_IMPORTED_MODULE_6__["HomePage"]]
    })
], HomePageModule);



/***/ }),

/***/ "./src/app/home/home.page.scss":
/*!*************************************!*\
  !*** ./src/app/home/home.page.scss ***!
  \*************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = (".bg-secondary {\n  background-color: #4a4a4a !important;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvaG9tZS9FOlxcc2hpcGdpZ1xcY29ra2llLWFwcC9zcmNcXGFwcFxcaG9tZVxcaG9tZS5wYWdlLnNjc3MiLCJzcmMvYXBwL2hvbWUvaG9tZS5wYWdlLnNjc3MiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUE7RUFDSSxvQ0FBQTtBQ0NKIiwiZmlsZSI6InNyYy9hcHAvaG9tZS9ob21lLnBhZ2Uuc2NzcyIsInNvdXJjZXNDb250ZW50IjpbIi5iZy1zZWNvbmRhcnkge1xuICAgIGJhY2tncm91bmQtY29sb3I6ICM0YTRhNGEgIWltcG9ydGFudFxufSIsIi5iZy1zZWNvbmRhcnkge1xuICBiYWNrZ3JvdW5kLWNvbG9yOiAjNGE0YTRhICFpbXBvcnRhbnQ7XG59Il19 */");

/***/ }),

/***/ "./src/app/home/home.page.ts":
/*!***********************************!*\
  !*** ./src/app/home/home.page.ts ***!
  \***********************************/
/*! exports provided: HomePage */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "HomePage", function() { return HomePage; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm2015/core.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm2015/router.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/fesm2015/ionic-angular.js");
/* harmony import */ var _services_category_service__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../services/category.service */ "./src/app/services/category.service.ts");





let HomePage = class HomePage {
    constructor(router, menu, categoryService) {
        this.router = router;
        this.menu = menu;
        this.categoryService = categoryService;
        this.appointmentArray = [];
        this.getCurrentDate = "";
        this.getCurrentDate = new Date();
    }
    ngOnInit() {
        this.getAppointments();
    }
    ionViewDidEnter() {
        this.menu.swipeGesture(true);
        this.getCurrentDate = new Date();
    }
    getAppointments() {
        this.categoryService.getScheduleData().subscribe(res => {
            if (res['data']) {
                this.appointmentArray = res['data'];
                let currDate = new Date();
                this.appointmentArray = this.appointmentArray.filter(item => {
                    if (currDate >= new Date(item.startdatetime) && currDate <= new Date(item.enddatetime)) {
                        return item;
                    }
                });
                console.log("ar", this.appointmentArray);
            }
            console.log("res", res);
        }, err => {
            console.log("Err", err);
        });
    }
};
HomePage.ctorParameters = () => [
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_2__["Router"] },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_3__["MenuController"] },
    { type: _services_category_service__WEBPACK_IMPORTED_MODULE_4__["CategoryService"] }
];
HomePage = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
        selector: 'app-home',
        template: tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(/*! raw-loader!./home.page.html */ "./node_modules/raw-loader/dist/cjs.js!./src/app/home/home.page.html")).default,
        styles: [tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(/*! ./home.page.scss */ "./src/app/home/home.page.scss")).default]
    }),
    tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_angular_router__WEBPACK_IMPORTED_MODULE_2__["Router"],
        _ionic_angular__WEBPACK_IMPORTED_MODULE_3__["MenuController"],
        _services_category_service__WEBPACK_IMPORTED_MODULE_4__["CategoryService"]])
], HomePage);



/***/ })

}]);
//# sourceMappingURL=home-home-module-es2015.js.map
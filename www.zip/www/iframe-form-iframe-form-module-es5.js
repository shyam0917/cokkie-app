function _defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } }

function _createClass(Constructor, protoProps, staticProps) { if (protoProps) _defineProperties(Constructor.prototype, protoProps); if (staticProps) _defineProperties(Constructor, staticProps); return Constructor; }

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["iframe-form-iframe-form-module"], {
  /***/
  "./node_modules/raw-loader/dist/cjs.js!./src/app/iframe-form/iframe-form.page.html":
  /*!*****************************************************************************************!*\
    !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/iframe-form/iframe-form.page.html ***!
    \*****************************************************************************************/

  /*! exports provided: default */

  /***/
  function node_modulesRawLoaderDistCjsJsSrcAppIframeFormIframeFormPageHtml(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony default export */


    __webpack_exports__["default"] = "<ion-header>\n  <ion-toolbar class=\"customize-toolbar\">\n    <ion-buttons slot=\"start\">\n      <ion-back-button text=\"\" color=\"dark\"></ion-back-button>\n    </ion-buttons>\n    <ion-img class=\"logo p-3\" src=\"assets/img/logo.png\"></ion-img>\n  </ion-toolbar>\n</ion-header>\n\n<ion-content *ngIf=\"switch=='1'\"> \n  <iframe class='webPage' src=\"https://cands.ca/candsproject/mechanical.php\" allowfullscreen></iframe>\n</ion-content>\n\n\n<ion-content style=\"position: absolute;\" *ngIf=\"switch=='2'\"> \n  <iframe class='webPage' src=\"https://cands.ca/candsproject/electrical.php\" allowfullscreen></iframe>\n</ion-content>\n\n<ion-content *ngIf=\"switch=='3'\"> \n  <iframe class='webPage' [src]=\"editUrl.url\"  allowfullscreen></iframe>\n</ion-content>";
    /***/
  },

  /***/
  "./src/app/iframe-form/iframe-form-routing.module.ts":
  /*!***********************************************************!*\
    !*** ./src/app/iframe-form/iframe-form-routing.module.ts ***!
    \***********************************************************/

  /*! exports provided: IframeFormPageRoutingModule */

  /***/
  function srcAppIframeFormIframeFormRoutingModuleTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "IframeFormPageRoutingModule", function () {
      return IframeFormPageRoutingModule;
    });
    /* harmony import */


    var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! tslib */
    "./node_modules/tslib/tslib.es6.js");
    /* harmony import */


    var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! @angular/core */
    "./node_modules/@angular/core/fesm2015/core.js");
    /* harmony import */


    var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
    /*! @angular/router */
    "./node_modules/@angular/router/fesm2015/router.js");
    /* harmony import */


    var _iframe_form_page__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
    /*! ./iframe-form.page */
    "./src/app/iframe-form/iframe-form.page.ts");

    var routes = [{
      path: '',
      component: _iframe_form_page__WEBPACK_IMPORTED_MODULE_3__["IframeFormPage"]
    }];

    var IframeFormPageRoutingModule = function IframeFormPageRoutingModule() {
      _classCallCheck(this, IframeFormPageRoutingModule);
    };

    IframeFormPageRoutingModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
      imports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"].forChild(routes)],
      exports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"]]
    })], IframeFormPageRoutingModule);
    /***/
  },

  /***/
  "./src/app/iframe-form/iframe-form.module.ts":
  /*!***************************************************!*\
    !*** ./src/app/iframe-form/iframe-form.module.ts ***!
    \***************************************************/

  /*! exports provided: IframeFormPageModule */

  /***/
  function srcAppIframeFormIframeFormModuleTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "IframeFormPageModule", function () {
      return IframeFormPageModule;
    });
    /* harmony import */


    var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! tslib */
    "./node_modules/tslib/tslib.es6.js");
    /* harmony import */


    var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! @angular/core */
    "./node_modules/@angular/core/fesm2015/core.js");
    /* harmony import */


    var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
    /*! @angular/common */
    "./node_modules/@angular/common/fesm2015/common.js");
    /* harmony import */


    var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
    /*! @angular/forms */
    "./node_modules/@angular/forms/fesm2015/forms.js");
    /* harmony import */


    var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(
    /*! @ionic/angular */
    "./node_modules/@ionic/angular/fesm2015/ionic-angular.js");
    /* harmony import */


    var _iframe_form_routing_module__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(
    /*! ./iframe-form-routing.module */
    "./src/app/iframe-form/iframe-form-routing.module.ts");
    /* harmony import */


    var _iframe_form_page__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(
    /*! ./iframe-form.page */
    "./src/app/iframe-form/iframe-form.page.ts");

    var IframeFormPageModule = function IframeFormPageModule() {
      _classCallCheck(this, IframeFormPageModule);
    };

    IframeFormPageModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
      imports: [_angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"], _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormsModule"], _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["IonicModule"], _iframe_form_routing_module__WEBPACK_IMPORTED_MODULE_5__["IframeFormPageRoutingModule"]],
      declarations: [_iframe_form_page__WEBPACK_IMPORTED_MODULE_6__["IframeFormPage"]]
    })], IframeFormPageModule);
    /***/
  },

  /***/
  "./src/app/iframe-form/iframe-form.page.scss":
  /*!***************************************************!*\
    !*** ./src/app/iframe-form/iframe-form.page.scss ***!
    \***************************************************/

  /*! exports provided: default */

  /***/
  function srcAppIframeFormIframeFormPageScss(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony default export */


    __webpack_exports__["default"] = ".webPage {\n  width: 100%;\n  height: 600px;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvaWZyYW1lLWZvcm0vRTpcXHNoaXBnaWdcXGNva2tpZS1hcHAvc3JjXFxhcHBcXGlmcmFtZS1mb3JtXFxpZnJhbWUtZm9ybS5wYWdlLnNjc3MiLCJzcmMvYXBwL2lmcmFtZS1mb3JtL2lmcmFtZS1mb3JtLnBhZ2Uuc2NzcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQTtFQUNJLFdBQUE7RUFDQSxhQUFBO0FDQ0oiLCJmaWxlIjoic3JjL2FwcC9pZnJhbWUtZm9ybS9pZnJhbWUtZm9ybS5wYWdlLnNjc3MiLCJzb3VyY2VzQ29udGVudCI6WyIud2ViUGFnZXtcclxuICAgIHdpZHRoOiAxMDAlO1xyXG4gICAgaGVpZ2h0OiA2MDBweDtcclxuICB9IiwiLndlYlBhZ2Uge1xuICB3aWR0aDogMTAwJTtcbiAgaGVpZ2h0OiA2MDBweDtcbn0iXX0= */";
    /***/
  },

  /***/
  "./src/app/iframe-form/iframe-form.page.ts":
  /*!*************************************************!*\
    !*** ./src/app/iframe-form/iframe-form.page.ts ***!
    \*************************************************/

  /*! exports provided: IframeFormPage */

  /***/
  function srcAppIframeFormIframeFormPageTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "IframeFormPage", function () {
      return IframeFormPage;
    });
    /* harmony import */


    var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! tslib */
    "./node_modules/tslib/tslib.es6.js");
    /* harmony import */


    var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! @angular/core */
    "./node_modules/@angular/core/fesm2015/core.js");
    /* harmony import */


    var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
    /*! @angular/router */
    "./node_modules/@angular/router/fesm2015/router.js");

    var IframeFormPage =
    /*#__PURE__*/
    function () {
      function IframeFormPage(activatedRoute, router) {
        _classCallCheck(this, IframeFormPage);

        this.activatedRoute = activatedRoute;
        this.router = router;
        this.editUrl = {};
        this.editUrl = this.router.getCurrentNavigation().extras.state;
      }

      _createClass(IframeFormPage, [{
        key: "ngOnInit",
        value: function ngOnInit() {
          console.log("Ere", this.editUrl);
          this.switch = this.activatedRoute.snapshot.paramMap.get('id');
        }
      }]);

      return IframeFormPage;
    }();

    IframeFormPage.ctorParameters = function () {
      return [{
        type: _angular_router__WEBPACK_IMPORTED_MODULE_2__["ActivatedRoute"]
      }, {
        type: _angular_router__WEBPACK_IMPORTED_MODULE_2__["Router"]
      }];
    };

    IframeFormPage = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
      selector: 'app-iframe-form',
      template: tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(
      /*! raw-loader!./iframe-form.page.html */
      "./node_modules/raw-loader/dist/cjs.js!./src/app/iframe-form/iframe-form.page.html")).default,
      styles: [tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(
      /*! ./iframe-form.page.scss */
      "./src/app/iframe-form/iframe-form.page.scss")).default]
    }), tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_angular_router__WEBPACK_IMPORTED_MODULE_2__["ActivatedRoute"], _angular_router__WEBPACK_IMPORTED_MODULE_2__["Router"]])], IframeFormPage);
    /***/
  }
}]);
//# sourceMappingURL=iframe-form-iframe-form-module-es5.js.map
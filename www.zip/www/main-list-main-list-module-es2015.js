(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["main-list-main-list-module"],{

/***/ "./node_modules/raw-loader/dist/cjs.js!./src/app/main-list/main-list.page.html":
/*!*************************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/main-list/main-list.page.html ***!
  \*************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("<ion-header>\n  <ion-toolbar class=\"customize-toolbar\">\n    <ion-buttons slot=\"start\">\n      <ion-back-button text=\"\" color=\"light\"></ion-back-button>\n    </ion-buttons>\n    <ion-img class=\"logo p-3\" src=\"assets/img/logo.png\"></ion-img>\n  </ion-toolbar>\n</ion-header>\n\n<iframe *ngIf=\"switch=='6'\" class='webPage' src=\"https://cands.ca/one_timepmnt.php\" allowfullscreen></iframe>\n\n<div *ngIf=\"errorMessage\" class=\"text-center text-danger\">{{errMessage}}</div>\n\n<div class=\"ion-text-center\" *ngIf=\"isLoading\">\n  <ion-spinner name=\"crescent\" color=\"primary\"></ion-spinner>\n</div>\n\n<ion-content *ngIf=\"switch!='6'\">\n  <div class=\"app-layout set-height\">\n    <div class=\"container\">\n      <div class=\"heading\">\n        <h3 *ngIf=\"switch=='1'\">CLIENTS</h3>\n        <h3 *ngIf=\"switch=='2'\">CLOCK IN/OUT</h3>\n        <h3 *ngIf=\"switch=='3'\">PROJECTS</h3>\n        <h3 *ngIf=\"switch=='4'\">INVOICES</h3>\n        <h3 *ngIf=\"switch=='5'\">ESTIMATE</h3>\n        <!-- <h3 *ngIf=\"switch=='6'\">PAYMENT</h3> -->\n        <h3 *ngIf=\"switch=='7'\">RECEIPT UPLOAD</h3>\n        <h3 *ngIf=\"switch=='8'\">WORK ORDERS</h3>\n      </div>\n      <ion-item>\n        <ion-searchbar [(ngModel)]=\"searchQuery\" *ngIf=\"switch!='7'\" class=\"search-bar\"></ion-searchbar>\n        <ion-buttons slot=\"end\">\n          <ion-button (click)=\"searchData(switch)\" color=\"primary\" fill=\"solid\">Search</ion-button>\n        </ion-buttons>\n      </ion-item>\n\n      <!-- Client Details -->\n      <ion-list *ngIf=\"switch=='1'\" class=\"main-list\">\n        <div *ngIf=\"isEmpty(testObject)\" class=\"text-danger text-center\">No Data Available</div>\n        <ion-item *ngFor=\"let item of testObject | keyvalue\" lines=\"none\" routerLink=\"/table/1\"\n          [queryParams]=\"item.value\">\n          <ion-avatar slot=\"start\">\n            <span class=\"icon\"><i class=\"fas fa-user-circle\"></i></span>\n          </ion-avatar>\n          <ion-label>\n            <ion-label>\n              <h2 class=\"set-content\" innerHTML=\"{{item.value?.title}} - <b>{{item.value?.post_status}}</b>\"></h2>\n            </ion-label>\n          </ion-label>\n        </ion-item>\n      </ion-list>\n\n      <!--  -->\n      <ion-list *ngIf=\"switch=='2'\" class=\"main-list\">\n        <ion-item lines=\"none\" routerLink=\"/table/2\">\n          <ion-avatar slot=\"start\">\n            <span class=\"icon\"><i class=\"fas fa-user-circle\"></i></span>\n          </ion-avatar>\n          <ion-label>\n            <ion-label>\n              <h2>James </h2>\n            </ion-label>\n          </ion-label>\n        </ion-item>\n        <ion-item lines=\"none\" routerLink=\"/table/2\">\n          <ion-avatar slot=\"start\">\n            <span class=\"icon\"><i class=\"fas fa-user-circle\"></i></span>\n          </ion-avatar>\n          <ion-label>\n            <h2>Bob</h2>\n          </ion-label>\n        </ion-item>\n      </ion-list>\n\n      <!-- project Details -->\n      <ion-list *ngIf=\"switch=='3'\" class=\"main-list\">\n        <h5 *ngIf=\"errMessage\" class=\"text-center text-danger\">{{errMessage}}</h5>\n        <div *ngIf=\"emptyData\" class=\"text-danger text-center\">No Data Available</div>\n        <ion-item *ngFor=\"let item of categoryArr\" lines=\"none\" routerLink=\"/table/3\" [queryParams]=\"item\">\n          <ion-avatar slot=\"start\">\n            <span class=\"icon\"><i class=\"fas fa-user-circle\"></i></span>\n          </ion-avatar>\n          <ion-label>\n            <ion-label>\n              <h2 class=\"set-content\" innerHTML=\"{{item?.title}} - <b>{{item?.post_status}}</b>\"></h2>\n              <h3><b><i class=\"far fa-calendar-alt\"></i> : </b>{{item?.post_modified | date: 'dd/MM/yyyy'}}</h3>\n            </ion-label>\n          </ion-label>\n        </ion-item>\n      </ion-list>\n\n      <!-- Invoice Details -->\n      <ion-list *ngIf=\"switch=='4'\" class=\"main-list\">\n        <div *ngIf=\"emptyData\" class=\"text-danger text-center\">No Data Available</div>\n        <ion-item *ngFor=\"let item of categoryArr\" lines=\"none\" routerLink=\"/table/4\" [queryParams]=\"item\">\n          <ion-avatar slot=\"start\">\n            <span class=\"icon\"><i class=\"fas fa-user-circle\"></i></span>\n          </ion-avatar>\n          <ion-label>\n            <ion-label>\n              <h2 class=\"set-content\" innerHTML=\"{{item?.title}} - <b>{{item?.post_status}}</b>\"></h2>\n              <h3><b>Amount: </b>{{item?.client_invoice_amount}} </h3>\n            </ion-label>\n          </ion-label>\n        </ion-item>\n      </ion-list>\n\n      <!-- Estimate Details -->\n      <ion-list *ngIf=\"switch=='5'\" class=\"main-list\">\n        <div *ngIf=\"emptyData\" class=\"text-danger text-center\">No Data Available</div>\n        <ion-item *ngFor=\"let item of categoryArr\" lines=\"none\" routerLink=\"/table/5\" [queryParams]=\"item\">\n          <ion-avatar slot=\"start\">\n            <span class=\"icon\"><i class=\"fas fa-user-circle\"></i></span>\n          </ion-avatar>\n          <ion-label>\n            <ion-label>\n              <h2 class=\"set-content\" innerHTML=\"{{item?.title}} - <b>{{item?.post_status}}</b>\"></h2>\n              <!-- <h3><b>Amount: </b>$80 </h3> -->\n            </ion-label>\n          </ion-label>\n        </ion-item>\n      </ion-list>\n\n      <!-- WorkFlow Details -->\n      <ion-list *ngIf=\"switch=='8'\" class=\"main-list\">\n        <div *ngIf=\"emptyData\" class=\"text-danger text-center\">No Data Available</div>\n        <ion-item *ngFor=\"let item of categoryArr\" lines=\"none\" routerLink=\"/table/8\" [queryParams]=\"item\">\n          <ion-avatar slot=\"start\">\n            <span class=\"icon\"><i class=\"fas fa-user-circle\"></i></span>\n          </ion-avatar>\n          <ion-label>\n            <ion-label>\n              <h2 class=\"set-content\">Work Order - {{item?.work_order_number}}</h2>\n              <h3 class=\"set-content\">Work Type - {{item?.work_type}}</h3>\n              <!-- <h3><b>Amount: </b>$80 </h3> -->\n            </ion-label>\n          </ion-label>\n        </ion-item>\n      </ion-list>\n\n      <!-- <ion-list *ngIf=\"switch=='8'\" class=\"main-list\">\n        <ion-item lines=\"none\" routerLink=\"/table/6\">\n          <ion-avatar slot=\"start\">\n            <span class=\"icon\"><i class=\"fas fa-user-circle\"></i></span>\n          </ion-avatar>\n          <ion-label>\n            <ion-label>\n              <h2>Paul Molive </h2>\n              <h3><b>Amount: </b>$80 </h3>\n            </ion-label>\n          </ion-label>\n        </ion-item>\n        <ion-item lines=\"none\" routerLink=\"/table/6\">\n          <ion-avatar slot=\"start\">\n            <span class=\"icon\"><i class=\"fas fa-user-circle\"></i></span>\n          </ion-avatar>\n          <ion-label>\n            <h2>Richard </h2>\n            <h3><b>Amount: </b>$20 </h3>\n          </ion-label>\n        </ion-item>\n      </ion-list> -->\n\n      <div class=\"invoice-upload\" *ngIf=\"switch=='7'\">\n        <p>Please upload the receipt. (Only JPG, PNG and GIF files are allowed)</p>\n        <ion-button color=\"light\">Upload File</ion-button>\n      </div>\n\n    </div>\n  </div>\n</ion-content>");

/***/ }),

/***/ "./src/app/main-list/main-list-routing.module.ts":
/*!*******************************************************!*\
  !*** ./src/app/main-list/main-list-routing.module.ts ***!
  \*******************************************************/
/*! exports provided: MainListPageRoutingModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "MainListPageRoutingModule", function() { return MainListPageRoutingModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm2015/core.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm2015/router.js");
/* harmony import */ var _main_list_page__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./main-list.page */ "./src/app/main-list/main-list.page.ts");




const routes = [
    {
        path: '',
        component: _main_list_page__WEBPACK_IMPORTED_MODULE_3__["MainListPage"]
    }
];
let MainListPageRoutingModule = class MainListPageRoutingModule {
};
MainListPageRoutingModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"].forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"]],
    })
], MainListPageRoutingModule);



/***/ }),

/***/ "./src/app/main-list/main-list.module.ts":
/*!***********************************************!*\
  !*** ./src/app/main-list/main-list.module.ts ***!
  \***********************************************/
/*! exports provided: MainListPageModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "MainListPageModule", function() { return MainListPageModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm2015/core.js");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/fesm2015/common.js");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/forms */ "./node_modules/@angular/forms/fesm2015/forms.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/fesm2015/ionic-angular.js");
/* harmony import */ var _main_list_routing_module__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./main-list-routing.module */ "./src/app/main-list/main-list-routing.module.ts");
/* harmony import */ var _main_list_page__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./main-list.page */ "./src/app/main-list/main-list.page.ts");







let MainListPageModule = class MainListPageModule {
};
MainListPageModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"],
            _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormsModule"],
            _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["IonicModule"],
            _main_list_routing_module__WEBPACK_IMPORTED_MODULE_5__["MainListPageRoutingModule"]
        ],
        declarations: [_main_list_page__WEBPACK_IMPORTED_MODULE_6__["MainListPage"]]
    })
], MainListPageModule);



/***/ }),

/***/ "./src/app/main-list/main-list.page.scss":
/*!***********************************************!*\
  !*** ./src/app/main-list/main-list.page.scss ***!
  \***********************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("/**LIST: START**/\n.search-bar {\n  background: #fff;\n  border-radius: 50px;\n  height: 40px;\n  margin-bottom: 20px;\n  padding: 0;\n}\n.searchbar-input-container input {\n  --background: #fff !important;\n}\ninput {\n  --ion-background: red !important;\n}\n.main-list {\n  --ion-background-color: #000 !important;\n}\n.main-list ion-item {\n  --ion-background-color: #fff !important;\n  --padding-top: 10px !important;\n  --padding-bottom: 10px !important;\n}\n.main-list ion-avatar {\n  margin: 0 !important;\n}\n.main-list .icon {\n  font-size: 25px;\n}\n.main-list .item {\n  padding: 10px;\n}\n.main-list .f-icon {\n  font-size: 15px;\n}\n.invoice-upload {\n  margin-top: 50px;\n}\n.set-content {\n  white-space: normal;\n}\n.container {\n  background-color: black;\n}\n.search-bar {\n  background: #fff;\n  border-radius: 50px;\n  height: 40px;\n  margin: 5px 0;\n  padding: 0;\n}\n.webPage {\n  width: 100%;\n  height: 600px;\n}\nion-spinner {\n  position: fixed;\n  z-index: 999;\n  height: 5em;\n  width: em;\n  overflow: show;\n  margin: auto;\n  top: 0;\n  left: 0;\n  bottom: 0;\n  right: 0;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvbWFpbi1saXN0L0U6XFxzaGlwZ2lnXFxjb2traWUtYXBwL3NyY1xcYXBwXFxtYWluLWxpc3RcXG1haW4tbGlzdC5wYWdlLnNjc3MiLCJzcmMvYXBwL21haW4tbGlzdC9tYWluLWxpc3QucGFnZS5zY3NzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBLGdCQUFBO0FBQ0E7RUFDRSxnQkFBQTtFQUNBLG1CQUFBO0VBQ0EsWUFBQTtFQUNBLG1CQUFBO0VBQ0EsVUFBQTtBQ0NGO0FERUE7RUFDRSw2QkFBQTtBQ0NGO0FERUE7RUFDRSxnQ0FBQTtBQ0NGO0FERUE7RUFDRSx1Q0FBQTtBQ0NGO0FERUE7RUFDRSx1Q0FBQTtFQUNBLDhCQUFBO0VBQ0EsaUNBQUE7QUNDRjtBREVBO0VBQ0Usb0JBQUE7QUNDRjtBREVBO0VBQ0UsZUFBQTtBQ0NGO0FERUE7RUFDRSxhQUFBO0FDQ0Y7QURFQTtFQUNFLGVBQUE7QUNDRjtBREVBO0VBQ0UsZ0JBQUE7QUNDRjtBREVBO0VBQ0UsbUJBQUE7QUNDRjtBREVBO0VBQ0UsdUJBQUE7QUNDRjtBREVBO0VBQ0UsZ0JBQUE7RUFDQSxtQkFBQTtFQUNBLFlBQUE7RUFDQSxhQUFBO0VBQ0EsVUFBQTtBQ0NGO0FERUE7RUFDRSxXQUFBO0VBQ0EsYUFBQTtBQ0NGO0FERUE7RUFDRSxlQUFBO0VBQ0EsWUFBQTtFQUNBLFdBQUE7RUFDQSxTQUFBO0VBQ0EsY0FBQTtFQUNBLFlBQUE7RUFDQSxNQUFBO0VBQ0EsT0FBQTtFQUNBLFNBQUE7RUFDQSxRQUFBO0FDQ0YiLCJmaWxlIjoic3JjL2FwcC9tYWluLWxpc3QvbWFpbi1saXN0LnBhZ2Uuc2NzcyIsInNvdXJjZXNDb250ZW50IjpbIi8qKkxJU1Q6IFNUQVJUKiovXHJcbi5zZWFyY2gtYmFyIHtcclxuICBiYWNrZ3JvdW5kOiAjZmZmO1xyXG4gIGJvcmRlci1yYWRpdXM6IDUwcHg7XHJcbiAgaGVpZ2h0OiA0MHB4O1xyXG4gIG1hcmdpbi1ib3R0b206IDIwcHg7XHJcbiAgcGFkZGluZzogMDtcclxufVxyXG5cclxuLnNlYXJjaGJhci1pbnB1dC1jb250YWluZXIgaW5wdXQge1xyXG4gIC0tYmFja2dyb3VuZDogI2ZmZiAhaW1wb3J0YW50O1xyXG59XHJcblxyXG5pbnB1dCB7XHJcbiAgLS1pb24tYmFja2dyb3VuZDogcmVkICFpbXBvcnRhbnQ7XHJcbn1cclxuXHJcbi5tYWluLWxpc3Qge1xyXG4gIC0taW9uLWJhY2tncm91bmQtY29sb3I6ICMwMDAgIWltcG9ydGFudDtcclxufVxyXG5cclxuLm1haW4tbGlzdCBpb24taXRlbSB7XHJcbiAgLS1pb24tYmFja2dyb3VuZC1jb2xvcjogI2ZmZiAhaW1wb3J0YW50O1xyXG4gIC0tcGFkZGluZy10b3A6IDEwcHggIWltcG9ydGFudDtcclxuICAtLXBhZGRpbmctYm90dG9tOiAxMHB4ICFpbXBvcnRhbnQ7XHJcbn1cclxuXHJcbi5tYWluLWxpc3QgaW9uLWF2YXRhciB7XHJcbiAgbWFyZ2luOiAwICFpbXBvcnRhbnQ7XHJcbn1cclxuXHJcbi5tYWluLWxpc3QgLmljb24ge1xyXG4gIGZvbnQtc2l6ZTogMjVweDtcclxufVxyXG5cclxuLm1haW4tbGlzdCAuaXRlbSB7XHJcbiAgcGFkZGluZzogMTBweDtcclxufVxyXG5cclxuLm1haW4tbGlzdCAuZi1pY29uIHtcclxuICBmb250LXNpemU6IDE1cHg7XHJcbn1cclxuXHJcbi5pbnZvaWNlLXVwbG9hZCB7XHJcbiAgbWFyZ2luLXRvcDogNTBweDtcclxufVxyXG5cclxuLnNldC1jb250ZW50IHtcclxuICB3aGl0ZS1zcGFjZTogbm9ybWFsO1xyXG59XHJcblxyXG4uY29udGFpbmVyIHtcclxuICBiYWNrZ3JvdW5kLWNvbG9yOiBibGFjaztcclxufVxyXG5cclxuLnNlYXJjaC1iYXIge1xyXG4gIGJhY2tncm91bmQ6ICNmZmY7XHJcbiAgYm9yZGVyLXJhZGl1czogNTBweDtcclxuICBoZWlnaHQ6IDQwcHg7XHJcbiAgbWFyZ2luOiA1cHggMDtcclxuICBwYWRkaW5nOiAwO1xyXG59XHJcblxyXG4ud2ViUGFnZXtcclxuICB3aWR0aDogMTAwJTtcclxuICBoZWlnaHQ6IDYwMHB4O1xyXG59XHJcblxyXG5pb24tc3Bpbm5lciB7XHJcbiAgcG9zaXRpb246IGZpeGVkO1xyXG4gIHotaW5kZXg6IDk5OTtcclxuICBoZWlnaHQ6IDVlbTtcclxuICB3aWR0aDogZW07XHJcbiAgb3ZlcmZsb3c6IHNob3c7XHJcbiAgbWFyZ2luOiBhdXRvO1xyXG4gIHRvcDogMDtcclxuICBsZWZ0OiAwO1xyXG4gIGJvdHRvbTogMDtcclxuICByaWdodDogMDtcclxufVxyXG5cclxuIiwiLyoqTElTVDogU1RBUlQqKi9cbi5zZWFyY2gtYmFyIHtcbiAgYmFja2dyb3VuZDogI2ZmZjtcbiAgYm9yZGVyLXJhZGl1czogNTBweDtcbiAgaGVpZ2h0OiA0MHB4O1xuICBtYXJnaW4tYm90dG9tOiAyMHB4O1xuICBwYWRkaW5nOiAwO1xufVxuXG4uc2VhcmNoYmFyLWlucHV0LWNvbnRhaW5lciBpbnB1dCB7XG4gIC0tYmFja2dyb3VuZDogI2ZmZiAhaW1wb3J0YW50O1xufVxuXG5pbnB1dCB7XG4gIC0taW9uLWJhY2tncm91bmQ6IHJlZCAhaW1wb3J0YW50O1xufVxuXG4ubWFpbi1saXN0IHtcbiAgLS1pb24tYmFja2dyb3VuZC1jb2xvcjogIzAwMCAhaW1wb3J0YW50O1xufVxuXG4ubWFpbi1saXN0IGlvbi1pdGVtIHtcbiAgLS1pb24tYmFja2dyb3VuZC1jb2xvcjogI2ZmZiAhaW1wb3J0YW50O1xuICAtLXBhZGRpbmctdG9wOiAxMHB4ICFpbXBvcnRhbnQ7XG4gIC0tcGFkZGluZy1ib3R0b206IDEwcHggIWltcG9ydGFudDtcbn1cblxuLm1haW4tbGlzdCBpb24tYXZhdGFyIHtcbiAgbWFyZ2luOiAwICFpbXBvcnRhbnQ7XG59XG5cbi5tYWluLWxpc3QgLmljb24ge1xuICBmb250LXNpemU6IDI1cHg7XG59XG5cbi5tYWluLWxpc3QgLml0ZW0ge1xuICBwYWRkaW5nOiAxMHB4O1xufVxuXG4ubWFpbi1saXN0IC5mLWljb24ge1xuICBmb250LXNpemU6IDE1cHg7XG59XG5cbi5pbnZvaWNlLXVwbG9hZCB7XG4gIG1hcmdpbi10b3A6IDUwcHg7XG59XG5cbi5zZXQtY29udGVudCB7XG4gIHdoaXRlLXNwYWNlOiBub3JtYWw7XG59XG5cbi5jb250YWluZXIge1xuICBiYWNrZ3JvdW5kLWNvbG9yOiBibGFjaztcbn1cblxuLnNlYXJjaC1iYXIge1xuICBiYWNrZ3JvdW5kOiAjZmZmO1xuICBib3JkZXItcmFkaXVzOiA1MHB4O1xuICBoZWlnaHQ6IDQwcHg7XG4gIG1hcmdpbjogNXB4IDA7XG4gIHBhZGRpbmc6IDA7XG59XG5cbi53ZWJQYWdlIHtcbiAgd2lkdGg6IDEwMCU7XG4gIGhlaWdodDogNjAwcHg7XG59XG5cbmlvbi1zcGlubmVyIHtcbiAgcG9zaXRpb246IGZpeGVkO1xuICB6LWluZGV4OiA5OTk7XG4gIGhlaWdodDogNWVtO1xuICB3aWR0aDogZW07XG4gIG92ZXJmbG93OiBzaG93O1xuICBtYXJnaW46IGF1dG87XG4gIHRvcDogMDtcbiAgbGVmdDogMDtcbiAgYm90dG9tOiAwO1xuICByaWdodDogMDtcbn0iXX0= */");

/***/ }),

/***/ "./src/app/main-list/main-list.page.ts":
/*!*********************************************!*\
  !*** ./src/app/main-list/main-list.page.ts ***!
  \*********************************************/
/*! exports provided: MainListPage */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "MainListPage", function() { return MainListPage; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm2015/core.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm2015/router.js");
/* harmony import */ var _services_category_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../services/category.service */ "./src/app/services/category.service.ts");




let MainListPage = class MainListPage {
    constructor(activatedRoute, categoryService) {
        this.activatedRoute = activatedRoute;
        this.categoryService = categoryService;
        this.isLoading = false;
        this.emptyData = false;
        this.categoryArr = [];
        this.testObject = {};
        this.errMessage = "";
        this.searchQuery = "";
        this.isLoading = false;
    }
    ngOnInit() {
        this.switch = this.activatedRoute.snapshot.paramMap.get('id');
        this.getCategoryData();
        this.errMessage = "";
    }
    getCategoryData() {
        // get Client Data
        if (this.switch && this.switch == '1') {
            this.isLoading = true;
            this.categoryService.getSearchClientData().subscribe(res => {
                if (res) {
                    this.testObject = res;
                    this.isLoading = false;
                }
            }, err => {
                this.isLoading = false;
                this.errMessage = "Internal Error Occured";
            });
        }
        // get project Data
        if (this.switch && this.switch == '3') {
            this.isLoading = true;
            this.categoryService.getSearchProjectData().subscribe(res => {
                if (res['data'] && res['data'].length > 0) {
                    this.categoryArr = res['data'];
                    this.emptyData = false;
                }
                else {
                    this.categoryArr = res['data'];
                    this.emptyData = true;
                }
                this.isLoading = false;
            }, err => {
                this.isLoading = false;
                if (err['status'] == '404') {
                    this.errMessage = "Internal Error Occured";
                }
            });
        }
        // get invoice Data
        if (this.switch && this.switch == '4') {
            this.isLoading = true;
            this.categoryService.getSearchInvoiceData().subscribe(res => {
                if (res['data'] && res['data'].length > 0) {
                    this.categoryArr = res['data'];
                    this.emptyData = false;
                }
                else {
                    this.categoryArr = res['data'];
                    this.emptyData = true;
                }
                this.isLoading = false;
            }, err => {
                this.isLoading = false;
                this.errMessage = "Internal Error Occurred";
                console.log("err", err);
            });
        }
        // get estimate Data
        if (this.switch && this.switch == '5') {
            this.isLoading = true;
            this.categoryService.getSearchEstimateData().subscribe(res => {
                if (res['data'] && res['data'].length > 0) {
                    this.categoryArr = res['data'];
                    this.emptyData = false;
                }
                else {
                    this.categoryArr = res['data'];
                    this.emptyData = true;
                }
                this.isLoading = false;
            }, err => {
                this.isLoading = false;
                this.errMessage = "Internal Error Occurred";
                console.log("err", err);
            });
        }
        // get Workflow Data
        if (this.switch && this.switch == '8') {
            this.isLoading = true;
            this.categoryService.getSearchWorkorderData().subscribe(res => {
                if (res['data'] && res['data'].length > 0) {
                    this.categoryArr = res['data'];
                    this.emptyData = false;
                }
                else {
                    this.categoryArr = res['data'];
                    this.emptyData = true;
                }
                this.isLoading = false;
            }, err => {
                this.isLoading = false;
                this.errMessage = "Internal Error Occurred";
                console.log("err", err);
            });
        }
    }
    searchData(sw) {
        if (sw == '1') {
            this.isLoading = true;
            this.categoryService.getSearchClientData(this.searchQuery).subscribe(res => {
                if (res) {
                    this.isLoading = false;
                    this.testObject = res;
                }
            }, err => {
                this.isLoading = false;
                this.errMessage = "Internal Error Occured";
            });
        }
        else if (sw == '3') {
            this.isLoading = true;
            this.categoryService.getSearchProjectData(this.searchQuery).subscribe(res => {
                if (res['data'] && res['data'].length > 0) {
                    this.categoryArr = res['data'];
                    this.emptyData = false;
                }
                else {
                    this.categoryArr = res['data'];
                    this.emptyData = true;
                }
                this.isLoading = false;
            }, err => {
                this.isLoading = false;
                if (err['status'] == '404') {
                    this.errMessage = "Internal Error Occured";
                }
            });
        }
        else if (sw == '4') {
            this.isLoading = true;
            this.categoryService.getSearchInvoiceData(this.searchQuery).subscribe(res => {
                if (res['data'] && res['data'].length > 0) {
                    this.categoryArr = res['data'];
                    this.emptyData = false;
                }
                else {
                    this.categoryArr = res['data'];
                    this.emptyData = true;
                }
                this.isLoading = false;
            }, err => {
                this.isLoading = false;
                this.errMessage = "Internal Error Occured";
            });
        }
        else if (sw == '5') {
            this.isLoading = true;
            this.categoryService.getSearchEstimateData(this.searchQuery).subscribe(res => {
                if (res['data'] && res['data'].length > 0) {
                    this.categoryArr = res['data'];
                    this.emptyData = false;
                }
                else {
                    this.categoryArr = res['data'];
                    this.emptyData = true;
                }
                this.isLoading = false;
            }, err => {
                this.isLoading = false;
                this.errMessage = "Internal Error Occured";
            });
        }
        else if (sw == '8') {
            this.isLoading = true;
            this.categoryService.getSearchWorkorderData(this.searchQuery).subscribe(res => {
                if (res['data'] && res['data'].length > 0) {
                    this.categoryArr = res['data'];
                    this.emptyData = false;
                }
                else {
                    this.categoryArr = res['data'];
                    this.emptyData = true;
                }
                this.isLoading = false;
            }, err => {
                this.isLoading = false;
                this.errMessage = "Internal Error Occured";
            });
        }
    }
    isEmpty(obj) {
        return Object.keys(obj).length === 0;
    }
};
MainListPage.ctorParameters = () => [
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_2__["ActivatedRoute"] },
    { type: _services_category_service__WEBPACK_IMPORTED_MODULE_3__["CategoryService"] }
];
MainListPage = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
        selector: 'app-main-list',
        template: tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(/*! raw-loader!./main-list.page.html */ "./node_modules/raw-loader/dist/cjs.js!./src/app/main-list/main-list.page.html")).default,
        styles: [tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(/*! ./main-list.page.scss */ "./src/app/main-list/main-list.page.scss")).default]
    }),
    tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_angular_router__WEBPACK_IMPORTED_MODULE_2__["ActivatedRoute"],
        _services_category_service__WEBPACK_IMPORTED_MODULE_3__["CategoryService"]])
], MainListPage);



/***/ })

}]);
//# sourceMappingURL=main-list-main-list-module-es2015.js.map
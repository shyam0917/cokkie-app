function _defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } }

function _createClass(Constructor, protoProps, staticProps) { if (protoProps) _defineProperties(Constructor.prototype, protoProps); if (staticProps) _defineProperties(Constructor, staticProps); return Constructor; }

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["main-list-main-list-module"], {
  /***/
  "./node_modules/raw-loader/dist/cjs.js!./src/app/main-list/main-list.page.html":
  /*!*************************************************************************************!*\
    !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/main-list/main-list.page.html ***!
    \*************************************************************************************/

  /*! exports provided: default */

  /***/
  function node_modulesRawLoaderDistCjsJsSrcAppMainListMainListPageHtml(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony default export */


    __webpack_exports__["default"] = "<ion-header>\n  <ion-toolbar class=\"customize-toolbar\">\n    <ion-buttons slot=\"start\">\n      <ion-back-button text=\"\" color=\"light\"></ion-back-button>\n    </ion-buttons>\n    <ion-img class=\"logo p-3\" src=\"assets/img/logo.png\"></ion-img>\n  </ion-toolbar>\n</ion-header>\n\n  <iframe *ngIf=\"switch=='6'\" class= 'webPage' src=\"https://cands.ca/one_timepmnt.php\" allowfullscreen></iframe>\n\n<div *ngIf=\"errorMessage\" class=\"text-center text-danger\">{{errMessage}}</div>\n\n<ion-content *ngIf=\"switch!='6'\">\n  <div class=\"app-layout set-height\">\n    <div class=\"container\">\n      <div class=\"heading\">\n        <h3 *ngIf=\"switch=='1'\">CLIENTS</h3>\n        <h3 *ngIf=\"switch=='2'\">CLOCK IN/OUT</h3>\n        <h3 *ngIf=\"switch=='3'\">PROJECTS</h3>\n        <h3 *ngIf=\"switch=='4'\">INVOICES</h3>\n        <h3 *ngIf=\"switch=='5'\">ESTIMATE</h3>\n        <!-- <h3 *ngIf=\"switch=='6'\">PAYMENT</h3> -->\n        <h3 *ngIf=\"switch=='7'\">RECEIPT UPLOAD</h3>\n      </div>\n      <ion-item><ion-searchbar [(ngModel)]=\"searchQuery\" *ngIf=\"switch!='7'\" class=\"search-bar\" ></ion-searchbar><ion-buttons slot=\"end\">\n        <ion-button (click)=\"searchData(switch)\" color=\"primary\" fill=\"solid\">Search</ion-button></ion-buttons></ion-item>\n     \n        <!-- Client Details -->\n      <ion-list *ngIf=\"switch=='1'\" class=\"main-list\">\n        <div *ngIf=\"isEmpty(testObject)\" class=\"text-danger text-center\">No Data Available</div>\n        <ion-item *ngFor=\"let item of testObject | keyvalue\" lines=\"none\" routerLink=\"/table/1\"\n          [queryParams]=\"item.value\">\n          <ion-avatar slot=\"start\">\n            <span class=\"icon\"><i class=\"fas fa-user-circle\"></i></span>\n          </ion-avatar>\n          <ion-label>\n            <ion-label>\n              <h2 class=\"set-content\" innerHTML=\"{{item.value?.title}} - <b>{{item.value?.post_status}}</b>\"></h2>\n            </ion-label>\n          </ion-label>\n        </ion-item>\n      </ion-list>\n\n      <!--  -->\n      <ion-list *ngIf=\"switch=='2'\" class=\"main-list\">\n        <ion-item lines=\"none\" routerLink=\"/table/2\">\n          <ion-avatar slot=\"start\">\n            <span class=\"icon\"><i class=\"fas fa-user-circle\"></i></span>\n          </ion-avatar>\n          <ion-label>\n            <ion-label>\n              <h2>James </h2>\n            </ion-label>\n          </ion-label>\n        </ion-item>\n        <ion-item lines=\"none\" routerLink=\"/table/2\">\n          <ion-avatar slot=\"start\">\n            <span class=\"icon\"><i class=\"fas fa-user-circle\"></i></span>\n          </ion-avatar>\n          <ion-label>\n            <h2>Bob</h2>\n          </ion-label>\n        </ion-item>\n      </ion-list>\n\n      <!-- project Details -->\n      <ion-list *ngIf=\"switch=='3'\" class=\"main-list\">\n        <h5 *ngIf=\"errMessage\" class=\"text-center text-danger\">{{errMessage}}</h5>\n        <div *ngIf=\"!categoryArr.length>0\" class=\"text-danger text-center\">No Data Available</div>\n        <ion-item *ngFor=\"let item of categoryArr\" lines=\"none\" routerLink=\"/table/3\" [queryParams]=\"item\">\n          <ion-avatar slot=\"start\">\n            <span class=\"icon\"><i class=\"fas fa-user-circle\"></i></span>\n          </ion-avatar>\n          <ion-label>\n            <ion-label>\n              <h2 class=\"set-content\" innerHTML=\"{{item?.title}} - <b>{{item?.post_status}}</b>\"></h2>\n              <h3><b><i class=\"far fa-calendar-alt\"></i> : </b>{{item?.post_modified | date: 'dd/MM/yyyy'}}</h3>\n            </ion-label>\n          </ion-label>\n        </ion-item>\n      </ion-list>\n\n      <!-- Invoice Details -->\n      <ion-list *ngIf=\"switch=='4'\" class=\"main-list\">\n        <div *ngIf=\"!categoryArr.length>0\" class=\"text-danger text-center\">No Data Available</div>\n        <ion-item *ngFor=\"let item of categoryArr\" lines=\"none\" routerLink=\"/table/4\" [queryParams]=\"item\">\n          <ion-avatar slot=\"start\">\n            <span class=\"icon\"><i class=\"fas fa-user-circle\"></i></span>\n          </ion-avatar>\n          <ion-label>\n            <ion-label>\n              <h2 class=\"set-content\" innerHTML=\"{{item?.title}} - <b>{{item?.post_status}}</b>\"></h2>\n              <h3><b>Amount: </b>{{item?.client_invoice_amount}} </h3>\n            </ion-label>\n          </ion-label>\n        </ion-item>\n      </ion-list>\n\n      <!-- Estimate Details -->\n      <ion-list *ngIf=\"switch=='5'\" class=\"main-list\">\n        <div *ngIf=\"!categoryArr.length>0\" class=\"text-danger text-center\">No Data Available</div>\n        <ion-item *ngFor=\"let item of categoryArr\" lines=\"none\" routerLink=\"/table/5\" [queryParams]=\"item\">\n          <ion-avatar slot=\"start\">\n            <span class=\"icon\"><i class=\"fas fa-user-circle\"></i></span>\n          </ion-avatar>\n          <ion-label>\n            <ion-label>\n              <h2 class=\"set-content\" innerHTML=\"{{item?.title}} - <b>{{item?.post_status}}</b>\"></h2>\n              <!-- <h3><b>Amount: </b>$80 </h3> -->\n            </ion-label>\n          </ion-label>\n        </ion-item>\n      </ion-list>\n\n      <!-- <ion-list *ngIf=\"switch=='6'\" class=\"main-list\">\n        <ion-item lines=\"none\" routerLink=\"/table/6\">\n          <ion-avatar slot=\"start\">\n            <span class=\"icon\"><i class=\"fas fa-user-circle\"></i></span>\n          </ion-avatar>\n          <ion-label>\n            <ion-label>\n              <h2>Paul Molive </h2>\n              <h3><b>Amount: </b>$80 </h3>\n            </ion-label>\n          </ion-label>\n        </ion-item>\n        <ion-item lines=\"none\" routerLink=\"/table/6\">\n          <ion-avatar slot=\"start\">\n            <span class=\"icon\"><i class=\"fas fa-user-circle\"></i></span>\n          </ion-avatar>\n          <ion-label>\n            <h2>Richard </h2>\n            <h3><b>Amount: </b>$20 </h3>\n          </ion-label>\n        </ion-item>\n      </ion-list> -->\n\n      <div class=\"invoice-upload\" *ngIf=\"switch=='7'\">\n        <p>Please upload the receipt. (Only JPG, PNG and GIF files are allowed)</p>\n        <ion-button color=\"light\">Upload File</ion-button>\n      </div>\n\n    </div>\n  </div>\n</ion-content>\n\n";
    /***/
  },

  /***/
  "./src/app/main-list/main-list-routing.module.ts":
  /*!*******************************************************!*\
    !*** ./src/app/main-list/main-list-routing.module.ts ***!
    \*******************************************************/

  /*! exports provided: MainListPageRoutingModule */

  /***/
  function srcAppMainListMainListRoutingModuleTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "MainListPageRoutingModule", function () {
      return MainListPageRoutingModule;
    });
    /* harmony import */


    var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! tslib */
    "./node_modules/tslib/tslib.es6.js");
    /* harmony import */


    var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! @angular/core */
    "./node_modules/@angular/core/fesm2015/core.js");
    /* harmony import */


    var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
    /*! @angular/router */
    "./node_modules/@angular/router/fesm2015/router.js");
    /* harmony import */


    var _main_list_page__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
    /*! ./main-list.page */
    "./src/app/main-list/main-list.page.ts");

    var routes = [{
      path: '',
      component: _main_list_page__WEBPACK_IMPORTED_MODULE_3__["MainListPage"]
    }];

    var MainListPageRoutingModule = function MainListPageRoutingModule() {
      _classCallCheck(this, MainListPageRoutingModule);
    };

    MainListPageRoutingModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
      imports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"].forChild(routes)],
      exports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"]]
    })], MainListPageRoutingModule);
    /***/
  },

  /***/
  "./src/app/main-list/main-list.module.ts":
  /*!***********************************************!*\
    !*** ./src/app/main-list/main-list.module.ts ***!
    \***********************************************/

  /*! exports provided: MainListPageModule */

  /***/
  function srcAppMainListMainListModuleTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "MainListPageModule", function () {
      return MainListPageModule;
    });
    /* harmony import */


    var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! tslib */
    "./node_modules/tslib/tslib.es6.js");
    /* harmony import */


    var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! @angular/core */
    "./node_modules/@angular/core/fesm2015/core.js");
    /* harmony import */


    var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
    /*! @angular/common */
    "./node_modules/@angular/common/fesm2015/common.js");
    /* harmony import */


    var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
    /*! @angular/forms */
    "./node_modules/@angular/forms/fesm2015/forms.js");
    /* harmony import */


    var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(
    /*! @ionic/angular */
    "./node_modules/@ionic/angular/fesm2015/ionic-angular.js");
    /* harmony import */


    var _main_list_routing_module__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(
    /*! ./main-list-routing.module */
    "./src/app/main-list/main-list-routing.module.ts");
    /* harmony import */


    var _main_list_page__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(
    /*! ./main-list.page */
    "./src/app/main-list/main-list.page.ts");

    var MainListPageModule = function MainListPageModule() {
      _classCallCheck(this, MainListPageModule);
    };

    MainListPageModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
      imports: [_angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"], _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormsModule"], _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["IonicModule"], _main_list_routing_module__WEBPACK_IMPORTED_MODULE_5__["MainListPageRoutingModule"]],
      declarations: [_main_list_page__WEBPACK_IMPORTED_MODULE_6__["MainListPage"]]
    })], MainListPageModule);
    /***/
  },

  /***/
  "./src/app/main-list/main-list.page.scss":
  /*!***********************************************!*\
    !*** ./src/app/main-list/main-list.page.scss ***!
    \***********************************************/

  /*! exports provided: default */

  /***/
  function srcAppMainListMainListPageScss(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony default export */


    __webpack_exports__["default"] = "/**LIST: START**/\n.search-bar {\n  background: #fff;\n  border-radius: 50px;\n  height: 40px;\n  margin-bottom: 20px;\n  padding: 0;\n}\n.searchbar-input-container input {\n  --background: #fff !important;\n}\ninput {\n  --ion-background: red !important;\n}\n.main-list {\n  --ion-background-color: #000 !important;\n}\n.main-list ion-item {\n  --ion-background-color: #fff !important;\n  --padding-top: 10px !important;\n  --padding-bottom: 10px !important;\n}\n.main-list ion-avatar {\n  margin: 0 !important;\n}\n.main-list .icon {\n  font-size: 25px;\n}\n.main-list .item {\n  padding: 10px;\n}\n.main-list .f-icon {\n  font-size: 15px;\n}\n.invoice-upload {\n  margin-top: 50px;\n}\n.set-content {\n  white-space: normal;\n}\n.container {\n  background-color: black;\n}\n.webPage {\n  width: 100%;\n  height: 600px;\n}\n/**LIST: START**/\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvbWFpbi1saXN0L0U6XFxzaGlwZ2lnXFxjb2traWUtYXBwL3NyY1xcYXBwXFxtYWluLWxpc3RcXG1haW4tbGlzdC5wYWdlLnNjc3MiLCJzcmMvYXBwL21haW4tbGlzdC9tYWluLWxpc3QucGFnZS5zY3NzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBLGdCQUFBO0FBQ0E7RUFDRSxnQkFBQTtFQUNBLG1CQUFBO0VBQ0EsWUFBQTtFQUNBLG1CQUFBO0VBQ0EsVUFBQTtBQ0NGO0FERUE7RUFDRSw2QkFBQTtBQ0NGO0FERUE7RUFDRSxnQ0FBQTtBQ0NGO0FERUE7RUFDRSx1Q0FBQTtBQ0NGO0FERUE7RUFDRSx1Q0FBQTtFQUNBLDhCQUFBO0VBQ0EsaUNBQUE7QUNDRjtBREVBO0VBQ0Usb0JBQUE7QUNDRjtBREVBO0VBQ0UsZUFBQTtBQ0NGO0FERUE7RUFDRSxhQUFBO0FDQ0Y7QURFQTtFQUNFLGVBQUE7QUNDRjtBREVBO0VBQ0UsZ0JBQUE7QUNDRjtBREVBO0VBQ0UsbUJBQUE7QUNDRjtBREVBO0VBQ0UsdUJBQUE7QUNDRjtBREVBO0VBQ0UsV0FBQTtFQUNBLGFBQUE7QUNDRjtBREdBLGdCQUFBIiwiZmlsZSI6InNyYy9hcHAvbWFpbi1saXN0L21haW4tbGlzdC5wYWdlLnNjc3MiLCJzb3VyY2VzQ29udGVudCI6WyIvKipMSVNUOiBTVEFSVCoqL1xyXG4uc2VhcmNoLWJhciB7XHJcbiAgYmFja2dyb3VuZDogI2ZmZjtcclxuICBib3JkZXItcmFkaXVzOiA1MHB4O1xyXG4gIGhlaWdodDogNDBweDtcclxuICBtYXJnaW4tYm90dG9tOiAyMHB4O1xyXG4gIHBhZGRpbmc6IDA7XHJcbn1cclxuXHJcbi5zZWFyY2hiYXItaW5wdXQtY29udGFpbmVyIGlucHV0IHtcclxuICAtLWJhY2tncm91bmQ6ICNmZmYgIWltcG9ydGFudDtcclxufVxyXG5cclxuaW5wdXQge1xyXG4gIC0taW9uLWJhY2tncm91bmQ6IHJlZCAhaW1wb3J0YW50O1xyXG59XHJcblxyXG4ubWFpbi1saXN0IHtcclxuICAtLWlvbi1iYWNrZ3JvdW5kLWNvbG9yOiAjMDAwICFpbXBvcnRhbnQ7XHJcbn1cclxuXHJcbi5tYWluLWxpc3QgaW9uLWl0ZW0ge1xyXG4gIC0taW9uLWJhY2tncm91bmQtY29sb3I6ICNmZmYgIWltcG9ydGFudDtcclxuICAtLXBhZGRpbmctdG9wOiAxMHB4ICFpbXBvcnRhbnQ7XHJcbiAgLS1wYWRkaW5nLWJvdHRvbTogMTBweCAhaW1wb3J0YW50O1xyXG59XHJcblxyXG4ubWFpbi1saXN0IGlvbi1hdmF0YXIge1xyXG4gIG1hcmdpbjogMCAhaW1wb3J0YW50O1xyXG59XHJcblxyXG4ubWFpbi1saXN0IC5pY29uIHtcclxuICBmb250LXNpemU6IDI1cHg7XHJcbn1cclxuXHJcbi5tYWluLWxpc3QgLml0ZW0ge1xyXG4gIHBhZGRpbmc6IDEwcHg7XHJcbn1cclxuXHJcbi5tYWluLWxpc3QgLmYtaWNvbiB7XHJcbiAgZm9udC1zaXplOiAxNXB4O1xyXG59XHJcblxyXG4uaW52b2ljZS11cGxvYWQge1xyXG4gIG1hcmdpbi10b3A6IDUwcHg7XHJcbn1cclxuXHJcbi5zZXQtY29udGVudCB7XHJcbiAgd2hpdGUtc3BhY2U6IG5vcm1hbDtcclxufVxyXG5cclxuLmNvbnRhaW5lciB7XHJcbiAgYmFja2dyb3VuZC1jb2xvcjogYmxhY2s7XHJcbn1cclxuXHJcbi53ZWJQYWdle1xyXG4gIHdpZHRoOiAxMDAlO1xyXG4gIGhlaWdodDogNjAwcHg7XHJcbn1cclxuXHJcblxyXG4vKipMSVNUOiBTVEFSVCoqLyIsIi8qKkxJU1Q6IFNUQVJUKiovXG4uc2VhcmNoLWJhciB7XG4gIGJhY2tncm91bmQ6ICNmZmY7XG4gIGJvcmRlci1yYWRpdXM6IDUwcHg7XG4gIGhlaWdodDogNDBweDtcbiAgbWFyZ2luLWJvdHRvbTogMjBweDtcbiAgcGFkZGluZzogMDtcbn1cblxuLnNlYXJjaGJhci1pbnB1dC1jb250YWluZXIgaW5wdXQge1xuICAtLWJhY2tncm91bmQ6ICNmZmYgIWltcG9ydGFudDtcbn1cblxuaW5wdXQge1xuICAtLWlvbi1iYWNrZ3JvdW5kOiByZWQgIWltcG9ydGFudDtcbn1cblxuLm1haW4tbGlzdCB7XG4gIC0taW9uLWJhY2tncm91bmQtY29sb3I6ICMwMDAgIWltcG9ydGFudDtcbn1cblxuLm1haW4tbGlzdCBpb24taXRlbSB7XG4gIC0taW9uLWJhY2tncm91bmQtY29sb3I6ICNmZmYgIWltcG9ydGFudDtcbiAgLS1wYWRkaW5nLXRvcDogMTBweCAhaW1wb3J0YW50O1xuICAtLXBhZGRpbmctYm90dG9tOiAxMHB4ICFpbXBvcnRhbnQ7XG59XG5cbi5tYWluLWxpc3QgaW9uLWF2YXRhciB7XG4gIG1hcmdpbjogMCAhaW1wb3J0YW50O1xufVxuXG4ubWFpbi1saXN0IC5pY29uIHtcbiAgZm9udC1zaXplOiAyNXB4O1xufVxuXG4ubWFpbi1saXN0IC5pdGVtIHtcbiAgcGFkZGluZzogMTBweDtcbn1cblxuLm1haW4tbGlzdCAuZi1pY29uIHtcbiAgZm9udC1zaXplOiAxNXB4O1xufVxuXG4uaW52b2ljZS11cGxvYWQge1xuICBtYXJnaW4tdG9wOiA1MHB4O1xufVxuXG4uc2V0LWNvbnRlbnQge1xuICB3aGl0ZS1zcGFjZTogbm9ybWFsO1xufVxuXG4uY29udGFpbmVyIHtcbiAgYmFja2dyb3VuZC1jb2xvcjogYmxhY2s7XG59XG5cbi53ZWJQYWdlIHtcbiAgd2lkdGg6IDEwMCU7XG4gIGhlaWdodDogNjAwcHg7XG59XG5cbi8qKkxJU1Q6IFNUQVJUKiovIl19 */";
    /***/
  },

  /***/
  "./src/app/main-list/main-list.page.ts":
  /*!*********************************************!*\
    !*** ./src/app/main-list/main-list.page.ts ***!
    \*********************************************/

  /*! exports provided: MainListPage */

  /***/
  function srcAppMainListMainListPageTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "MainListPage", function () {
      return MainListPage;
    });
    /* harmony import */


    var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! tslib */
    "./node_modules/tslib/tslib.es6.js");
    /* harmony import */


    var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! @angular/core */
    "./node_modules/@angular/core/fesm2015/core.js");
    /* harmony import */


    var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
    /*! @angular/router */
    "./node_modules/@angular/router/fesm2015/router.js");
    /* harmony import */


    var _services_category_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
    /*! ../services/category.service */
    "./src/app/services/category.service.ts");

    var MainListPage =
    /*#__PURE__*/
    function () {
      function MainListPage(activatedRoute, categoryService) {
        _classCallCheck(this, MainListPage);

        this.activatedRoute = activatedRoute;
        this.categoryService = categoryService;
        this.categoryArr = [];
        this.testObject = {};
        this.errMessage = "";
        this.searchQuery = "";
      }

      _createClass(MainListPage, [{
        key: "ngOnInit",
        value: function ngOnInit() {
          this.switch = this.activatedRoute.snapshot.paramMap.get('id');
          this.getCategoryData();
          this.errMessage = "";
        }
      }, {
        key: "getCategoryData",
        value: function getCategoryData() {
          var _this = this;

          // get Client Data
          if (this.switch && this.switch == '1') {
            this.categoryService.getSearchClientData().subscribe(function (res) {
              if (res) {
                _this.testObject = res;
                console.log("yyy", _this.testObject.keys);
              }
            }, function (err) {
              console.log("err", err);
            });
          } // get project Data


          if (this.switch && this.switch == '3') {
            this.categoryService.getSearchProjectData().subscribe(function (res) {
              if (res['data']) {
                _this.categoryArr = res['data'];
                console.log(_this.categoryArr, res, "apiiiiiiiiii");
              }
            }, function (err) {
              if (err['status'] == '404') {
                _this.errMessage = "Internal Error Occured";
              }

              console.log("err", err);
            });
          } // get invoice Data


          if (this.switch && this.switch == '4') {
            this.categoryService.getSearchInvoiceData().subscribe(function (res) {
              if (res && res['data']) {
                _this.categoryArr = res['data'];
              }
            }, function (err) {
              console.log("err", err);
            });
          } // get estimate Data


          if (this.switch && this.switch == '5') {
            this.categoryService.getSearchEstimateData().subscribe(function (res) {
              if (res['data']) {
                _this.categoryArr = res['data'];
                console.log(_this.categoryArr, res);
              }
            }, function (err) {
              console.log("err", err);
            });
          }
        }
      }, {
        key: "searchData",
        value: function searchData(sw) {
          var _this2 = this;

          console.log("yyy", sw, this.searchQuery);

          if (sw == '1') {
            this.categoryService.getSearchClientData(this.searchQuery).subscribe(function (res) {
              if (res) {
                _this2.testObject = res;
              }
            }, function (err) {
              console.log("err", err);
            });
          } else if (sw == '3') {
            this.categoryService.getSearchProjectData(this.searchQuery).subscribe(function (res) {
              if (res['data']) {
                _this2.categoryArr = res['data'];
                console.log(_this2.categoryArr, res, "api");
              }
            }, function (err) {
              if (err['status'] == '404') {
                _this2.errMessage = "Internal Error Occured";
              }

              console.log("err", err);
            });
          } else if (sw == '4') {
            this.categoryService.getSearchInvoiceData(this.searchQuery).subscribe(function (res) {
              if (res && res['data']) {
                _this2.categoryArr = res['data'];
              }
            }, function (err) {
              console.log("err", err);
            });
          } else if (sw == '5') {
            this.categoryService.getSearchEstimateData(this.searchQuery).subscribe(function (res) {
              if (res['data']) {
                _this2.categoryArr = res['data'];
                console.log(_this2.categoryArr, res);
              }
            }, function (err) {
              console.log("err", err);
            });
          }
        }
      }, {
        key: "isEmpty",
        value: function isEmpty(obj) {
          return Object.keys(obj).length === 0;
        }
      }]);

      return MainListPage;
    }();

    MainListPage.ctorParameters = function () {
      return [{
        type: _angular_router__WEBPACK_IMPORTED_MODULE_2__["ActivatedRoute"]
      }, {
        type: _services_category_service__WEBPACK_IMPORTED_MODULE_3__["CategoryService"]
      }];
    };

    MainListPage = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
      selector: 'app-main-list',
      template: tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(
      /*! raw-loader!./main-list.page.html */
      "./node_modules/raw-loader/dist/cjs.js!./src/app/main-list/main-list.page.html")).default,
      styles: [tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(
      /*! ./main-list.page.scss */
      "./src/app/main-list/main-list.page.scss")).default]
    }), tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_angular_router__WEBPACK_IMPORTED_MODULE_2__["ActivatedRoute"], _services_category_service__WEBPACK_IMPORTED_MODULE_3__["CategoryService"]])], MainListPage);
    /***/
  }
}]);
//# sourceMappingURL=main-list-main-list-module-es5.js.map
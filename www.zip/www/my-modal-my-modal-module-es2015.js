(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["my-modal-my-modal-module"],{

/***/ "./node_modules/raw-loader/dist/cjs.js!./src/app/my-modal/my-modal.page.html":
/*!***********************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/my-modal/my-modal.page.html ***!
  \***********************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("<div class=\"invoice-upload\">\n  <!-- modal start -->\n  <div class=\"modalcustom\">\n     <div class=\"modalcustom-header\">\n        <h4>Edit Call   <span class=\"custom-icon\"><i class=\"fa fa-times\" aria-hidden=\"true\"></i></span></h4>            \n     </div>\n     <div class=\"modalcustom-body\">                  \n      <ion-list class=\"modal-padd\">\n        <ion-item>\n          <ion-label>Select Staff</ion-label>\n          <ion-select okText=\"Okay\" cancelText=\"Dismiss\">\n            <ion-select-option>Female</ion-select-option>\n            <ion-select-option>Male</ion-select-option>\n          </ion-select>\n        </ion-item>        \n      </ion-list>           \n      <ion-item class=\"modal-padd\">\n        <ion-label>Start Date</ion-label>\n        <ion-datetime displayFormat=\"DD MM YYYY\" placeholder=\"Select Date\"></ion-datetime>\n      </ion-item>\n      <ion-item class=\"modal-padd\">\n        <ion-label>Start Time</ion-label>\n        <ion-datetime displayFormat=\"HH:mm\"  placeholder=\"Select Time\"></ion-datetime>\n      </ion-item>         \n      <ion-item class=\"modal-padd\">\n        <ion-label>End Date</ion-label>\n        <ion-datetime displayFormat=\"DD MM YYYY\" placeholder=\"Select Date\"></ion-datetime>\n      </ion-item>\n      <ion-item class=\"modal-padd\">\n        <ion-label>End Time</ion-label>\n        <ion-datetime displayFormat=\"HH:mm\"  placeholder=\"Select Time\"></ion-datetime>\n      </ion-item>\n      \n      \n     </div>\n     <div class=\"modalcustom-footer\">\n      <ion-button expand=\"fill\" color=\"success\"  class=\"mt-3 custom-btn\">Submit</ion-button>\n      <ion-button expand=\"fill\" color=\"danger\"  class=\"mt-3 custom-btn\">Delete</ion-button>\n     </div>\n  </div>\n</div>");

/***/ }),

/***/ "./src/app/my-modal/my-modal-routing.module.ts":
/*!*****************************************************!*\
  !*** ./src/app/my-modal/my-modal-routing.module.ts ***!
  \*****************************************************/
/*! exports provided: MyModalPageRoutingModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "MyModalPageRoutingModule", function() { return MyModalPageRoutingModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm2015/core.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm2015/router.js");
/* harmony import */ var _my_modal_page__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./my-modal.page */ "./src/app/my-modal/my-modal.page.ts");




const routes = [
    {
        path: '',
        component: _my_modal_page__WEBPACK_IMPORTED_MODULE_3__["MyModalPage"]
    }
];
let MyModalPageRoutingModule = class MyModalPageRoutingModule {
};
MyModalPageRoutingModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"].forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"]],
    })
], MyModalPageRoutingModule);



/***/ }),

/***/ "./src/app/my-modal/my-modal.module.ts":
/*!*********************************************!*\
  !*** ./src/app/my-modal/my-modal.module.ts ***!
  \*********************************************/
/*! exports provided: MyModalPageModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "MyModalPageModule", function() { return MyModalPageModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm2015/core.js");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/fesm2015/common.js");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/forms */ "./node_modules/@angular/forms/fesm2015/forms.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/fesm2015/ionic-angular.js");
/* harmony import */ var _my_modal_routing_module__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./my-modal-routing.module */ "./src/app/my-modal/my-modal-routing.module.ts");
/* harmony import */ var _my_modal_page__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./my-modal.page */ "./src/app/my-modal/my-modal.page.ts");







let MyModalPageModule = class MyModalPageModule {
};
MyModalPageModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"],
            _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormsModule"],
            _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["IonicModule"],
            _my_modal_routing_module__WEBPACK_IMPORTED_MODULE_5__["MyModalPageRoutingModule"]
        ],
        declarations: [_my_modal_page__WEBPACK_IMPORTED_MODULE_6__["MyModalPage"]]
    })
], MyModalPageModule);



/***/ }),

/***/ "./src/app/my-modal/my-modal.page.scss":
/*!*********************************************!*\
  !*** ./src/app/my-modal/my-modal.page.scss ***!
  \*********************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("/**LIST: START**/\n.search-bar {\n  background: #fff;\n  border-radius: 50px;\n  height: 40px;\n  margin-bottom: 20px;\n  padding: 0;\n}\n.searchbar-input-container input {\n  --background: #fff !important;\n}\ninput {\n  --ion-background: red !important;\n}\n.main-list {\n  --ion-background-color: #000 !important;\n}\n.main-list ion-item {\n  --ion-background-color: #fff !important;\n  --padding-top: 10px !important;\n  --padding-bottom: 10px !important;\n}\n.main-list ion-avatar {\n  margin: 0 !important;\n}\n.main-list .icon {\n  font-size: 25px;\n}\n.main-list .item {\n  padding: 10px;\n}\n.main-list .f-icon {\n  font-size: 15px;\n}\n.main-workflow {\n  padding: 0 7px;\n}\n.accordion-icon {\n  font-size: 20px !important;\n  float: right;\n  margin-top: 7px;\n}\n.invoice-upload {\n  margin-top: 50px;\n}\n.set-content {\n  white-space: normal;\n}\n.container {\n  background-color: black;\n}\n.search-bar {\n  background: #fff;\n  border-radius: 50px;\n  height: 40px;\n  margin: 5px 0;\n  padding: 0;\n}\n.webPage {\n  width: 100%;\n  height: 600px;\n}\nion-spinner {\n  position: fixed;\n  z-index: 999;\n  height: 5em;\n  width: em;\n  overflow: show;\n  margin: auto;\n  top: 0;\n  left: 0;\n  bottom: 0;\n  right: 0;\n}\n.modalcustom {\n  background: #fff;\n  color: #000;\n  padding: 10px;\n  width: 90%;\n  margin: auto;\n}\n.modalcustom-header {\n  border-bottom: 1px solid #d2d2d2;\n}\n.modalcustom-header h4 {\n  margin: 10px 0;\n}\n.modalcustom-header .custom-icon {\n  float: right;\n  font-size: 15px;\n  margin-top: 2px;\n}\n.modalcustom-body {\n  padding: 20px 0;\n}\n.modal-padd {\n  padding-right: 20px;\n}\n.modalcustom-footer {\n  border-top: 1px solid #d2d2d2;\n}\n.modalcustom-footer .custom-btn {\n  height: 30px;\n  padding: 1px 10px;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvbXktbW9kYWwvRTpcXHNoaXBnaWdcXGNva2tpZS1hcHAvc3JjXFxhcHBcXG15LW1vZGFsXFxteS1tb2RhbC5wYWdlLnNjc3MiLCJzcmMvYXBwL215LW1vZGFsL215LW1vZGFsLnBhZ2Uuc2NzcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQSxnQkFBQTtBQUNBO0VBQ0ksZ0JBQUE7RUFDQSxtQkFBQTtFQUNBLFlBQUE7RUFDQSxtQkFBQTtFQUNBLFVBQUE7QUNDSjtBREVFO0VBQ0UsNkJBQUE7QUNDSjtBREVFO0VBQ0UsZ0NBQUE7QUNDSjtBREVFO0VBQ0UsdUNBQUE7QUNDSjtBREVFO0VBQ0UsdUNBQUE7RUFDQSw4QkFBQTtFQUNBLGlDQUFBO0FDQ0o7QURFRTtFQUNFLG9CQUFBO0FDQ0o7QURFRTtFQUNFLGVBQUE7QUNDSjtBREVFO0VBQ0UsYUFBQTtBQ0NKO0FERUU7RUFDRSxlQUFBO0FDQ0o7QURDRTtFQUNFLGNBQUE7QUNFSjtBREFFO0VBQ0UsMEJBQUE7RUFDQSxZQUFBO0VBQ0EsZUFBQTtBQ0dKO0FEREU7RUFDRSxnQkFBQTtBQ0lKO0FEREU7RUFDRSxtQkFBQTtBQ0lKO0FEREU7RUFDRSx1QkFBQTtBQ0lKO0FEREU7RUFDRSxnQkFBQTtFQUNBLG1CQUFBO0VBQ0EsWUFBQTtFQUNBLGFBQUE7RUFDQSxVQUFBO0FDSUo7QURERTtFQUNFLFdBQUE7RUFDQSxhQUFBO0FDSUo7QURERTtFQUNFLGVBQUE7RUFDQSxZQUFBO0VBQ0EsV0FBQTtFQUNBLFNBQUE7RUFDQSxjQUFBO0VBQ0EsWUFBQTtFQUNBLE1BQUE7RUFDQSxPQUFBO0VBQ0EsU0FBQTtFQUNBLFFBQUE7QUNJSjtBREFFO0VBQ0UsZ0JBQUE7RUFDQSxXQUFBO0VBQ0EsYUFBQTtFQUNBLFVBQUE7RUFDQSxZQUFBO0FDR0o7QURERTtFQUNFLGdDQUFBO0FDSUo7QURGRTtFQUNFLGNBQUE7QUNLSjtBREhFO0VBQ0UsWUFBQTtFQUNBLGVBQUE7RUFDQSxlQUFBO0FDTUo7QURKRTtFQUNFLGVBQUE7QUNPSjtBRExFO0VBQ0UsbUJBQUE7QUNRSjtBRExFO0VBQ0UsNkJBQUE7QUNRSjtBRE5FO0VBQ0UsWUFBQTtFQUNBLGlCQUFBO0FDU0oiLCJmaWxlIjoic3JjL2FwcC9teS1tb2RhbC9teS1tb2RhbC5wYWdlLnNjc3MiLCJzb3VyY2VzQ29udGVudCI6WyIvKipMSVNUOiBTVEFSVCoqL1xyXG4uc2VhcmNoLWJhciB7XHJcbiAgICBiYWNrZ3JvdW5kOiAjZmZmO1xyXG4gICAgYm9yZGVyLXJhZGl1czogNTBweDtcclxuICAgIGhlaWdodDogNDBweDtcclxuICAgIG1hcmdpbi1ib3R0b206IDIwcHg7XHJcbiAgICBwYWRkaW5nOiAwO1xyXG4gIH1cclxuICBcclxuICAuc2VhcmNoYmFyLWlucHV0LWNvbnRhaW5lciBpbnB1dCB7XHJcbiAgICAtLWJhY2tncm91bmQ6ICNmZmYgIWltcG9ydGFudDtcclxuICB9XHJcbiAgXHJcbiAgaW5wdXQge1xyXG4gICAgLS1pb24tYmFja2dyb3VuZDogcmVkICFpbXBvcnRhbnQ7XHJcbiAgfVxyXG4gIFxyXG4gIC5tYWluLWxpc3Qge1xyXG4gICAgLS1pb24tYmFja2dyb3VuZC1jb2xvcjogIzAwMCAhaW1wb3J0YW50O1xyXG4gIH1cclxuICBcclxuICAubWFpbi1saXN0IGlvbi1pdGVtIHtcclxuICAgIC0taW9uLWJhY2tncm91bmQtY29sb3I6ICNmZmYgIWltcG9ydGFudDtcclxuICAgIC0tcGFkZGluZy10b3A6IDEwcHggIWltcG9ydGFudDtcclxuICAgIC0tcGFkZGluZy1ib3R0b206IDEwcHggIWltcG9ydGFudDtcclxuICB9XHJcbiAgXHJcbiAgLm1haW4tbGlzdCBpb24tYXZhdGFyIHtcclxuICAgIG1hcmdpbjogMCAhaW1wb3J0YW50O1xyXG4gIH1cclxuICBcclxuICAubWFpbi1saXN0IC5pY29uIHtcclxuICAgIGZvbnQtc2l6ZTogMjVweDtcclxuICB9XHJcbiAgXHJcbiAgLm1haW4tbGlzdCAuaXRlbSB7XHJcbiAgICBwYWRkaW5nOiAxMHB4O1xyXG4gIH1cclxuICBcclxuICAubWFpbi1saXN0IC5mLWljb24ge1xyXG4gICAgZm9udC1zaXplOiAxNXB4O1xyXG4gIH1cclxuICAubWFpbi13b3JrZmxvd3tcclxuICAgIHBhZGRpbmc6IDAgN3B4O1xyXG4gIH1cclxuICAuYWNjb3JkaW9uLWljb257XHJcbiAgICBmb250LXNpemU6IDIwcHggIWltcG9ydGFudDtcclxuICAgIGZsb2F0OiByaWdodDtcclxuICAgIG1hcmdpbi10b3A6N3B4O1xyXG4gIH1cclxuICAuaW52b2ljZS11cGxvYWQge1xyXG4gICAgbWFyZ2luLXRvcDogNTBweDtcclxuICB9XHJcbiAgXHJcbiAgLnNldC1jb250ZW50IHtcclxuICAgIHdoaXRlLXNwYWNlOiBub3JtYWw7XHJcbiAgfVxyXG4gIFxyXG4gIC5jb250YWluZXIge1xyXG4gICAgYmFja2dyb3VuZC1jb2xvcjogYmxhY2s7XHJcbiAgfVxyXG4gIFxyXG4gIC5zZWFyY2gtYmFyIHtcclxuICAgIGJhY2tncm91bmQ6ICNmZmY7XHJcbiAgICBib3JkZXItcmFkaXVzOiA1MHB4O1xyXG4gICAgaGVpZ2h0OiA0MHB4O1xyXG4gICAgbWFyZ2luOiA1cHggMDtcclxuICAgIHBhZGRpbmc6IDA7XHJcbiAgfVxyXG4gIFxyXG4gIC53ZWJQYWdle1xyXG4gICAgd2lkdGg6IDEwMCU7XHJcbiAgICBoZWlnaHQ6IDYwMHB4O1xyXG4gIH1cclxuICBcclxuICBpb24tc3Bpbm5lciB7XHJcbiAgICBwb3NpdGlvbjogZml4ZWQ7XHJcbiAgICB6LWluZGV4OiA5OTk7XHJcbiAgICBoZWlnaHQ6IDVlbTtcclxuICAgIHdpZHRoOiBlbTtcclxuICAgIG92ZXJmbG93OiBzaG93O1xyXG4gICAgbWFyZ2luOiBhdXRvO1xyXG4gICAgdG9wOiAwO1xyXG4gICAgbGVmdDogMDtcclxuICAgIGJvdHRvbTogMDtcclxuICAgIHJpZ2h0OiAwO1xyXG4gIH1cclxuICBcclxuICAvLyBtb2RhbCBjc3Mgc3RhcnRcclxuICAubW9kYWxjdXN0b20ge1xyXG4gICAgYmFja2dyb3VuZDogI2ZmZjtcclxuICAgIGNvbG9yOiAjMDAwO1xyXG4gICAgcGFkZGluZzogMTBweDtcclxuICAgIHdpZHRoOiA5MCU7XHJcbiAgICBtYXJnaW46IGF1dG87XHJcbiAgfVxyXG4gIC5tb2RhbGN1c3RvbS1oZWFkZXIge1xyXG4gICAgYm9yZGVyLWJvdHRvbTogMXB4IHNvbGlkICNkMmQyZDI7XHJcbiAgfVxyXG4gIC5tb2RhbGN1c3RvbS1oZWFkZXIgaDR7XHJcbiAgICBtYXJnaW46IDEwcHggMDtcclxuICB9XHJcbiAgLm1vZGFsY3VzdG9tLWhlYWRlciAuY3VzdG9tLWljb257XHJcbiAgICBmbG9hdDogcmlnaHQ7XHJcbiAgICBmb250LXNpemU6IDE1cHg7XHJcbiAgICBtYXJnaW4tdG9wOiAycHg7XHJcbiAgfVxyXG4gIC5tb2RhbGN1c3RvbS1ib2R5e1xyXG4gICAgcGFkZGluZzogMjBweCAwO1xyXG4gIH1cclxuICAubW9kYWwtcGFkZHtcclxuICAgIHBhZGRpbmctcmlnaHQ6IDIwcHg7XHJcbiAgfVxyXG4gIFxyXG4gIC5tb2RhbGN1c3RvbS1mb290ZXIge1xyXG4gICAgYm9yZGVyLXRvcDogMXB4IHNvbGlkICNkMmQyZDI7XHJcbiAgfVxyXG4gIC5tb2RhbGN1c3RvbS1mb290ZXIgLmN1c3RvbS1idG57XHJcbiAgICBoZWlnaHQ6IDMwcHg7XHJcbiAgICBwYWRkaW5nOiAxcHggMTBweDtcclxuICB9XHJcbiAgLy8gbW9kYWwgY3NzIGVuZCIsIi8qKkxJU1Q6IFNUQVJUKiovXG4uc2VhcmNoLWJhciB7XG4gIGJhY2tncm91bmQ6ICNmZmY7XG4gIGJvcmRlci1yYWRpdXM6IDUwcHg7XG4gIGhlaWdodDogNDBweDtcbiAgbWFyZ2luLWJvdHRvbTogMjBweDtcbiAgcGFkZGluZzogMDtcbn1cblxuLnNlYXJjaGJhci1pbnB1dC1jb250YWluZXIgaW5wdXQge1xuICAtLWJhY2tncm91bmQ6ICNmZmYgIWltcG9ydGFudDtcbn1cblxuaW5wdXQge1xuICAtLWlvbi1iYWNrZ3JvdW5kOiByZWQgIWltcG9ydGFudDtcbn1cblxuLm1haW4tbGlzdCB7XG4gIC0taW9uLWJhY2tncm91bmQtY29sb3I6ICMwMDAgIWltcG9ydGFudDtcbn1cblxuLm1haW4tbGlzdCBpb24taXRlbSB7XG4gIC0taW9uLWJhY2tncm91bmQtY29sb3I6ICNmZmYgIWltcG9ydGFudDtcbiAgLS1wYWRkaW5nLXRvcDogMTBweCAhaW1wb3J0YW50O1xuICAtLXBhZGRpbmctYm90dG9tOiAxMHB4ICFpbXBvcnRhbnQ7XG59XG5cbi5tYWluLWxpc3QgaW9uLWF2YXRhciB7XG4gIG1hcmdpbjogMCAhaW1wb3J0YW50O1xufVxuXG4ubWFpbi1saXN0IC5pY29uIHtcbiAgZm9udC1zaXplOiAyNXB4O1xufVxuXG4ubWFpbi1saXN0IC5pdGVtIHtcbiAgcGFkZGluZzogMTBweDtcbn1cblxuLm1haW4tbGlzdCAuZi1pY29uIHtcbiAgZm9udC1zaXplOiAxNXB4O1xufVxuXG4ubWFpbi13b3JrZmxvdyB7XG4gIHBhZGRpbmc6IDAgN3B4O1xufVxuXG4uYWNjb3JkaW9uLWljb24ge1xuICBmb250LXNpemU6IDIwcHggIWltcG9ydGFudDtcbiAgZmxvYXQ6IHJpZ2h0O1xuICBtYXJnaW4tdG9wOiA3cHg7XG59XG5cbi5pbnZvaWNlLXVwbG9hZCB7XG4gIG1hcmdpbi10b3A6IDUwcHg7XG59XG5cbi5zZXQtY29udGVudCB7XG4gIHdoaXRlLXNwYWNlOiBub3JtYWw7XG59XG5cbi5jb250YWluZXIge1xuICBiYWNrZ3JvdW5kLWNvbG9yOiBibGFjaztcbn1cblxuLnNlYXJjaC1iYXIge1xuICBiYWNrZ3JvdW5kOiAjZmZmO1xuICBib3JkZXItcmFkaXVzOiA1MHB4O1xuICBoZWlnaHQ6IDQwcHg7XG4gIG1hcmdpbjogNXB4IDA7XG4gIHBhZGRpbmc6IDA7XG59XG5cbi53ZWJQYWdlIHtcbiAgd2lkdGg6IDEwMCU7XG4gIGhlaWdodDogNjAwcHg7XG59XG5cbmlvbi1zcGlubmVyIHtcbiAgcG9zaXRpb246IGZpeGVkO1xuICB6LWluZGV4OiA5OTk7XG4gIGhlaWdodDogNWVtO1xuICB3aWR0aDogZW07XG4gIG92ZXJmbG93OiBzaG93O1xuICBtYXJnaW46IGF1dG87XG4gIHRvcDogMDtcbiAgbGVmdDogMDtcbiAgYm90dG9tOiAwO1xuICByaWdodDogMDtcbn1cblxuLm1vZGFsY3VzdG9tIHtcbiAgYmFja2dyb3VuZDogI2ZmZjtcbiAgY29sb3I6ICMwMDA7XG4gIHBhZGRpbmc6IDEwcHg7XG4gIHdpZHRoOiA5MCU7XG4gIG1hcmdpbjogYXV0bztcbn1cblxuLm1vZGFsY3VzdG9tLWhlYWRlciB7XG4gIGJvcmRlci1ib3R0b206IDFweCBzb2xpZCAjZDJkMmQyO1xufVxuXG4ubW9kYWxjdXN0b20taGVhZGVyIGg0IHtcbiAgbWFyZ2luOiAxMHB4IDA7XG59XG5cbi5tb2RhbGN1c3RvbS1oZWFkZXIgLmN1c3RvbS1pY29uIHtcbiAgZmxvYXQ6IHJpZ2h0O1xuICBmb250LXNpemU6IDE1cHg7XG4gIG1hcmdpbi10b3A6IDJweDtcbn1cblxuLm1vZGFsY3VzdG9tLWJvZHkge1xuICBwYWRkaW5nOiAyMHB4IDA7XG59XG5cbi5tb2RhbC1wYWRkIHtcbiAgcGFkZGluZy1yaWdodDogMjBweDtcbn1cblxuLm1vZGFsY3VzdG9tLWZvb3RlciB7XG4gIGJvcmRlci10b3A6IDFweCBzb2xpZCAjZDJkMmQyO1xufVxuXG4ubW9kYWxjdXN0b20tZm9vdGVyIC5jdXN0b20tYnRuIHtcbiAgaGVpZ2h0OiAzMHB4O1xuICBwYWRkaW5nOiAxcHggMTBweDtcbn0iXX0= */");

/***/ }),

/***/ "./src/app/my-modal/my-modal.page.ts":
/*!*******************************************!*\
  !*** ./src/app/my-modal/my-modal.page.ts ***!
  \*******************************************/
/*! exports provided: MyModalPage */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "MyModalPage", function() { return MyModalPage; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm2015/core.js");


let MyModalPage = class MyModalPage {
    constructor() { }
    ngOnInit() {
        // console.table(this.navParams);
    }
};
MyModalPage = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
        selector: 'app-my-modal',
        template: tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(/*! raw-loader!./my-modal.page.html */ "./node_modules/raw-loader/dist/cjs.js!./src/app/my-modal/my-modal.page.html")).default,
        styles: [tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(/*! ./my-modal.page.scss */ "./src/app/my-modal/my-modal.page.scss")).default]
    }),
    tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [])
], MyModalPage);



/***/ })

}]);
//# sourceMappingURL=my-modal-my-modal-module-es2015.js.map
(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["signup-signup-module"],{

/***/ "./node_modules/raw-loader/dist/cjs.js!./src/app/signup/signup.page.html":
/*!*******************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/signup/signup.page.html ***!
  \*******************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("<ion-header class=\"customize-toolbar test\">\n  <ion-toolbar class=\"sign-main\">\n    <ion-img class=\"logo p-3\" src=\"assets/img/logo.png\"></ion-img>\n  </ion-toolbar>\n</ion-header>\n\n<ion-content *ngIf=\"isLogin\" class=\"signin-bg\">\n  <div class=\"app-layout set-height\">\n    <div class=\"container\">\n      <div class=\"form-login\">\n        <div class=\"heading\">\n          <h3>SIGN IN</h3>\n        </div>\n        <form>\n          <div class=\"form-group\">\n            <input type=\"text\" class=\"form-control\" placeholder=\"Username\" name=\"user\"\n              [(ngModel)]=\"userCredentials.username\" id=\"user\">\n          </div>\n          <div class=\"form-group\">\n            <input type=\"password\" class=\"form-control\" placeholder=\"Password\" name=\"pass\"\n              [(ngModel)]=\"userCredentials.password\" id=\"pwd\">\n          </div>\n          <button type=\"submit\" class=\"btn-submit\" (click)=\"login(userCredentials)\">SIGN\n            IN</button>\n          <p> New to Cooke & Sons? <span (click)=\"togglePage()\">Create Account</span></p>\n        </form>\n        <div *ngIf=\"isFailed\" class=\"text-danger\">{{errMessage}}</div>\n      </div>\n    </div>\n  </div>\n</ion-content>\n\n<ion-content *ngIf=\"!isLogin\" class=\"signin-bg\">\n  <div class=\"app-layout set-height\">\n    <div class=\"container\">\n      <div class=\"form-login\">\n        <div class=\"heading\">\n          <h3>SIGN UP</h3>\n        </div>\n        <form action=\"\">\n          <div class=\"form-group\">\n            <input type=\"email\" class=\"form-control\" placeholder=\"Enter your E-mail address\">\n          </div>\n          <div class=\"form-group\">\n            <input type=\"password\" class=\"form-control\" placeholder=\"Confirm New Password\">\n          </div>\n          <div class=\"form-group\">\n            <input type=\"password\" class=\"form-control\" placeholder=\"Re-enter your  New Password\">\n          </div>\n          <button type=\"submit\" class=\"btn-submit\">SIGN UP</button>\n          <p>Already have an account? <span (click)=\"togglePage()\">Sign in</span></p>\n        </form>\n      </div>\n    </div>\n  </div>\n</ion-content>");

/***/ }),

/***/ "./src/app/signup/signup-routing.module.ts":
/*!*************************************************!*\
  !*** ./src/app/signup/signup-routing.module.ts ***!
  \*************************************************/
/*! exports provided: SignupPageRoutingModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "SignupPageRoutingModule", function() { return SignupPageRoutingModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm2015/core.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm2015/router.js");
/* harmony import */ var _signup_page__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./signup.page */ "./src/app/signup/signup.page.ts");




const routes = [
    {
        path: '',
        component: _signup_page__WEBPACK_IMPORTED_MODULE_3__["SignupPage"]
    }
];
let SignupPageRoutingModule = class SignupPageRoutingModule {
};
SignupPageRoutingModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"].forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"]],
    })
], SignupPageRoutingModule);



/***/ }),

/***/ "./src/app/signup/signup.module.ts":
/*!*****************************************!*\
  !*** ./src/app/signup/signup.module.ts ***!
  \*****************************************/
/*! exports provided: SignupPageModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "SignupPageModule", function() { return SignupPageModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm2015/core.js");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/fesm2015/common.js");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/forms */ "./node_modules/@angular/forms/fesm2015/forms.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/fesm2015/ionic-angular.js");
/* harmony import */ var _signup_routing_module__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./signup-routing.module */ "./src/app/signup/signup-routing.module.ts");
/* harmony import */ var _signup_page__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./signup.page */ "./src/app/signup/signup.page.ts");







let SignupPageModule = class SignupPageModule {
};
SignupPageModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"],
            _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormsModule"],
            _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["IonicModule"],
            _signup_routing_module__WEBPACK_IMPORTED_MODULE_5__["SignupPageRoutingModule"]
        ],
        declarations: [_signup_page__WEBPACK_IMPORTED_MODULE_6__["SignupPage"]]
    })
], SignupPageModule);



/***/ }),

/***/ "./src/app/signup/signup.page.scss":
/*!*****************************************!*\
  !*** ./src/app/signup/signup.page.scss ***!
  \*****************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = (".set-height {\n  height: 100%;\n}\n\n.signin-bg {\n  --background: #000;\n}\n\n.toolbar-container {\n  padding: 0 !important;\n  --background: #000 !important;\n}\n\n.sign-main {\n  --background: #000;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvc2lnbnVwL0U6XFxzaGlwZ2lnXFxjb2traWUtYXBwL3NyY1xcYXBwXFxzaWdudXBcXHNpZ251cC5wYWdlLnNjc3MiLCJzcmMvYXBwL3NpZ251cC9zaWdudXAucGFnZS5zY3NzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBO0VBQ0ksWUFBQTtBQ0NKOztBRENBO0VBQ0csa0JBQUE7QUNFSDs7QURBQTtFQUNJLHFCQUFBO0VBQ0EsNkJBQUE7QUNHSjs7QUREQTtFQUNJLGtCQUFBO0FDSUoiLCJmaWxlIjoic3JjL2FwcC9zaWdudXAvc2lnbnVwLnBhZ2Uuc2NzcyIsInNvdXJjZXNDb250ZW50IjpbIi5zZXQtaGVpZ2h0IHtcbiAgICBoZWlnaHQ6IDEwMCU7XG59XG4uc2lnbmluLWJne1xuICAgLS1iYWNrZ3JvdW5kOiAjMDAwOztcbn1cbi50b29sYmFyLWNvbnRhaW5lcntcbiAgICBwYWRkaW5nOiAwICFpbXBvcnRhbnQ7XG4gICAgLS1iYWNrZ3JvdW5kOiAjMDAwICFpbXBvcnRhbnQ7XG59XG4uc2lnbi1tYWlue1xuICAgIC0tYmFja2dyb3VuZDogIzAwMDtcbn0iLCIuc2V0LWhlaWdodCB7XG4gIGhlaWdodDogMTAwJTtcbn1cblxuLnNpZ25pbi1iZyB7XG4gIC0tYmFja2dyb3VuZDogIzAwMDtcbn1cblxuLnRvb2xiYXItY29udGFpbmVyIHtcbiAgcGFkZGluZzogMCAhaW1wb3J0YW50O1xuICAtLWJhY2tncm91bmQ6ICMwMDAgIWltcG9ydGFudDtcbn1cblxuLnNpZ24tbWFpbiB7XG4gIC0tYmFja2dyb3VuZDogIzAwMDtcbn0iXX0= */");

/***/ }),

/***/ "./src/app/signup/signup.page.ts":
/*!***************************************!*\
  !*** ./src/app/signup/signup.page.ts ***!
  \***************************************/
/*! exports provided: SignupPage */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "SignupPage", function() { return SignupPage; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm2015/core.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm2015/router.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/fesm2015/ionic-angular.js");
/* harmony import */ var _services_authentication_service__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../services/authentication.service */ "./src/app/services/authentication.service.ts");





let SignupPage = class SignupPage {
    constructor(loginService, router, menu) {
        this.loginService = loginService;
        this.router = router;
        this.menu = menu;
        this.errMessage = "";
        this.isLogin = true;
        this.isFailed = false;
        this.userCredentials = {
            username: "",
            password: ""
        };
    }
    ngOnInit() {
        this.userCredentials = {
            username: "",
            password: ""
        };
        this.errMessage = "";
    }
    ionViewDidEnter() {
        setTimeout(() => {
            this.menu.swipeGesture(false);
        }, 2000);
    }
    ionViewWillLeave() {
        this.menu.swipeGesture(true);
    }
    togglePage() {
        this.isLogin = !this.isLogin;
    }
    login(loginData) {
        if (!loginData || !loginData.username || !loginData.password) {
            this.isFailed = true;
            this.errMessage = "FILL ALL THE DETAILS";
            return;
        }
        else {
            const formData = new FormData();
            formData.append('username', loginData.username);
            formData.append('password', loginData.password);
            this.loginService.oniLogin(formData).subscribe(res => {
                if (res && res['data']) {
                    if (res['code'] == "invalid_username") {
                        this.isFailed = true;
                        this.errMessage = "INVALID CREDENTIALS";
                    }
                    else {
                        this.router.navigate(['home']);
                        localStorage.setItem("userData", JSON.stringify(res['data']));
                    }
                }
                else {
                    this.isFailed = true;
                    this.errMessage = "INVALID CREDENTIALS";
                }
            }, err => {
                this.isFailed = true;
                this.errMessage = "INVALID CREDENTIALS";
            });
        }
    }
};
SignupPage.ctorParameters = () => [
    { type: _services_authentication_service__WEBPACK_IMPORTED_MODULE_4__["AuthenticationService"] },
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_2__["Router"] },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_3__["MenuController"] }
];
SignupPage = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
        selector: 'app-signup',
        template: tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(/*! raw-loader!./signup.page.html */ "./node_modules/raw-loader/dist/cjs.js!./src/app/signup/signup.page.html")).default,
        providers: [_services_authentication_service__WEBPACK_IMPORTED_MODULE_4__["AuthenticationService"]],
        styles: [tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(/*! ./signup.page.scss */ "./src/app/signup/signup.page.scss")).default]
    }),
    tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_services_authentication_service__WEBPACK_IMPORTED_MODULE_4__["AuthenticationService"],
        _angular_router__WEBPACK_IMPORTED_MODULE_2__["Router"],
        _ionic_angular__WEBPACK_IMPORTED_MODULE_3__["MenuController"]])
], SignupPage);



/***/ })

}]);
//# sourceMappingURL=signup-signup-module-es2015.js.map
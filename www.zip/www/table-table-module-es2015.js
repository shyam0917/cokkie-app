(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["table-table-module"],{

/***/ "./node_modules/raw-loader/dist/cjs.js!./src/app/table/table.page.html":
/*!*****************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/table/table.page.html ***!
  \*****************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("<ion-header>\n  <ion-toolbar class=\"customize-toolbar\">\n    <ion-buttons slot=\"start\">\n      <ion-back-button text=\"\" color=\"light\"></ion-back-button>\n    </ion-buttons>\n    <ion-img class=\"logo p-3\" src=\"assets/img/logo.png\"></ion-img>\n  </ion-toolbar>\n</ion-header>\n\n<ion-content *ngIf=\"tableSwitch=='1'\">\n  <div class=\"app-layout set-height\">\n    <div class=\"container\">\n      <div class=\"heading\">\n        <h3>CLIENT INFO</h3>\n      </div>\n      <ion-list class=\"main-list\">\n        <ion-item lines=\"none\">\n          <ion-label>\n            <div class=\"main-detail\">\n              <h3><b>Name: </b>{{tableData?.title}}</h3>\n              <h3 id=\"projects\"><b>Client Type: </b>Projects </h3>\n              <div class=\"main-subdetail\">\n                <h2><b>Associated User</b></h2>\n                <p><b>User ID: </b>{{tableData?.userid}}</p>\n                <p><b>Username: </b> btran@fusion-projects.com</p>\n                <p><b>Company Name: </b>{{tableData?.company_name}}</p>\n              </div>\n              <div class=\"main-subdetail\">\n                <h2><b>Contact Details</b></h2>\n                <p><b>Contact Name: </b>{{tableData?.company_contact}}</p>\n                <p><b>Email: </b>{{tableData?.company_email}}</p>\n                <p><b>Telephone: </b>{{tableData?.company_telephone}}</p>\n              </div>\n              <!-- <div class=\"note-detail py-1\">\n              <h2><b>Add Note</b></h2>\n              <ion-textarea class=\"border border-secondary p-1\" placeholder=\"Enter any notes here...\">\n              </ion-textarea>\n              <ion-button expand=\"fill\">Submit</ion-button>\n            </div>\n            <div class=\"note-detail py-1\">\n              <h2><b>Upload Image</b></h2>\n              <ion-button expand=\"fill\" color=\"success\" class=\"mt-3\">Upload Image</ion-button>\n            </div> -->\n            </div>\n          </ion-label>\n        </ion-item>\n      </ion-list>\n    </div>\n  </div>\n</ion-content>\n\n\n<ion-content *ngIf=\"tableSwitch=='2'\">\n  <div class=\"app-layout set-height\">\n    <div class=\"container\">\n      <div class=\"heading\">\n        <h3>CLOCK IN/OUT</h3>\n      </div>\n      <ion-list class=\"main-list\">\n\n        <ion-item lines=\"none\">\n          <ion-label>\n            <ion-label>\n              <div class=\"main-detail\">\n                <h3><b>Name: </b>Fusion Projects </h3>\n                <h3 id=\"projects\"><b>Type: </b>Projects </h3>\n                <div class=\"main-subdetail\">\n                  <h3><b>In-Time </b> 11:10 AM </h3>\n                  <h3 id=\"projects\"><b>Out-Time </b> 07:00 PM </h3>\n\n                  <!-- <h2><b>In-Time</b></h2>\n                    <p><b>User ID: </b> 106</p>\n                    <p><b>Username: </b> btran@fusion-projects.com</p>\n                    <p><b>Company Name: </b> Fusion projects</p> -->\n                </div>\n              </div>\n            </ion-label>\n          </ion-label>\n        </ion-item>\n      </ion-list>\n    </div>\n  </div>\n</ion-content>\n\n<ion-content *ngIf=\"tableSwitch=='3'\">\n  <div class=\"app-layout set-height\">\n    <div class=\"container\">\n      <div class=\"heading\">\n        <h3>PROJECT INFO</h3>\n      </div>\n      <ion-list class=\"main-list\">\n        <ion-item lines=\"none\">\n          <div class=\"main-detail set-p\">\n            <h3><b>Name: </b>{{tableData?.title}}</h3>\n            <h3 class=\"mt-1\"><b>Last Modified: </b>{{tableData?.post_modified | date: 'dd/MM/yyyy'}} </h3>\n            <h3 id=\"projects\" class=\"mt-1\"><b>Project Type: </b><span innerHTML=\"{{tableData?.project_type}}\"></span>\n            </h3>\n            <div class=\"main-subdetail py-1\">\n              <h2><b>Client Details</b></h2>\n              <span *ngIf=\"!tableData?.error\">\n                <p><b>Company Name: </b><span innerHTML=\"{{tableData?.client_company_name}}\"></span></p>\n                <p><b>Contact Name: </b> {{tableData?.client_contact_name}}</p>\n                <p><b>Email: </b> {{tableData?.client_email}}</p>\n                <p><b>Telephone: </b> {{tableData?.client_telephone}}</p>\n              </span>\n              <span *ngIf=\"tableData?.error\">\n                <p>{{tableData?.error}}</p>\n              </span>\n            </div>\n            <div class=\"main-subdetail py-1\">\n              <h2><b>Status</b></h2>\n              <p>{{tableData?.project_status}}</p>\n            </div>\n            <div class=\"note-detail py-1\">\n              <h2><b>Add Note</b></h2>\n              <ion-textarea class=\"border border-secondary p-1\" placeholder=\"Enter any notes here...\">\n              </ion-textarea>\n              <ion-button expand=\"fill\">Submit</ion-button>\n            </div>\n            <div class=\"note-detail py-1\">\n              <h2><b>Upload Image</b></h2>\n              <ion-button expand=\"fill\" color=\"success\" class=\"mt-3\">Upload Image</ion-button>\n            </div>\n          </div>\n\n        </ion-item>\n      </ion-list>\n    </div>\n  </div>\n</ion-content>\n\n<ion-content *ngIf=\"tableSwitch=='4'\">\n  <div class=\"app-layout set-height\">\n    <div class=\"container\">\n      <div class=\"heading\">\n        <h3>INVOICE INFO</h3>\n      </div>\n      <ion-list class=\"main-list\">\n\n        <ion-item lines=\"none\">\n          <ion-label>\n            <ion-label>\n              <div class=\"main-detail\">\n                <h3><b>Name: </b>{{tableData?.title}} </h3>\n                <h3><b>Amount: </b>{{tableData?.client_invoice_amount}} </h3>\n                <!-- <h3 id=\"projects\"><b>Issue / Due Dates: </b>14/02/2020 </h3> -->\n                <div class=\"main-subdetail\">\n                  <h2><b>Issue / Due Dates:</b></h2>\n                  <p><b>Invoice Date: </b> {{tableData?.invoice_date}}</p>\n                  <p><b>Due Date: </b> {{tableData?.due_date}}</p>\n                </div>\n                <div class=\"main-subdetail\">\n                  <h2><b>Client Details</b></h2>\n                  <p><b>Name: </b> {{tableData?.client_contact_name}}</p>\n                </div>\n                <div class=\"main-subdetail\">\n                  <h2><b>Status</b></h2>\n                  <p class=\"set-content\">{{tableData?.invoice_status}}</p>\n                </div>\n              </div>\n            </ion-label>\n          </ion-label>\n        </ion-item>\n      </ion-list>\n    </div>\n  </div>\n</ion-content>\n\n<ion-content *ngIf=\"tableSwitch=='5'\">\n  <div class=\"app-layout set-height\">\n    <div class=\"container\">\n      <div class=\"heading\">\n        <h3>ESTIMATE INFO</h3>\n      </div>\n      <ion-list class=\"main-list\">\n\n        <ion-item lines=\"none\">\n          <ion-label>\n            <ion-label>\n              <div class=\"main-detail\">\n                <h3><b>Name: </b>\n                  <span innerHTML=\"{{tableData?.title}}\"></span>\n                </h3>\n                <!-- <h3><b>Amount: </b>$20 </h3> -->\n                <!-- <h3 id=\"projects\"><b>Issue / Due Dates: </b>14/02/2020 </h3> -->\n                <div class=\"main-subdetail\">\n                  <h2><b>Client Details</b></h2>\n                  <p><b>Company Name: </b> {{tableData?.client_company_name}}</p>\n                  <p><b>Contact Name: </b> {{tableData?.client_contact_name}}</p>\n                  <p><b>Email: </b> {{tableData?.client_email}}</p>\n                  <p><b>Telephone: </b> {{tableData?.client_telephone}}</p>\n                </div>\n                <div class=\"main-subdetail\">\n                  <h2><b>Status</b></h2>\n                  <p class=\"set-content\">{{tableData?.estimate_status}}</p>\n                </div>\n              </div>\n            </ion-label>\n          </ion-label>\n        </ion-item>\n      </ion-list>\n    </div>\n  </div>\n</ion-content>\n\n<ion-content *ngIf=\"tableSwitch=='6'\">\n  <div class=\"app-layout set-height\">\n    <div class=\"container\">\n      <div class=\"heading\">\n        <h3>PAYMENT INFO</h3>\n      </div>\n      <ion-list class=\"main-list\">\n\n        <ion-item lines=\"none\">\n          <ion-label>\n            <ion-label>\n              <div class=\"main-detail\">\n                <h3><b>Name: </b>Paul Molive </h3>\n                <h3><b>Amount: </b>$80 </h3>\n                <h3 id=\"projects\"><b>Date: </b>14/02/2020 </h3>\n                <div class=\"main-subdetail\">\n                  <h2><b>Client Details</b></h2>\n                  <p><b>Company Name: </b> </p>\n                  <p><b>Contact Name:: </b> James Findlay</p>\n                  <p><b>Email: </b> james@elitermg.com</p>\n                  <p><b>Telephone: </b> 16047571117/p>\n                </div>\n                <div class=\"main-subdetail\">\n                  <h2><b>Status</b></h2>\n                  <p>The contract has not yet been sent to the client.</p>\n                </div>\n              </div>\n            </ion-label>\n          </ion-label>\n        </ion-item>\n      </ion-list>\n    </div>\n  </div>\n</ion-content>\n\n<!-- <ion-content *ngIf=\"tableSwitch=='8'\">\n  <div class=\"app-layout set-height\">\n    <div class=\"container\">\n      <div class=\"heading\">\n        <h3>WORK ORDER DETAILS</h3>\n      </div>\n      <ion-list class=\"main-list\">\n\n        <ion-item lines=\"none\">\n          <ion-label>\n            <ion-label>\n              <div class=\"main-detail\">\n                <h3 class=\"my-2\"><b>#Invoice: </b>{{tableData?.invoice_id}}</h3>\n                <h3 class=\"my-2\"><b>Work Type: </b>{{tableData?.work_type}}</h3>\n                <h3 class=\"my-2\"><b>Work Order: </b>{{tableData?.work_order_number}}</h3>\n                <h3 class=\"my-2\"><b>Bill To: </b>{{tableData?.bill_to}}</h3>\n                <h3 class=\"my-2\"><b>Work Requested: </b>{{tableData?.work_request}}</h3>\n                <h3 class=\"my-2\"><b>Status: </b>{{tableData?.work_status}}</h3>\n                <div class=\"main-subdetail\">\n                  <h2><b>Action</b></h2>\n                  <ion-button expand=\"fill\" color=\"success\" (click)=\"openIFrame(tableData.id)\" class=\"mt-3\">Edit</ion-button>\n                  <ion-button expand=\"fill\" color=\"danger\" class=\"mt-3\">Delete</ion-button>\n                </div>\n              </div>\n            </ion-label>\n          </ion-label>\n        </ion-item>\n      </ion-list>\n    </div>\n  </div>\n</ion-content> -->\n");

/***/ }),

/***/ "./src/app/table/table-routing.module.ts":
/*!***********************************************!*\
  !*** ./src/app/table/table-routing.module.ts ***!
  \***********************************************/
/*! exports provided: TablePageRoutingModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "TablePageRoutingModule", function() { return TablePageRoutingModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm2015/core.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm2015/router.js");
/* harmony import */ var _table_page__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./table.page */ "./src/app/table/table.page.ts");




const routes = [
    {
        path: '',
        component: _table_page__WEBPACK_IMPORTED_MODULE_3__["TablePage"]
    }
];
let TablePageRoutingModule = class TablePageRoutingModule {
};
TablePageRoutingModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"].forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"]],
    })
], TablePageRoutingModule);



/***/ }),

/***/ "./src/app/table/table.module.ts":
/*!***************************************!*\
  !*** ./src/app/table/table.module.ts ***!
  \***************************************/
/*! exports provided: TablePageModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "TablePageModule", function() { return TablePageModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm2015/core.js");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/fesm2015/common.js");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/forms */ "./node_modules/@angular/forms/fesm2015/forms.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/fesm2015/ionic-angular.js");
/* harmony import */ var _table_routing_module__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./table-routing.module */ "./src/app/table/table-routing.module.ts");
/* harmony import */ var _table_page__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./table.page */ "./src/app/table/table.page.ts");







let TablePageModule = class TablePageModule {
};
TablePageModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"],
            _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormsModule"],
            _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["IonicModule"],
            _table_routing_module__WEBPACK_IMPORTED_MODULE_5__["TablePageRoutingModule"]
        ],
        declarations: [_table_page__WEBPACK_IMPORTED_MODULE_6__["TablePage"]]
    })
], TablePageModule);



/***/ }),

/***/ "./src/app/table/table.page.scss":
/*!***************************************!*\
  !*** ./src/app/table/table.page.scss ***!
  \***************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("/**LIST: START**/\n.main-list {\n  --ion-background-color: #000 !important;\n}\n.main-list ion-item {\n  --ion-background-color: #fff !important;\n  --padding-top: 10px !important;\n  --padding-bottom: 10px !important;\n}\n.main-list ion-avatar {\n  margin: 0 !important;\n}\n.main-list .icon {\n  font-size: 25px;\n}\n.main-list .item {\n  padding: 10px;\n}\n.main-list .f-icon {\n  font-size: 15px;\n}\n.main-subdetail {\n  border-top: 1px solid #bfbfbf;\n  padding: 10px 0;\n}\n.main-subdetail h2 {\n  padding-bottom: 5px;\n}\n.main-detail #projects {\n  padding: 3px 0 10px 0;\n}\n.main-detail p,\n.main-detail h3 {\n  font-size: 15px;\n}\n.set-content {\n  white-space: normal;\n}\n.main-detail h2,\n.main-detail h3,\n.main-detail p {\n  white-space: normal;\n}\n.container {\n  background-color: black;\n}\n.note-detail {\n  border-top: 1px solid #bfbfbf;\n  padding: 10px 0;\n}\n.set-p p,\n.set-p h3,\n.set-p b {\n  margin-bottom: 0px !important;\n}\n.set-p b {\n  font-size: 15px !important;\n}\n.set-p h2 b {\n  font-size: 17px !important;\n}\n.set-p .main-subdetail h2,\n.set-p .note-detail h2 {\n  margin-top: 0px !important;\n  margin-bottom: 0px !important;\n}\n.webPage {\n  width: 100%;\n  height: 600px;\n}\n/**LIST: START**/\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvdGFibGUvRTpcXHNoaXBnaWdcXGNva2tpZS1hcHAvc3JjXFxhcHBcXHRhYmxlXFx0YWJsZS5wYWdlLnNjc3MiLCJzcmMvYXBwL3RhYmxlL3RhYmxlLnBhZ2Uuc2NzcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQSxnQkFBQTtBQUNBO0VBQ0UsdUNBQUE7QUNDRjtBREVBO0VBQ0UsdUNBQUE7RUFDQSw4QkFBQTtFQUNBLGlDQUFBO0FDQ0Y7QURFQTtFQUNFLG9CQUFBO0FDQ0Y7QURFQTtFQUNFLGVBQUE7QUNDRjtBREVBO0VBQ0UsYUFBQTtBQ0NGO0FERUE7RUFDRSxlQUFBO0FDQ0Y7QURFQTtFQUNFLDZCQUFBO0VBQ0EsZUFBQTtBQ0NGO0FERUE7RUFDRSxtQkFBQTtBQ0NGO0FERUE7RUFDRSxxQkFBQTtBQ0NGO0FERUE7O0VBRUUsZUFBQTtBQ0NGO0FERUE7RUFDRSxtQkFBQTtBQ0NGO0FERUE7OztFQUdFLG1CQUFBO0FDQ0Y7QURFQTtFQUNFLHVCQUFBO0FDQ0Y7QURFQTtFQUNFLDZCQUFBO0VBQ0EsZUFBQTtBQ0NGO0FERUE7OztFQUdFLDZCQUFBO0FDQ0Y7QURFQTtFQUNFLDBCQUFBO0FDQ0Y7QURFQTtFQUNFLDBCQUFBO0FDQ0Y7QURFQTs7RUFFRSwwQkFBQTtFQUNBLDZCQUFBO0FDQ0Y7QURFQTtFQUNFLFdBQUE7RUFDQSxhQUFBO0FDQ0Y7QURFQSxnQkFBQSIsImZpbGUiOiJzcmMvYXBwL3RhYmxlL3RhYmxlLnBhZ2Uuc2NzcyIsInNvdXJjZXNDb250ZW50IjpbIi8qKkxJU1Q6IFNUQVJUKiovXHJcbi5tYWluLWxpc3Qge1xyXG4gIC0taW9uLWJhY2tncm91bmQtY29sb3I6ICMwMDAgIWltcG9ydGFudDtcclxufVxyXG5cclxuLm1haW4tbGlzdCBpb24taXRlbSB7XHJcbiAgLS1pb24tYmFja2dyb3VuZC1jb2xvcjogI2ZmZiAhaW1wb3J0YW50O1xyXG4gIC0tcGFkZGluZy10b3A6IDEwcHggIWltcG9ydGFudDtcclxuICAtLXBhZGRpbmctYm90dG9tOiAxMHB4ICFpbXBvcnRhbnQ7XHJcbn1cclxuXHJcbi5tYWluLWxpc3QgaW9uLWF2YXRhciB7XHJcbiAgbWFyZ2luOiAwICFpbXBvcnRhbnQ7XHJcbn1cclxuXHJcbi5tYWluLWxpc3QgLmljb24ge1xyXG4gIGZvbnQtc2l6ZTogMjVweDtcclxufVxyXG5cclxuLm1haW4tbGlzdCAuaXRlbSB7XHJcbiAgcGFkZGluZzogMTBweDtcclxufVxyXG5cclxuLm1haW4tbGlzdCAuZi1pY29uIHtcclxuICBmb250LXNpemU6IDE1cHg7XHJcbn1cclxuXHJcbi5tYWluLXN1YmRldGFpbCB7XHJcbiAgYm9yZGVyLXRvcDogMXB4IHNvbGlkICNiZmJmYmY7XHJcbiAgcGFkZGluZzogMTBweCAwO1xyXG59XHJcblxyXG4ubWFpbi1zdWJkZXRhaWwgaDIge1xyXG4gIHBhZGRpbmctYm90dG9tOiA1cHg7XHJcbn1cclxuXHJcbi5tYWluLWRldGFpbCAjcHJvamVjdHMge1xyXG4gIHBhZGRpbmc6IDNweCAwIDEwcHggMDtcclxufVxyXG5cclxuLm1haW4tZGV0YWlsIHAsXHJcbi5tYWluLWRldGFpbCBoMyB7XHJcbiAgZm9udC1zaXplOiAxNXB4O1xyXG59XHJcblxyXG4uc2V0LWNvbnRlbnQge1xyXG4gIHdoaXRlLXNwYWNlOiBub3JtYWw7XHJcbn1cclxuXHJcbi5tYWluLWRldGFpbCBoMixcclxuLm1haW4tZGV0YWlsIGgzLFxyXG4ubWFpbi1kZXRhaWwgcCB7XHJcbiAgd2hpdGUtc3BhY2U6IG5vcm1hbDtcclxufVxyXG5cclxuLmNvbnRhaW5lciB7XHJcbiAgYmFja2dyb3VuZC1jb2xvcjogYmxhY2s7XHJcbn1cclxuXHJcbi5ub3RlLWRldGFpbCB7XHJcbiAgYm9yZGVyLXRvcDogMXB4IHNvbGlkICNiZmJmYmY7XHJcbiAgcGFkZGluZzogMTBweCAwO1xyXG59XHJcblxyXG4uc2V0LXAgcCxcclxuLnNldC1wIGgzLFxyXG4uc2V0LXAgYiB7XHJcbiAgbWFyZ2luLWJvdHRvbTogMHB4ICFpbXBvcnRhbnQ7XHJcbn1cclxuXHJcbi5zZXQtcCBiIHtcclxuICBmb250LXNpemU6IDE1cHggIWltcG9ydGFudDtcclxufVxyXG5cclxuLnNldC1wIGgyIGIge1xyXG4gIGZvbnQtc2l6ZTogMTdweCAhaW1wb3J0YW50O1xyXG59XHJcblxyXG4uc2V0LXAgLm1haW4tc3ViZGV0YWlsIGgyLFxyXG4uc2V0LXAgLm5vdGUtZGV0YWlsIGgyIHtcclxuICBtYXJnaW4tdG9wOiAwcHggIWltcG9ydGFudDtcclxuICBtYXJnaW4tYm90dG9tOiAwcHggIWltcG9ydGFudDtcclxufVxyXG5cclxuLndlYlBhZ2V7XHJcbiAgd2lkdGg6IDEwMCU7XHJcbiAgaGVpZ2h0OiA2MDBweDtcclxufVxyXG5cclxuLyoqTElTVDogU1RBUlQqKi8iLCIvKipMSVNUOiBTVEFSVCoqL1xuLm1haW4tbGlzdCB7XG4gIC0taW9uLWJhY2tncm91bmQtY29sb3I6ICMwMDAgIWltcG9ydGFudDtcbn1cblxuLm1haW4tbGlzdCBpb24taXRlbSB7XG4gIC0taW9uLWJhY2tncm91bmQtY29sb3I6ICNmZmYgIWltcG9ydGFudDtcbiAgLS1wYWRkaW5nLXRvcDogMTBweCAhaW1wb3J0YW50O1xuICAtLXBhZGRpbmctYm90dG9tOiAxMHB4ICFpbXBvcnRhbnQ7XG59XG5cbi5tYWluLWxpc3QgaW9uLWF2YXRhciB7XG4gIG1hcmdpbjogMCAhaW1wb3J0YW50O1xufVxuXG4ubWFpbi1saXN0IC5pY29uIHtcbiAgZm9udC1zaXplOiAyNXB4O1xufVxuXG4ubWFpbi1saXN0IC5pdGVtIHtcbiAgcGFkZGluZzogMTBweDtcbn1cblxuLm1haW4tbGlzdCAuZi1pY29uIHtcbiAgZm9udC1zaXplOiAxNXB4O1xufVxuXG4ubWFpbi1zdWJkZXRhaWwge1xuICBib3JkZXItdG9wOiAxcHggc29saWQgI2JmYmZiZjtcbiAgcGFkZGluZzogMTBweCAwO1xufVxuXG4ubWFpbi1zdWJkZXRhaWwgaDIge1xuICBwYWRkaW5nLWJvdHRvbTogNXB4O1xufVxuXG4ubWFpbi1kZXRhaWwgI3Byb2plY3RzIHtcbiAgcGFkZGluZzogM3B4IDAgMTBweCAwO1xufVxuXG4ubWFpbi1kZXRhaWwgcCxcbi5tYWluLWRldGFpbCBoMyB7XG4gIGZvbnQtc2l6ZTogMTVweDtcbn1cblxuLnNldC1jb250ZW50IHtcbiAgd2hpdGUtc3BhY2U6IG5vcm1hbDtcbn1cblxuLm1haW4tZGV0YWlsIGgyLFxuLm1haW4tZGV0YWlsIGgzLFxuLm1haW4tZGV0YWlsIHAge1xuICB3aGl0ZS1zcGFjZTogbm9ybWFsO1xufVxuXG4uY29udGFpbmVyIHtcbiAgYmFja2dyb3VuZC1jb2xvcjogYmxhY2s7XG59XG5cbi5ub3RlLWRldGFpbCB7XG4gIGJvcmRlci10b3A6IDFweCBzb2xpZCAjYmZiZmJmO1xuICBwYWRkaW5nOiAxMHB4IDA7XG59XG5cbi5zZXQtcCBwLFxuLnNldC1wIGgzLFxuLnNldC1wIGIge1xuICBtYXJnaW4tYm90dG9tOiAwcHggIWltcG9ydGFudDtcbn1cblxuLnNldC1wIGIge1xuICBmb250LXNpemU6IDE1cHggIWltcG9ydGFudDtcbn1cblxuLnNldC1wIGgyIGIge1xuICBmb250LXNpemU6IDE3cHggIWltcG9ydGFudDtcbn1cblxuLnNldC1wIC5tYWluLXN1YmRldGFpbCBoMixcbi5zZXQtcCAubm90ZS1kZXRhaWwgaDIge1xuICBtYXJnaW4tdG9wOiAwcHggIWltcG9ydGFudDtcbiAgbWFyZ2luLWJvdHRvbTogMHB4ICFpbXBvcnRhbnQ7XG59XG5cbi53ZWJQYWdlIHtcbiAgd2lkdGg6IDEwMCU7XG4gIGhlaWdodDogNjAwcHg7XG59XG5cbi8qKkxJU1Q6IFNUQVJUKiovIl19 */");

/***/ }),

/***/ "./src/app/table/table.page.ts":
/*!*************************************!*\
  !*** ./src/app/table/table.page.ts ***!
  \*************************************/
/*! exports provided: TablePage */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "TablePage", function() { return TablePage; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm2015/core.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm2015/router.js");
/* harmony import */ var _services_category_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../services/category.service */ "./src/app/services/category.service.ts");




let TablePage = class TablePage {
    constructor(activatedRoute, router, categoryService) {
        this.activatedRoute = activatedRoute;
        this.router = router;
        this.categoryService = categoryService;
        this.tableArr = [];
        this.tableData = {};
    }
    ngOnInit() {
        this.tableSwitch = this.activatedRoute.snapshot.paramMap.get('id');
        this.activatedRoute.queryParams
            .subscribe(params => {
            if (params) {
                this.tableData = params;
            }
            console.log(params);
        });
        this.getCategoryData();
    }
    getCategoryData() {
        // get Client Data
        if (this.tableSwitch && this.tableSwitch == '1') {
            this.categoryService.getSearchClientData().subscribe(res => {
                if (res['length']) {
                    this.tableArr = res;
                }
            }, err => {
                console.log("err", err);
            });
        }
        // get project Data
        if (this.tableSwitch && this.tableSwitch == '3') {
            let clientID = JSON.parse(localStorage.getItem('userData'))['ID'];
            const userId = new FormData();
            userId.append('id', clientID);
            this.categoryService.getSearchProjectData().subscribe(res => {
                if (res['data']) {
                    this.tableArr = res['data'];
                }
            }, err => {
                console.log("err", err);
            });
        }
        // get estimate Data
        if (this.tableSwitch && this.tableSwitch == '5') {
            this.categoryService.getSearchEstimateData().subscribe(res => {
                if (res['length']) {
                    this.tableArr = res;
                }
            }, err => {
                console.log("err", err);
            });
        }
    }
};
TablePage.ctorParameters = () => [
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_2__["ActivatedRoute"] },
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_2__["Router"] },
    { type: _services_category_service__WEBPACK_IMPORTED_MODULE_3__["CategoryService"] }
];
TablePage = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
        selector: 'app-table',
        template: tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(/*! raw-loader!./table.page.html */ "./node_modules/raw-loader/dist/cjs.js!./src/app/table/table.page.html")).default,
        styles: [tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(/*! ./table.page.scss */ "./src/app/table/table.page.scss")).default]
    }),
    tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_angular_router__WEBPACK_IMPORTED_MODULE_2__["ActivatedRoute"],
        _angular_router__WEBPACK_IMPORTED_MODULE_2__["Router"],
        _services_category_service__WEBPACK_IMPORTED_MODULE_3__["CategoryService"]])
], TablePage);



/***/ })

}]);
//# sourceMappingURL=table-table-module-es2015.js.map